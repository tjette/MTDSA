<?php
/*
 * All Custom Shortcode for [theme_name] theme.
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

if( ! function_exists( 'groppe_vt_shortcodes' ) ) {
  function groppe_vt_shortcodes( $options ) {
    $causes = get_posts( 'post_type="give_forms"&numberposts=-1' );
        $all_causes = array();
        if ( $causes ) {
          foreach ( $causes as $cause ) {
            $all_causes[ $cause->ID ] = $cause->post_title;
          }
        } else {
          $all_causes[ esc_html__( 'No contact forms found', 'groppe-core' ) ] = 0;
        }

    $options       = array();

    /* Header Shortcodes */
    $options[]     = array(
      'title'      => esc_html__('Top Bar Shortcodes', 'groppe-core'),
      'shortcodes' => array(

        // Address Info
        array(
          'name'          => 'grop_address_infos',
          'title'         => esc_html__('Address Info', 'groppe-core'),
          // 'view'          => 'clone',
          // 'clone_id'      => 'grop_address_info',
          // 'clone_title'   => esc_html__('Add New', 'groppe-core'),
          'fields'        => array(

            array(
              'id'        => 'info_style',
              'type'      => 'select',
              'title'     => esc_html__('Address Info Style', 'groppe-core'),
              'options'   => array(
                'style-one' => esc_html__('Style One', 'groppe-core'),
                'style-two' => esc_html__('Style Two', 'groppe-core'),
              ),
            ),

            array(
              'id'        => 'custom_class',
              'type'      => 'text',
              'title'     => esc_html__('Custom Class', 'groppe-core'),
            ),
            array(
              'id'        => 'target_tab',
              'type'      => 'switcher',
              'title'     => esc_html__('Open New Tab?', 'groppe-core'),
              'on_text'     => esc_html__('Yes', 'groppe-core'),
              'off_text'     => esc_html__('No', 'groppe-core'),
            ),
            array(
              'id'        => 'info_icon_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Info Icon Color', 'groppe-core'),
            ),
            array(
              'id'        => 'content_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Info Content Color', 'groppe-core'),
            ),
            array(
              'id'        => 'content_size',
              'type'      => 'text',
              'title'     => esc_html__('Info Content Size', 'groppe-core'),
            ),
          
          // 'clone_fields'  => array(
            // Icon One
            array(
              'type'    => 'notice',
              'class'   => 'info',
              'content' => esc_html__('Info One', 'groppe')
            ),
            array(
              'id'        => 'info_icon_one',
              'type'      => 'icon',
              'title'     => esc_html__('Info Icon One', 'groppe-core')
            ),
            array(
              'id'        => 'info_title_one',
              'type'      => 'text',
              'dependency'  => array('info_style', '==', 'style-two'),
              'title'     => esc_html__('Title One', 'groppe-core')
            ),
            array(
              'id'        => 'info_text_one',
              'type'      => 'text',
              'title'     => esc_html__('Text', 'groppe-core')
            ),
            array(
              'id'        => 'info_one_link',
              'type'      => 'text',
              'title'     => esc_html__('Text Link', 'groppe-core')
            ),
            // Icon Two
            array(
              'type'    => 'notice',
              'class'   => 'info',
              'content' => esc_html__('Info Two', 'groppe')
            ),
            array(
              'id'        => 'info_icon_two',
              'type'      => 'icon',
              'title'     => esc_html__('Info Icon Two', 'groppe-core')
            ),
            array(
              'id'        => 'info_title_two',
              'type'      => 'text',
              'dependency'  => array('info_style', '==', 'style-two'),
              'title'     => esc_html__('Title Two', 'groppe-core')
            ),
            array(
              'id'        => 'info_text_two',
              'type'      => 'text',
              'title'     => esc_html__('Text Two', 'groppe-core')
            ),
            array(
              'id'        => 'info_two_link',
              'type'      => 'text',
              'title'     => esc_html__('Text Two Link', 'groppe-core')
            ),
            
          ),

        ),
        // Address Info
        // Social
        array(
          'name'          => 'grop_socials',
          'title'         => esc_html__('Groppe Social', 'groppe-core'),
          'view'          => 'clone',
          'clone_id'      => 'grop_social',
          'clone_title'   => esc_html__('Add New', 'groppe-core'),
          'fields'        => array(
            array(
              'id'        => 'social_style',
              'type'      => 'select',
              'title'     => esc_html__('Social Icon Style', 'groppe-core'),
              'options'   => array(
                'style-one' => esc_html__('Style One (Top-bar)', 'groppe-core'),
                'style-two' => esc_html__('Style Two (Copyright section)', 'groppe-core'),
              ),
            ),

            array(
              'id'        => 'custom_class',
              'type'      => 'text',
              'title'     => esc_html__('Wrap Class', 'groppe-core'),
            ),
            array(
              'id'        => 'ul_class',
              'type'      => 'text',
              'title'     => esc_html__('UL Class', 'groppe-core'),
            ),
            array(
              'id'        => 'align',
              'type'      => 'select',
              'title'     => esc_html__('Wrap Tag', 'groppe-core'),
              'options'   => array(
                'right' => esc_html__('Right', 'groppe-core'),
                'center' => esc_html__('Center', 'groppe-core'),
                'left' => esc_html__('Left', 'groppe-core'),
              ),
            ),
            array(
              'id'        => 'icon_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Color', 'groppe-core'),
            ),
            array(
              'id'        => 'icon_hover_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Hover Color', 'groppe-core'),
            ),

          ),
          'clone_fields'  => array(
            array(
              'id'        => 'icon',
              'type'      => 'icon',
              'title'     => esc_html__('Info Icon', 'groppe-core')
            ),
            array(
              'id'        => 'link',
              'type'      => 'text',
              'title'     => esc_html__('Text Link', 'groppe-core')
            ),
            array(
              'id'        => 'target_tab',
              'type'      => 'switcher',
              'title'     => esc_html__('Open New Tab?', 'groppe-core'),
              'on_text'     => esc_html__('Yes', 'groppe-core'),
              'off_text'     => esc_html__('No', 'groppe-core'),
            ),

          ),

        ),
        // Social

      ),
    );/* Header Shortcodes */
    $options[]     = array(
      'title'      => esc_html__('Footer Shortcodes', 'groppe-core'),
      'shortcodes' => array(

        // Address Info
        array(
          'name'          => 'footer_address_infos',
          'title'         => esc_html__('Footer Address', 'groppe-core'),
          'view'          => 'clone',
          'clone_id'      => 'footer_address_info',
          'clone_title'   => esc_html__('Add New', 'groppe-core'),
          'fields'        => array(

            array(
              'id'        => 'custom_class',
              'type'      => 'text',
              'title'     => esc_html__('Custom Class', 'groppe-core'),
            ),

          ),
          'clone_fields'  => array(
            array(
              'id'        => 'pre_text',
              'type'      => 'text',
              'title'     => esc_html__('Pre Text', 'groppe-core')
            ),
            array(
              'id'        => 'info_text',
              'type'      => 'text',
              'title'     => esc_html__('Info Text', 'groppe-core')
            ),
            array(
              'id'        => 'info_link',
              'type'      => 'text',
              'title'     => esc_html__('Text Link', 'groppe-core')
            ),
            array(
              'id'        => 'info_text_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Link Color', 'groppe-core'),
            ),
            array(
              'id'        => 'info_text_hover_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Link Hover Color', 'groppe-core'),
            ),
            array(
              'id'        => 'target_tab',
              'type'      => 'switcher',
              'title'     => esc_html__('Open New Tab?', 'groppe-core'),
              'on_text'     => esc_html__('Yes', 'groppe-core'),
              'off_text'     => esc_html__('No', 'groppe-core'),
            ),

          ),

        ),
        // Address Info
      ),
    );

    /* Content Shortcodes */
    $options[]     = array(
      'title'      => esc_html__('Content Shortcodes', 'groppe-core'),
      'shortcodes' => array(

        // Spacer
        array(
          'name'          => 'grop_spacer',
          'title'         => esc_html__('Spacer', 'groppe-core'),
          'fields'        => array(

            array(
              'id'        => 'height',
              'type'      => 'text',
              'title'     => esc_html__('Height', 'groppe-core'),
              'attributes' => array(
                'placeholder'     => '20px',
              ),
            ),

          ),
        ),

        // Spacer
        array(
          'name'          => 'grop_button',
          'title'         => esc_html__('Button', 'groppe-core'),
          'fields'        => array(

            array(
              'id'        => 'use_wrapper',
              'type'      => 'switcher',
              'title'     => esc_html__('Use Wrapper?', 'groppe'),
              'on_text'     => esc_html__('Yes', 'groppe'),
              'off_text'     => esc_html__('No', 'groppe'),
            ),
            array(
              'id'        => 'wrapper_class',
              'type'      => 'text',
              'title'     => esc_html__('Wrapper Class', 'groppe-core'),
              'dependency'  => array('use_wrapper', '==', 'true'),
            ),
            array(
              'id'        => 'link',
              'type'      => 'text',
              'title'     => esc_html__('Button Link', 'groppe-core'),
              'attributes' => array(
                'placeholder'     => 'http://',
              ),
            ),
            array(
              'id'        => 'button_text',
              'type'      => 'text',
              'title'     => esc_html__('Button Text', 'groppe-core'),
            ),
            array(
              'id'        => 'button_class',
              'type'      => 'text',
              'title'     => esc_html__('Button Class', 'groppe-core'),
            ),
            array(
              'id'        => 'open_link',
              'type'      => 'switcher',
              'title'     => esc_html__('Open New Tab?', 'groppe'),
              'on_text'     => esc_html__('Yes', 'groppe'),
              'off_text'     => esc_html__('No', 'groppe'),
            ),
            array(
              'id'        => 'wrap_span',
              'type'      => 'switcher',
              'title'     => esc_html__('Wrap Span?', 'groppe'),
              'on_text'     => esc_html__('Yes', 'groppe'),
              'off_text'     => esc_html__('No', 'groppe'),
            ),
          ),
        ),
        // Current Year
        array(
          'name'          => 'grop_current_year',
          'title'         => esc_html__('Current Year', 'groppe-core'),
        ),
        // Home URL
        array(
          'name'          => 'grop_home_url',
          'title'         => esc_html__('Home URL', 'groppe-core'),
        ),
        // Text Block

        array(
          'name'          => 'grop_text_block',
          'title'         => esc_html__('Text Block', 'groppe-core'),
          'fields'        => array(
            array(
              'id'        => 'custom_class',
              'type'      => 'text',
              'title'     => esc_html__('Custom Class', 'groppe-core'),
            ),
            array(
              'id'        => 'wrap_tag',
              'type'      => 'select',
              'title'     => esc_html__('Wrap Tag', 'groppe-core'),
              'options'   => array(
                'div' => esc_html__('Div', 'groppe-core'),
                'p' => esc_html__('P', 'groppe-core'),
                'pre' => esc_html__('Pre', 'groppe-core'),
                'span' => esc_html__('Span', 'groppe-core'),
                'H1' => esc_html__('h1', 'groppe-core'),
                'H2' => esc_html__('h2', 'groppe-core'),
                'H3' => esc_html__('h3', 'groppe-core'),
                'H4' => esc_html__('h4', 'groppe-core'),
                'H5' => esc_html__('h5', 'groppe-core'),
                'H6' => esc_html__('h6', 'groppe-core'),
              ),
            ),
            array(
              'id'        => 'text',
              'type'      => 'textarea',
              'title'     => esc_html__('Content', 'groppe-core'),
            ),
          ),
        ),


        array(
          'name'          => 'grop_images',
          'title'         => esc_html__('Image Block', 'groppe-core'),
          'view'          => 'clone',
          'clone_id'      => 'grop_image',
          'clone_title'   => esc_html__('Add Image', 'groppe-core'),
          'fields'        => array(
            array(
              'id'        => 'column',
              'type'      => 'select',
              'title'     => esc_html__('Image Column', 'groppe-core'),
              'options'   => array(
                '' => esc_html__('select column', 'groppe-core'),
                'single-image' => esc_html__('Sinlg Column', 'groppe-core'),
                'two-image' => esc_html__('Two column', 'groppe-core'),
                'three-image' => esc_html__('Three column', 'groppe-core'),
                'four-image' => esc_html__('Four column', 'groppe-core'),
              ),
            ),
            array(
              'id'        => 'custom_class',
              'type'      => 'text',
              'title'     => esc_html__('Custom Class', 'groppe-core'),
            ),
          ),
          'clone_fields' => array(
            array(
              'id'        => 'image',
              'type'      => 'image',
              'title'     => esc_html__('Upload Image', 'groppe-core'),
            ),
            array(
              'id'        => 'alt',
              'type'      => 'text',
              'title'     => esc_html__('Alt Text', 'groppe-core'),
            ),
          ),
        ),

        // Cause Form
        array(
          'name'          => 'slider_donation_cause',
          'title'         => esc_html__('Donation Cause', 'groppe-core'),
          'fields'        => array(
            array(
              'id'        => 'cause_form_select',
              'type'      => 'select',
              'title'     => esc_html__('Select Cause Form', 'groppe'),
              'options'        => $all_causes,
            ),
            array(
              'id'        => 'button_text',
              'type'      => 'text',
              'title'     => esc_html__('Button Text', 'groppe-core'),
              'wrap_class' => 'column_half',
            ),
            array(
              'id'        => 'button_link',
              'type'      => 'text',
              'title'     => esc_html__('Button Link', 'groppe-core'),
              'wrap_class' => 'column_half',
            ),

          ),
        ),
        // Simple Link
        array(
          'name'          => 'grop_simple_link',
          'title'         => esc_html__('Simple Link', 'groppe'),
          'fields'        => array(

            array(
              'id'        => 'link_style',
              'type'      => 'select',
              'title'     => esc_html__('Link Style', 'groppe'),
              'options'        => array(
                'link-underline' => esc_html__('Link Underline', 'groppe'),
                'link-arrow-right' => esc_html__('Link Arrow (Right)', 'groppe'),
                'link-arrow-left' => esc_html__('Link Arrow (Left)', 'groppe'),
              ),
            ),
            array(
              'id'        => 'link_icon',
              'type'      => 'icon',
              'title'     => esc_html__('Icon', 'groppe'),
              'value'      => 'fa fa-caret-right',
              'dependency'  => array('link_style', '!=', 'link-underline'),
            ),
            array(
              'id'        => 'link_text',
              'type'      => 'text',
              'title'     => esc_html__('Link Text', 'groppe'),
            ),
            array(
              'id'        => 'link',
              'type'      => 'text',
              'title'     => esc_html__('Link', 'groppe'),
              'attributes' => array(
                'placeholder'     => 'http://',
              ),
            ),
            array(
              'id'        => 'target_tab',
              'type'      => 'switcher',
              'title'     => esc_html__('Open New Tab?', 'groppe'),
              'on_text'     => esc_html__('Yes', 'groppe'),
              'off_text'     => esc_html__('No', 'groppe'),
            ),
            array(
              'id'        => 'custom_class',
              'type'      => 'text',
              'title'     => esc_html__('Custom Class', 'groppe'),
            ),

            // Normal Mode
            array(
              'type'    => 'notice',
              'class'   => 'info',
              'content' => esc_html__('Normal Mode', 'groppe')
            ),
            array(
              'id'        => 'text_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Text Color', 'groppe'),
              'wrap_class' => 'column_half el-hav-border',
            ),
            array(
              'id'        => 'border_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Border Color', 'groppe'),
              'wrap_class' => 'column_half el-hav-border',
              'dependency'  => array('link_style', '==', 'link-underline'),
            ),
            // Hover Mode
            array(
              'type'    => 'notice',
              'class'   => 'info',
              'content' => esc_html__('Hover Mode', 'groppe')
            ),
            array(
              'id'        => 'text_hover_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Text Hover Color', 'groppe'),
              'wrap_class' => 'column_half el-hav-border',
            ),
            array(
              'id'        => 'border_hover_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Border Hover Color', 'groppe'),
              'wrap_class' => 'column_half el-hav-border',
              'dependency'  => array('link_style', '==', 'link-underline'),
            ),

            // Size
            array(
              'type'    => 'notice',
              'class'   => 'info',
              'content' => esc_html__('Font Sizes', 'groppe')
            ),
            array(
              'id'        => 'text_size',
              'type'      => 'text',
              'title'     => esc_html__('Text Size', 'groppe'),
              'attributes' => array(
                'placeholder'     => 'Eg: 14px',
              ),
            ),

          ),
        ),
        // Simple Link

        // Project Info
        array(
          'name'          => 'grop_project_info',
          'title'         => esc_html__('Project Infos', 'groppe-core'),
          'fields'        => array(

            array(
              'id'        => 'custom_class',
              'type'      => 'text',
              'title'     => esc_html__('Custom Class', 'groppe'),
            ),
          ),
        ),

        // Blockquotes
        array(
          'name'          => 'grop_blockquote',
          'title'         => esc_html__('Blockquote', 'groppe'),
          'fields'        => array(

            array(
              'id'        => 'blockquote_style',
              'type'      => 'select',
              'title'     => esc_html__('Blockquote Style', 'groppe'),
              'options'        => array(
                '' => esc_html__('Select Blockquote Style', 'groppe'),
                'style-one' => esc_html__('Style One', 'groppe'),
                'style-two' => esc_html__('Style Two', 'groppe'),
              ),
            ),
            array(
              'id'        => 'text_size',
              'type'      => 'text',
              'title'     => esc_html__('Text Size', 'groppe'),
            ),
            array(
              'id'        => 'custom_class',
              'type'      => 'text',
              'title'     => esc_html__('Custom Class', 'groppe'),
            ),
            array(
              'id'        => 'content_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Content Color', 'groppe'),
            ),
            array(
              'id'        => 'left_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Left Border Color', 'groppe'),
            ),
            array(
              'id'        => 'border_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Border Color', 'groppe'),
            ),
            array(
              'id'        => 'bg_color',
              'type'      => 'color_picker',
              'title'     => esc_html__('Background Color', 'groppe'),
            ),
            // Content
            array(
              'id'        => 'content',
              'type'      => 'textarea',
              'title'     => esc_html__('Content', 'groppe'),
            ),

          ),

        ),
        // Blockquotes
      ),
    );

  return $options;

  }
  add_filter( 'cs_shortcode_options', 'groppe_vt_shortcodes' );
}
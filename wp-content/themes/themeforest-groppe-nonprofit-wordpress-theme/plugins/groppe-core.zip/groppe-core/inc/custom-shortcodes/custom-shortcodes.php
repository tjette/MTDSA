<?php

/* ==========================================================
  Buttons
=========================================================== */
if ( !function_exists('grop_button_function')) {
  function grop_button_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'use_wrapper'  => '',
      'wrapper_class'  => '',
      'link'  => '',
      'button_text'  => '',
      'button_class'  => '',
      'open_link'  => '',
      'wrap_span'  => '',
    ), $atts));

    if ( $use_wrapper ) {
      $wrap_before = '<div class="'.esc_attr($wrapper_class).'">';
      $wrap_after = '</div>';
    } else {
      $wrap_before = '';
      $wrap_after = '';
    }

    $output = $wrap_before;
        $class = $button_class ? ' class="'.esc_attr( $each_button['class'] ).'"' : '';
        $open_link = $open_link ? ' target="_blank"' : ''; 

        if ($wrap_span) {
          $output .= '<a'.$class.$open_link.' href="'.esc_url($link).'"><span>'.esc_html__($button_text, 'groppe-core').'</span></a>';
        } else {
          $output .= '<a'.$class.$open_link.' href="'.esc_url($link).'">'.esc_html__($button_text, 'groppe-core').'</a>';
        }
    $output .= $wrap_after;

    return $output;
  }
}
add_shortcode( 'grop_button', 'grop_button_function' );

/* Spacer */
function grop_spacer_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "height" => '',
  ), $atts));

  $result = do_shortcode('[vc_empty_space height="'. $height .'"]');
  return $result;

}
add_shortcode("grop_spacer", "grop_spacer_function");

/* Project Info */
function grop_project_info_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "custom_class" => '',
  ), $atts));
ob_start();
// Metabox
global $post;
$groppe_id    = ( isset( $post ) ) ? $post->ID : 0;
$groppe_id    = ( is_home() ) ? get_option( 'page_for_posts' ) : $groppe_id;
$groppe_id    = ( is_woocommerce_shop() ) ? wc_get_page_id( 'shop' ) : $groppe_id;
$groppe_meta  = get_post_meta( $groppe_id, 'page_type_metabox', true );
$project_options  = get_post_meta( $groppe_id, 'project_options', true );
if ($project_options) {
  $project_donors = $project_options['project_donors'];
  $project_info = $project_options['project_info'];
} else {
  $project_donors = array();
  $project_info = array();
}
if ($project_info) { ?>
  <div class="grop-prjctinfo_box_warp">
    <ul class="grop-fix grop-list_unstyled">
      <?php
      foreach ($project_info as $key => $info) {
        $icon = $imagess = wp_get_attachment_image_src( $info['info_icon'], 'full' );
        $info_title = $info['info_title'];
        $info_desc = $info['info_desc'];
        $groppe_alt = get_post_meta($info['info_icon'], '_wp_attachment_image_alt', true);
        ?>
        <li>
          <div class="text-center  grop-prjctinfo_box">
            <div class="grop-prjcts_icon">
              <img src="<?php echo esc_url($icon[0]); ?>" alt="<?php echo esc_attr($groppe_alt); ?>" />
            </div>
            <h6><?php echo esc_attr($info_title); ?></h6>
            <h5><?php echo esc_attr($info_desc); ?></h5>
          </div>
        </li>
      <?php } ?>
    </ul>
  </div><!--/end-->
<?php }
$result = ob_get_clean();

  return $result;

}
add_shortcode("grop_project_info", "grop_project_info_function");

// donation cause
function slider_donation_cause_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "cause_form_select" => '',
    "button_text" => '',
    "button_link" => '',
  ), $atts));

  ob_start(); ?>
  <?php
    $args = array(
      'post_type' => 'give_forms',
      'posts_per_page' => 1,
      'orderby' => 'none',
      'order' => 'ASC',
      'post__in' => (array) $cause_form_select,
    );
    $grop_cas = new WP_Query( $args ); ?>
    <?php
      if ($grop_cas->have_posts()) : while ($grop_cas->have_posts()) : $grop_cas->the_post();
        $form        = new Give_Donate_Form( get_the_ID() );
        $goal_option = get_post_meta( get_the_ID(), '_give_goal_option', true );
        $goal        = $form->goal;
        $goal_format = get_post_meta( get_the_ID(), '_give_goal_format', true );
        $income      = $form->get_earnings();
        $color       = get_post_meta( get_the_ID(), '_give_goal_color', true );
        //Sanity check - ensure form has goal set to output
        if ( empty( $form->ID ) || ( is_singular( 'give_forms' ) && ! give_is_setting_enabled( $goal_option ) ) || ! give_is_setting_enabled( $goal_option ) || $goal == 0 ) {
          return false;
        }
        $progress = round( ( $income / $goal ) * 100, 2 );
        if ( $income >= $goal ) {
          $progress = 100;
        } 
        $income = give_human_format_large_amount( give_format_amount( $income ) );
        $goal = give_human_format_large_amount( give_format_amount( $goal ) );
    ?>
    <div class="grop-vertical_middle  grop-float_left grop-hm-4cap_box">
      <!--  text start \-->
      <div class="grop-hm-4cap_btxt">
        <h3><?php echo esc_attr(get_the_title()); ?></h3>
        <p><?php echo the_excerpt(); ?></p>
      </div><!--/  text end-->
      
      <div class="grop-hm-4cap_p_bar">
          <!--  ammount start \-->
        <div class="grop-cusigl_dt-txt">
          <div class="row grop-hm-4cap_pb_amn">
            <div class="text-left  col-xs-6 grop-rsd_amn ">
              <?php echo __('Raised: <span class="grop-rasd_amount grop-conter-hm4">'.apply_filters( 'give_goal_amount_raised_output', give_currency_filter( $income ) ).'</span>', 'groppe'); ?>
            </div>
            <div class="text-right  col-xs-6 grop-gal_amn">
              <?php echo __('Goal: <span class="grop-gl_amount grop-conter-hm4">'.apply_filters( 'give_goal_amount_target_output', give_currency_filter( $goal ) ).'</span>', 'groppe'); ?>
            </div>
          </div>
        </div>
        <?php 
        $button_text = $button_text ? $button_text : esc_html__('Donate now', 'groppe-core'); ?>
        <div class="grop-skill_prgresbar">
          <div class="grop-progress-bar" data-percentage="<?php echo $progress;  ?>%">
            <div class="progress-content-outter">
              <div class="progress-bar-striped animated progress-content"></div>
            </div>
          </div>
        </div>
        <a class="grop-btn grop-btn_overly grop-hm-4cap_pb_btn" href="<?php echo $button_link; ?>">
          <span><?php echo $button_text; ?></span>
        </a>
      </div>
    </div>
    <?php
     endwhile;
     endif;
  $result = ob_get_clean();
  return $result;

}
add_shortcode("slider_donation_cause", "slider_donation_cause_function");

/* Address Infos */
function grop_address_infos_function( $atts, $content = true ) {
   extract(shortcode_atts(array(
      "info_style" => '',
      "custom_class" => '',
      "target_tab" => '',
      "info_icon_color" => '',
      "content_size" => '',
      "content_color" => '',
      // Icons Section
      "info_icon_one" => '',
      "info_title_one" => '',
      "info_text_one" => '',
      "info_one_link" => '',
      "info_icon_two" => '',
      "info_title_two" => '',
      "info_text_two" => '',
      "info_two_link" => '',
   ), $atts));

  // Shortcode Style CSS
  $e_uniqid        = uniqid();
  $inline_style  = '';

  // Text Color
  if ( $info_icon_color ) {
    $inline_style .= '.grop-header_info.address-info-'. $e_uniqid .' ul.list-inline li a i, .grop-header_info.address-info-'. $e_uniqid .' ul.list-inline li i, ul.list-inline.address-info-'. $e_uniqid .' i {';
    $inline_style .= ( $info_icon_color ) ? 'color:'. $info_icon_color .' !important;' : '';
    $inline_style .= '}';
  }
  if ( $content_size || $content_color ) {
    $inline_style .= '.address-info-'. $e_uniqid .' p {';
    $inline_style .= ( $content_size ) ? 'font-size:'. riffel_core_check_px($content_size) .';' : '';
    $inline_style .= ( $content_color ) ? 'color:'. $content_color .';' : '';
    $inline_style .= '}';
  }

  // add inline style
  add_inline_style( $inline_style );
  $styled_class  = ' address-info-'. $e_uniqid;

  $target_link = $target_tab ? 'target="_blank"' : '';

   if($info_style === 'style-two'){
      $icon = $info_icon_one ? '<div class="grop-float_left grop-hsi2_icon"><i class="'.$info_icon_one.'"></i></div>' : '';
      $icon_two = $info_icon_two ? '<div class="grop-float_left grop-hsi2_icon"><i class="'.$info_icon_two.'"></i></div>' : '';
      $title_one = $info_title_one ? '<h6>'.$info_title_one.'</h6>' : '';
      $title_two = $info_title_two ? '<h6>'.$info_title_two.'</h6>' : '';
      $text_one_link = $info_one_link ? '<h5><a href="'.$info_one_link.'" '.$target_link.'>'.$info_text_one.'</a></h5>' : '<h5>'.$info_text_one.'</h5>';
      $text_two_link = $info_two_link ? '<h5><a href="'.$info_two_link.'" '.$target_link.'>'.$info_text_two.'</a></h5>' : '<h5>'.$info_text_two.'</h5>';

      $result = '<ul class="list-inline '. $custom_class .' '.$styled_class.'"><li><div class="text-left  grop-fix  grop-hsi2_single">'. $icon .'<div class="grop-fix grop-float_left  grop-hsi2_txt">'. $title_one . $text_one_link .'</div></div></li><li><div class="text-left  grop-fix  grop-hsi2_single">'. $icon_two .'<div class="grop-fix grop-float_left  grop-hsi2_txt">'. $title_two . $text_two_link .'</div></div></li></ul>';

   } else {
      $info_one = $info_one_link ? '<a href="'.$info_one_link.'" '.$target_link.'><i class="'.$info_icon_one.'"></i>'.$info_text_one.'</a>' : '<span><i class="'.$info_icon_one.'"></i>'.$info_text_one.'</span>';
      $info_two = $info_two_link ? '<a href="'.$info_two_link.'" '.$target_link.'><i class="'.$info_icon_two.'"></i>'.$info_text_two.'</a>' : '<span><i class="'.$info_icon_two.'"></i>'.$info_text_two.'</span>';

      $result = '<div class="text-left grop-header_info '. $custom_class .' '.$styled_class.'"><ul class="list-inline"><li>'. $info_one .'</li><li>'. $info_two .'</li></ul></div>';
   }

   return $result;

}
add_shortcode("grop_address_infos", "grop_address_infos_function");

/* Address Infos */
function footer_address_infos_function( $atts, $content = true ) {
   extract(shortcode_atts(array(
      "custom_class" => ''
   ), $atts));

   $result = '<address class="grop-ftr_wigt_locn '. $custom_class .'">'. do_shortcode($content) .'</address>';
   return $result;

}
add_shortcode("footer_address_infos", "footer_address_infos_function");

/* Address Info */
function footer_address_info_function($atts, $content = NULL) {
   extract(shortcode_atts(array(
      "info_text" => '',
      "pre_text" => '',
      "info_link" => '',
      "info_text_color" => '',
      "info_text_hover_color" => '',
      "target_tab" => ''
   ), $atts));

   // Shortcode Style CSS
  $e_uniqid       = uniqid();
  $inline_style   = '';

  // Colors & Size
  if ( $info_text_color || $info_text_hover_color ) {
    $inline_style .= '.grop-footer-adrs-'. $e_uniqid .' a {';
    $inline_style .= ( $info_text_color ) ? 'color:'. $info_text_color .';' : '';
    $inline_style .= '}';
    $inline_style .= '.grop-footer-adrs-'. $e_uniqid .' a:hover {';
    $inline_style .= ( $info_text_hover_color ) ? 'color:'. $info_text_hover_color .'!important;' : '';
    $inline_style .= '}';
  }
  // add inline style
  add_inline_style( $inline_style );
  $styled_class  = ' grop-footer-adrs-'. $e_uniqid;

   // Color
   $info_text_color = $info_text_color ? 'color:'. $info_text_color .';' : '';

   $target_tab = ( $target_tab === '1' ) ? 'target="_blank"' : '';
   if ($pre_text) {
     $pre_text = $pre_text.': ';
   } else {
    $pre_text = '';
   }
   if (isset( $info_text ) && !$info_link ) {
      $result = '<span class="'.$styled_class.'">'.$pre_text. $info_text .'</span>';
   } elseif (isset( $info_text ) && isset( $info_link )) {
      $result = '<span class="'.$styled_class.'">'.$pre_text.'<a href="'. $info_link .'" '. $target_tab .' >'.$info_text .'</a></span>';
   } else {
      $result = '';
   }

   return $result;
}
add_shortcode("footer_address_info", "footer_address_info_function");

/* Topbar Socials */
function grop_socials_function($atts, $content = true) {
   extract(shortcode_atts(array(
      "social_style" => '',
      "custom_class" => '',
      "icon_color" => '',
      "icon_size" => '',
      "icon_hover_color" => '',
      "align" => '',
      "ul_class" => ''
   ), $atts));

   if ($social_style === 'style-two') {
     $style_class = 'grop-footer-socail';
     $style_ul_class = '';
   } else {
     $style_class = 'grop-header_social';
     $style_ul_class = 'list-inline';
   }


  // Shortcode Style CSS
  $e_uniqid       = uniqid();
  $inline_style   = '';

  // Colors & Size
  if ( $icon_color || $icon_size || $icon_hover_color ) {
    $inline_style .= '.grop-socials-'. $e_uniqid .' a i {';
    $inline_style .= ( $icon_color ) ? 'color:'. $icon_color .';' : '';
    $inline_style .= ( $icon_size ) ? 'font-size:'. groppe_core_check_px($icon_size) .';' : '';
    $inline_style .= '}';
    $inline_style .= '.grop-socials-'. $e_uniqid .' a:hover i {';
    $inline_style .= ( $icon_color ) ? 'color:'. $icon_color .';' : '';
    $inline_style .= '}';
  }
  // add inline style
  add_inline_style( $inline_style );
  $styled_class  = ' grop-socials-'. $e_uniqid;
  $align = ( $align ) ? $align : 'right';
   $result = '<div class="text-'.esc_attr($align).' '.$inline_style . esc_attr($custom_class) .' '.esc_attr($style_class).'"><ul class="'.esc_attr( $ul_class ).' '.esc_attr($style_ul_class).'">'. do_shortcode($content) .'</ul></div>';
   return $result;

}
add_shortcode("grop_socials", "grop_socials_function");

/* Topbar Social */
function grop_social_function($atts, $content = NULL) {
   extract(shortcode_atts(array(
      "icon" => '',
      "link" => '',
      "target_tab" => ''
   ), $atts));


   $target_tab = ( $target_tab === '1' ) ? 'target="_blank"' : '';
   $icon = ( isset( $icon ) ) ? '<i class="'. $icon .'"></i>' : '';

   if ( !$link ) {
      $result = '<li>'. $icon .'</li>';
   } else {
      $result = '<li><a href="'. esc_url($link) .'" '. $target_tab .'>'.$icon .'</a></li>';
   }

   return $result;

}
add_shortcode("grop_social", "grop_social_function");



/* Text block */
function grop_text_shortcode($atts, $content = true) {
  extract(shortcode_atts(array(
    "wrap_tag" => '',
    "text" => '',
    "custom_class" => '',
  ), $atts));

  $result = '<'.$wrap_tag.' class="grop-txt-block '.esc_attr( $custom_class ).'">'.esc_html__($text, 'groppe-core').'</'.$wrap_tag.'>';

  return $result;
}
add_shortcode("grop_text_block", "grop_text_shortcode");



/* Image block */
function grop_images_shortcode($atts, $content = true) {
  extract(shortcode_atts(array(
    "column" => '',
    "custom_class" => '',
  ), $atts));

  $result = '<div class="'.esc_attr( $column.' '.$custom_class ).'">'.do_shortcode( $content ).'</div>';

  return $result;
}
add_shortcode("grop_images", "grop_images_shortcode");


/*Single Image*/
function grop_image_shortcode($atts, $content = true) {
  extract(shortcode_atts(array(
    "image" => '',
    "alt" => '',
  ), $atts));

  $image = wp_get_attachment_image_url( $image, 'full' );
  $result = '<img src="'.esc_url($image).'" alt="'.esc_attr($alt).'">';

  return $result;
}
add_shortcode("grop_image", "grop_image_shortcode");

/* Simple Underline Link */
function grop_simple_link_function($atts, $content = NULL) {
  extract(shortcode_atts(array(
    "link_style" => '',
    "link_icon" => '',
    "link_text" => '',
    "link" => '',
    "target_tab" => '',
    "custom_class" => '',
    // Normal
    "text_color" => '',
    "border_color" => '',
    // Hover
    "text_hover_color" => '',
    "border_hover_color" => '',
    // Size
    "text_size" => '',
  ), $atts));

  // Atts
  $target_tab = $target_tab ? 'target="_blank"' : '';
  if ($link_style === 'link-arrow-right') {
    $arrow_icon = $link_icon ? ' <i class="'. $link_icon .'"></i>' : ' <i class="fa fa-caret-right"></i>';
  } elseif ($link_style === 'link-arrow-left') {
    $arrow_icon = $link_icon ? ' <i class="'. $link_icon .'"></i>' : ' <i class="fa fa-caret-left"></i>';
  } else {
    $arrow_icon = '';
  }
  $link_style = $link_style ? $link_style. ' ' : 'link-underline ';

  // Shortcode Style CSS
  $e_uniqid       = uniqid();
  $inline_style   = '';

  // Colors & Size
  if ( $text_color || $text_size ) {
    $inline_style .= '.grop-simple-link-'. $e_uniqid .'.grop-'. $link_style .', .grop-simple-link-'. $e_uniqid .'.grop-link-arrow-left i, .grop-simple-link-'. $e_uniqid .'.grop-link-arrow-right i {';
    $inline_style .= ( $text_color ) ? 'color:'. $text_color .';' : '';
    $inline_style .= ( $text_size ) ? 'font-size:'. groppe_core_check_px($text_size) .';' : '';
    $inline_style .= '}';
  }
  if ( $text_hover_color ) {
    $inline_style .= '.grop-simple-link-'. $e_uniqid .'.grop-'. $link_style .':hover, .grop-simple-link-'. $e_uniqid .'.grop-link-arrow-right:hover, .grop-simple-link-'. $e_uniqid .'.grop-link-arrow-left:hover, .grop-simple-link-'. $e_uniqid .'.grop-link-arrow-right:hover i, .grop-simple-link-'. $e_uniqid .'.grop-link-arrow-left:hover i {';
    $inline_style .= ( $text_hover_color ) ? 'color:'. $text_hover_color .';' : '';
    $inline_style .= '}';
  }
  if ( $border_color ) {
    $inline_style .= '.grop-simple-link-'. $e_uniqid .'.grop-'. $link_style .':after {';
    $inline_style .= ( $border_color ) ? 'background-color:'. $border_color .';' : '';
    $inline_style .= '}';
  }
  if ( $border_hover_color ) {
    $inline_style .= '.grop-simple-link-'. $e_uniqid .'.grop-'. $link_style .':hover:after {';
    $inline_style .= ( $border_hover_color ) ? 'background-color:'. $border_hover_color .';' : '';
    $inline_style .= '}';
  }

  // add inline style
  add_inline_style( $inline_style );
  $styled_class  = ' grop-simple-link-'. $e_uniqid;

  $result = '<a href="'. $link .'" '. $target_tab .' class="grop-'. $link_style . $custom_class . $styled_class .'">'. $link_text . $arrow_icon .'</a>';
  return $result;

}
add_shortcode("grop_simple_link", "grop_simple_link_function");

/* Blockquote */
function grop_blockquote_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "blockquote_style" => '',
    "text_size" => '',
    "custom_class" => '',
    "content_color" => '',
    "left_color" => '',
    "border_color" => '',
    "bg_color" => ''
  ), $atts));

  // Shortcode Style CSS
  $e_uniqid        = uniqid();
  $inline_style  = '';

  // Text Color
  if ( $text_size || $content_color || $border_color || $bg_color ) {
    $inline_style .= '.grop-blockquote-'. $e_uniqid .' {';
    $inline_style .= ( $text_size ) ? 'font-size:'. $text_size .';' : '';
    $inline_style .= ( $content_color ) ? 'color:'. $content_color .';' : '';
    $inline_style .= ( $border_color ) ? 'border-color:'. $border_color .';' : '';
    $inline_style .= ( $bg_color ) ? 'background-color:'. $bg_color .';' : '';
    $inline_style .= '}';
  }
  if ( $left_color ) {
    $inline_style .= '.grop-blockquote-'. $e_uniqid .':before {';
    $inline_style .= ( $left_color ) ? 'background-color:'. $left_color .';' : '';
    $inline_style .= '}';
  }

  // add inline style
  add_inline_style( $inline_style );
  $styled_class  = ' grop-blockquote-'. $e_uniqid;

  // Style
  $blockquote_style = ($blockquote_style === 'style-two') ? 'blockquote-two ' : '';

  $result = '<blockquote class="'. $blockquote_style . $custom_class . $styled_class .'">'. do_shortcode($content) .'</blockquote>';
  return $result;

}
add_shortcode("grop_blockquote", "grop_blockquote_function");

/* List Styles Lists */
function vt_address_lists_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "custom_class" => '',
    // Colors
    "text_color" => '',
    "title_color" => '',
    // Size
    "text_size" => '',
    "title_size" => '',
  ), $atts));

  // Shortcode Style CSS
  $e_uniqid       = uniqid();
  $inline_style   = '';

  if ( $text_color || $text_size ) {
    $inline_style .= '.grop-list-'. $e_uniqid .' li {';
    $inline_style .= ( $text_color ) ? 'color:'. $text_color .';' : '';
    $inline_style .= ( $text_size ) ? 'font-size:'. groppe_core_check_px($text_size) .';' : '';
    $inline_style .= '}';
  }
  if ( $title_size || $title_color ) {
    $inline_style .= '.grop-list-'. $e_uniqid .'.grop-list-three li strong {';
    $inline_style .= ( $title_color ) ? 'color:'. $title_color .';' : '';
    $inline_style .= ( $title_size ) ? 'font-size:'. groppe_core_check_px($title_size) .';' : '';
    $inline_style .= '}';
  }

  // add inline style
  add_inline_style( $inline_style );
  $styled_class  = ' grop-list-'. $e_uniqid;

  // Output
  $output = '';

  $output .= '<ul class="grop-list-three '. $custom_class . $styled_class .'">';
  $output .= do_shortcode($content);
  $output .= '</ul>';

  return $output;

}

/* Current Year - Shortcode */
if( ! function_exists( 'grop_current_year' ) ) {
  function grop_current_year() {
    return date('Y');
  }
  add_shortcode( 'grop_current_year', 'grop_current_year' );
}

/* Get Home Page URL - Via Shortcode */
if( ! function_exists( 'grop_home_url' ) ) {
  function grop_home_url() {
    return esc_url( home_url( '/' ) );
  }
  add_shortcode( 'grop_home_url', 'grop_home_url' );
}
<?php
/*
 * Recent Post Widget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

class groppe_events_photos extends WP_Widget {

  /**
   * Specifies the widget name, description, class name and instatiates it
   */
  public function __construct() {
    parent::__construct(
      'grop-events-photos',
      VTHEME_NAME_P . __( ': Events Photos', 'groppe' ),
      array(
        'classname'   => 'grop-events-photos',
        'description' => VTHEME_NAME_P . __( ' widget that displays events photos.', 'groppe' )
      )
    );
  }

  /**
   * Generates the back-end layout for the widget
   */
  public function form( $instance ) {
    // Default Values
    $instance   = wp_parse_args( $instance, array(
      'title'    => __( 'Events Photos', 'groppe' ),
      'ptypes'   => 'post',
      'limit'    => '3',
      'order' => '',
      'orderby' => '',
    ));

    // Title
    $title_value = esc_attr( $instance['title'] );
    $title_field = array(
      'id'    => $this->get_field_name('title'),
      'name'  => $this->get_field_name('title'),
      'type'  => 'text',
      'title' => __( 'Title :', 'groppe' ),
      'wrap_class' => 'vt-cs-widget-fields',
    );
    echo cs_add_element( $title_field, $title_value );

    // Post Type
    $ptypes_value = esc_attr( $instance['ptypes'] );
    $ptypes_field = array(
      'id'    => $this->get_field_name('ptypes'),
      'name'  => $this->get_field_name('ptypes'),
      'type' => 'select',
      'options' => 'post_types',
      'default_option' => __( 'Select Post Type', 'groppe' ),
      'title' => __( 'Post Type :', 'groppe' ),
    );
    echo cs_add_element( $ptypes_field, $ptypes_value );

    // Limit
    $limit_value = esc_attr( $instance['limit'] );
    $limit_field = array(
      'id'    => $this->get_field_name('limit'),
      'name'  => $this->get_field_name('limit'),
      'type'  => 'text',
      'title' => __( 'Limit :', 'groppe' ),
      'help' => __( 'How many posts want to show?', 'groppe' ),
    );
    echo cs_add_element( $limit_field, $limit_value );

    // Order
    $order_value = esc_attr( $instance['order'] );
    $order_field = array(
      'id'    => $this->get_field_name('order'),
      'name'  => $this->get_field_name('order'),
      'type' => 'select',
      'options'   => array(
        'ASC' => 'Ascending',
        'DESC' => 'Descending',
      ),
      'default_option' => __( 'Select Order', 'groppe' ),
      'title' => __( 'Order :', 'groppe' ),
    );
    echo cs_add_element( $order_field, $order_value );

    // Orderby
    $orderby_value = esc_attr( $instance['orderby'] );
    $orderby_field = array(
      'id'    => $this->get_field_name('orderby'),
      'name'  => $this->get_field_name('orderby'),
      'type' => 'select',
      'options'   => array(
        'none' => __('None', 'groppe'),
        'ID' => __('ID', 'groppe'),
        'author' => __('Author', 'groppe'),
        'title' => __('Title', 'groppe'),
        'name' => __('Name', 'groppe'),
        'type' => __('Type', 'groppe'),
        'date' => __('Date', 'groppe'),
        'modified' => __('Modified', 'groppe'),
        'rand' => __('Random', 'groppe'),
      ),
      'default_option' => __( 'Select OrderBy', 'groppe' ),
      'title' => __( 'OrderBy :', 'groppe' ),
    );
    echo cs_add_element( $orderby_field, $orderby_value );

  }

  /**
   * Processes the widget's values
   */
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;

    // Update values
    $instance['title']        = strip_tags( stripslashes( $new_instance['title'] ) );
    $instance['ptypes']       = strip_tags( stripslashes( $new_instance['ptypes'] ) );
    $instance['limit']        = strip_tags( stripslashes( $new_instance['limit'] ) );
    $instance['order']        = strip_tags( stripslashes( $new_instance['order'] ) );
    $instance['orderby']      = strip_tags( stripslashes( $new_instance['orderby'] ) );

    return $instance;
  }

  /**
   * Output the contents of the widget
   */
  public function widget( $args, $instance ) {
    // Extract the arguments
    extract( $args );

    $title          = apply_filters( 'widget_title', $instance['title'] );
    $ptypes         = $instance['ptypes'];
    $limit          = $instance['limit'];
    $order          = $instance['order'];
    $orderby        = $instance['orderby'];

    $args = array(
      // other query params here,
      'post_type' => esc_attr($ptypes),
      'posts_per_page' => (int)$limit,
      'orderby' => esc_attr($orderby),
      'order' => esc_attr($order),
      'ignore_sticky_posts' => 1,
     );

     $groppe_rpw = new WP_Query( $args );
     global $post;

    // Display the markup before the widget
    echo $before_widget;
    echo '<aside class="grop-side-widget">';

    if ( $title ) {
      echo $before_title . $title . $after_title;
    }

    echo '<div class="grop-evpho_wigt_warp"><ul class="grop-fix  grop-list_unstyled">';

    if ($groppe_rpw->have_posts()) : while ($groppe_rpw->have_posts()) : $groppe_rpw->the_post();
  ?>
  <li>
  <?php
      $riffel_post_imgg = wp_get_attachment_image_src( get_post_thumbnail_id(), 'fullsize', false, '' );
      $riffel_post_imgg = $riffel_post_imgg[0];
      if(class_exists('Aq_Resize')) {
        $riffel_post_img = aq_resize( $riffel_post_imgg, '70', '70', true );
      } else {
        $riffel_post_img = $riffel_post_imgg;
      }
      if($riffel_post_img){
        $riffel_post_img_actual = '<img src="'.esc_url($riffel_post_img).'" alt="'.get_the_title().'">';
      } else {
        $riffel_post_img_actual = '';
      }
    ?>
    <a href="<?php the_permalink(); ?>"><?php echo $riffel_post_img_actual; ?></a>
  </li>

  <?php
    endwhile; endif;
    echo '</ul></div></aside>';
    wp_reset_postdata();
    // Display the markup after the widget
    echo $after_widget;
  }
}

// Register the widget using an annonymous function
add_action( 'widgets_init', create_function( '', 'register_widget( "groppe_events_photos" );' ) );
<?php
/*
 * Recent Post Widget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

class groppe_urgent_causes extends WP_Widget {

  /**
   * Specifies the widget name, description, class name and instatiates it
   */
  public function __construct() {
    parent::__construct(
      'grop-urgent-cause',
      VTHEME_NAME_P . __( ': Urgent Causes', 'groppe' ),
      array(
        'classname'   => 'grop-urgent-cause',
        'description' => VTHEME_NAME_P . __( ' widget that displays Urgent Causes.', 'groppe' )
      )
    );
  }

  /**
   * Generates the back-end layout for the widget
   */
  public function form( $instance ) {
    // Default Values
    $instance   = wp_parse_args( $instance, array(
      'title'    => __( 'Urgent Causes', 'groppe' ),
      'ptypes'   => 'give_forms',
      'limit'    => '3',
      'order' => '',
      'orderby' => '',
    ));

    // Title
    $title_value = esc_attr( $instance['title'] );
    $title_field = array(
      'id'    => $this->get_field_name('title'),
      'name'  => $this->get_field_name('title'),
      'type'  => 'text',
      'title' => __( 'Title :', 'groppe' ),
      'wrap_class' => 'vt-cs-widget-fields',
    );
    echo cs_add_element( $title_field, $title_value );

    // Limit
    $limit_value = esc_attr( $instance['limit'] );
    $limit_field = array(
      'id'    => $this->get_field_name('limit'),
      'name'  => $this->get_field_name('limit'),
      'type'  => 'text',
      'title' => __( 'Limit :', 'groppe' ),
      'help' => __( 'How many posts want to show?', 'groppe' ),
    );
    echo cs_add_element( $limit_field, $limit_value );

    // Order
    $order_value = esc_attr( $instance['order'] );
    $order_field = array(
      'id'    => $this->get_field_name('order'),
      'name'  => $this->get_field_name('order'),
      'type' => 'select',
      'options'   => array(
        'ASC' => 'Ascending',
        'DESC' => 'Descending',
      ),
      'default_option' => __( 'Select Order', 'groppe' ),
      'title' => __( 'Order :', 'groppe' ),
    );
    echo cs_add_element( $order_field, $order_value );

    // Orderby
    $orderby_value = esc_attr( $instance['orderby'] );
    $orderby_field = array(
      'id'    => $this->get_field_name('orderby'),
      'name'  => $this->get_field_name('orderby'),
      'type' => 'select',
      'options'   => array(
        'none' => __('None', 'groppe'),
        'ID' => __('ID', 'groppe'),
        'author' => __('Author', 'groppe'),
        'title' => __('Title', 'groppe'),
        'name' => __('Name', 'groppe'),
        'type' => __('Type', 'groppe'),
        'date' => __('Date', 'groppe'),
        'modified' => __('Modified', 'groppe'),
        'rand' => __('Random', 'groppe'),
      ),
      'default_option' => __( 'Select OrderBy', 'groppe' ),
      'title' => __( 'OrderBy :', 'groppe' ),
    );
    echo cs_add_element( $orderby_field, $orderby_value );

  }

  /**
   * Processes the widget's values
   */
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;

    // Update values
    $instance['title']        = strip_tags( stripslashes( $new_instance['title'] ) );
    $instance['limit']        = strip_tags( stripslashes( $new_instance['limit'] ) );
    $instance['order']        = strip_tags( stripslashes( $new_instance['order'] ) );
    $instance['orderby']      = strip_tags( stripslashes( $new_instance['orderby'] ) );

    return $instance;
  }

  /**
   * Output the contents of the widget
   */
  public function widget( $args, $instance ) {
    // Extract the arguments
    extract( $args );

    $title          = apply_filters( 'widget_title', $instance['title'] );
    $limit          = $instance['limit'];
    $order          = $instance['order'];
    $orderby        = $instance['orderby'];

    $args = array(
      // other query params here,
      'post_type'   => 'give_forms',
      'posts_per_page' => (int)$limit,
      'orderby' => esc_attr($orderby),
      'order' => esc_attr($order),
     );

     $groppe_rpw = new WP_Query( $args );
     global $post;

    // Display the markup before the widget
    echo $before_widget;

    if ( $title ) {
      echo $before_title . $title . $after_title;
    }

    echo '<ul class="grop-fix  grop-urgent-cause-list">';

    if ($groppe_rpw->have_posts()) : while ($groppe_rpw->have_posts()) : $groppe_rpw->the_post();
      $form        = new Give_Donate_Form( get_the_ID() );
      $goal_option = get_post_meta( get_the_ID(), '_give_goal_option', true );
      $goal        = $form->goal;
      $goal_format = get_post_meta( get_the_ID(), '_give_goal_format', true );
      $income      = $form->get_earnings();
      $color       = get_post_meta( get_the_ID(), '_give_goal_color', true );
      //Sanity check - ensure form has goal set to output
      if ( empty( $form->ID ) || ( is_singular( 'give_forms' ) && ! give_is_setting_enabled( $goal_option ) ) || ! give_is_setting_enabled( $goal_option ) || $goal == 0 ) {
        return false;
      }
      $progress = round( ( $income / $goal ) * 100, 2 );
      if ( $income >= $goal ) {
        $progress = 100;
      }
      $customer_id = give_get_payment_donor_id( get_the_ID() );
      $income = give_human_format_large_amount( give_format_amount( $income ) );
      $goal = give_human_format_large_amount( give_format_amount( $goal ) );
      $payment_mode = give_get_chosen_gateway( get_the_ID() );
      $form_action = add_query_arg( apply_filters( 'give_form_action_args', array( 'payment-mode' => $payment_mode, ) ),  give_get_current_page_url() );
      // remaining date
      $dead_line = get_post_meta( get_the_ID(), '_donation_form_metabox', true ); 
      $donation_deadline = $dead_line['donation_deadline']; 
      $deadline = str_replace('/', '-', $donation_deadline);
      $deadline = date('F d, Y', strtotime($deadline));

      $date = strtotime($deadline);
      $remaining = $date - time();

      $days_remaining = floor($remaining / 86400);
      $hours_remaining = floor(($remaining % 86400) / 3600);
      $display_label_field = get_post_meta( get_the_ID(), '_give_checkout_label', true );
      $display_label       = ( ! empty( $display_label_field ) ? $display_label_field : esc_html__( 'Donate Now', 'groppe' ) );
  ?>
  <li>
    <div class="grop-progress-circular">
      <input type="text" class="grop-knob" value="0" data-rel="<?php echo esc_attr( $progress ); ?>" data-linecap="square" data-width="62" data-bgcolor="#E4E4E4" data-fgcolor="#F0C84C" data-thickness=".15" data-readonly="true"  data-height="62">
    </div>
    <div class="urgent-cause-cnt">
      <a class="urgent-cause-title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
      <div class="grop-cause_time">
        <i class="fa fa-clock-o"></i><?php echo $days_remaining.' '.esc_html__('Days Left', 'groppe-core'); ?>
      </div>
    </div>  
  </li>

  <?php
    endwhile; endif;
    echo '</ul>';
    wp_reset_postdata();
    // Display the markup after the widget
    echo $after_widget;
  }
}

// Register the widget using an annonymous function
add_action( 'widgets_init', create_function( '', 'register_widget( "groppe_urgent_causes" );' ) );
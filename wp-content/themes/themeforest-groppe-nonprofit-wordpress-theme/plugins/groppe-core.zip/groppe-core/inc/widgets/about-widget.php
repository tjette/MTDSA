<?php
/*
 * AboutWidget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

class grop_about_widget extends WP_Widget {

  /**
   * Specifies the widget name, description, class name and instatiates it
   */
  public function __construct() {
    parent::__construct(
      'about-widget',
      VTHEME_NAME_P . esc_html__( ': About Logo', 'groppe' ),
      array(
        'classname'   => 'vt-text-widget',
        'description' => VTHEME_NAME_P . esc_html__( ' widget that displays contents.', 'groppe' )
      )
    );
  }

  /**
   * Generates the back-end layout for the widget
   */
  public function form( $instance ) {
    // Default Values
    $instance   = wp_parse_args( $instance, array(
      'title'    => '',
      'logo' => '',
      'logo_url' => '',
    ));

    // Content
    $logo_value = esc_attr( $instance['logo'] );
    $logo_field = array(
      'id'    => $this->get_field_name('logo'),
      'name'  => $this->get_field_name('logo'),
      'type'  => 'image',
      'title' => esc_html__( 'Upload Logo :', 'groppe' ),
    );
    echo cs_add_element( $logo_field, $logo_value );

    // Logo URL
    $logo_url_value = esc_attr( $instance['logo_url'] );
    $logo_url_field = array(
      'id'    => $this->get_field_name('logo_url'),
      'name'  => $this->get_field_name('logo_url'),
      'type'  => 'text',
      'logo_url' => esc_html__( 'Logo URL :', 'groppe' ),
      'wrap_class' => 'vt-cs-widget-fields',
    );
    echo cs_add_element( $logo_url_field, $logo_url_value );
  }

  /**
   * Processes the widget's values
   */
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;

    // Update values
    $instance['title']      = strip_tags( stripslashes( $new_instance['title'] ) );
    $instance['logo_url']      = strip_tags( stripslashes( $new_instance['logo_url'] ) );
    $instance['logo']    = strip_tags( stripslashes( $new_instance['logo'] ) );

    return $instance;
  }

  /**
   * Output the contents of the widget
   */
  public function widget( $args, $instance ) {
    // Extract the arguments
    extract( $args );

    $title      = apply_filters( 'widget_title', $instance['title'] );
    $logo    = $instance['logo'];
    $logo_url    = $instance['logo_url'];
    $content    = $instance['content'];

    // Display the markup before the widget
    echo $before_widget;

    if ( $title ) {
      echo $before_title . $title . $after_title;
    }
    if ($logo) {
      $logo = wp_get_attachment_url( $logo );
      if ($logo_url) {
        echo '<a class="grop-ftr_logo" href="'.esc_url($logo_url).'"><img src="'.esc_url( $logo ).'" alt="#" /></a>';
      } else {
        echo '<img class="grop-ftr_logo" src="'.esc_url( $logo ).'" alt="#" />';
      }
    }


    // Display the markup after the widget
    echo $after_widget;
  }
}

// Register the widget using an annonymous function
add_action( 'widgets_init', create_function( '', 'register_widget( "grop_about_widget" );' ) );
<?php
/*
 * Recent Post Widget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

class groppe_categories extends WP_Widget {

  /**
   * Specifies the widget name, description, class name and instatiates it
   */
  public function __construct() {
    parent::__construct(
      'grop-cause-categories',
      VTHEME_NAME_P . __( ': Cause Categories', 'groppe' ),
      array(
        'classname'   => 'grop-cause-categories',
        'description' => VTHEME_NAME_P . __( ' widget that displays events photos.', 'groppe' )
      )
    );
  }

  /**
   * Generates the back-end layout for the widget
   */
  public function form( $instance ) {
    // Default Values
    $instance   = wp_parse_args( $instance, array(
      'title'    => __( 'Cause Categories', 'groppe' ),
      'ptypes'   => 'post',
      'limit'    => '-1',
      'order' => '',
      'orderby' => '',
    ));

    // Title
    $title_value = esc_attr( $instance['title'] );
    $title_field = array(
      'id'    => $this->get_field_name('title'),
      'name'  => $this->get_field_name('title'),
      'type'  => 'text',
      'title' => __( 'Title :', 'groppe' ),
      'wrap_class' => 'vt-cs-widget-fields',
    );
    echo cs_add_element( $title_field, $title_value );

  }

  /**
   * Processes the widget's values
   */
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;

    // Update values
    $instance['title']        = strip_tags( stripslashes( $new_instance['title'] ) );

    return $instance;
  }

  /**
   * Output the contents of the widget
   */
  public function widget( $args, $instance ) {
    // Extract the arguments
    extract( $args );

    $title          = apply_filters( 'widget_title', $instance['title'] );

    $args = array(
      // other query params here,
      'post_type' => 'give_forms',
      'taxonomy'     => 'give_forms_category',
      'ignore_sticky_posts' => 1,
     );

     $groppe_rpw = new WP_Query( $args );
     global $post;

    // Display the markup before the widget
    echo $before_widget;
    echo '<aside class="grop-side-widget widget_categories">';

    if ( $title ) {
      echo $before_title . $title . $after_title;
    }

    echo '<ul>';  

      $categories = get_categories( $args );
      foreach ( $categories as $category ) {
        echo '<li><a href="' . get_category_link( $category->term_id ) . '" rel="bookmark">' . $category->name . '' . $category->description . '</a></li>'; 
      }

    echo '</ul></aside>';
    wp_reset_postdata();
    // Display the markup after the widget
    echo $after_widget;
  }
}

// Register the widget using an annonymous function
add_action( 'widgets_init', create_function( '', 'register_widget( "groppe_categories" );' ) );
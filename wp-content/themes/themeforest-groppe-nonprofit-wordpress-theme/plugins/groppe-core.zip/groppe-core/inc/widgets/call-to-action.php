<?php
/*
 * Reserver Seat Widget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

class vt_call_to_action_widget extends WP_Widget {

  /**
   * Specifies the widget name, description, class name and instatiates it
   */
  public function __construct() {
    parent::__construct(
      'vt-call-to-action-widget',
      VTHEME_NAME_P . __( ': Call To Action Widget', 'groppe-core' ),
      array(
        'classname'   => 'vt-call-to-action-widget',
        'description' => VTHEME_NAME_P . __( ' widget that displays Call to action.', 'groppe-core' )
      )
    );
  }

  /**
   * Generates the back-end layout for the widget
   */
  public function form( $instance ) {
    // Default Values
    $instance   = wp_parse_args( $instance, array(
      'title'    => '',
      'icon' => '',
      'btn_txt' => '',
      'btn_link' => '',
    ));

    // Title
    $title_value = esc_attr( $instance['title'] );
    $title_field = array(
      'id'    => $this->get_field_name('title'),
      'name'  => $this->get_field_name('title'),
      'type'  => 'textarea',
      'title' => __( 'Text :', 'groppe-core' ),
      'wrap_class' => 'vt-reserve-widgt-fields',
    );
    echo cs_add_element( $title_field, $title_value );

    // Sub Title
    $icon_value = esc_attr( $instance['icon'] );
    $icon_field = array(
      'id'    => $this->get_field_name('icon'),
      'name'  => $this->get_field_name('icon'),
      'type'  => 'image',
      'title' => __( 'Icon :', 'groppe-core' ),
    );
    echo cs_add_element( $icon_field, $icon_value );

    // Button Text
    $btn_txt_value = esc_attr( $instance['btn_txt'] );
    $btn_txt_field = array(
      'id'    => $this->get_field_name('btn_txt'),
      'name'  => $this->get_field_name('btn_txt'),
      'type'  => 'text',
      'title' => __( 'Buttom Text :', 'groppe-core' ),
    );
    echo cs_add_element( $btn_txt_field, $btn_txt_value );

    // Button Text
    $btn_link_value = esc_attr( $instance['btn_link'] );
    $btn_link_field = array(
      'id'    => $this->get_field_name('btn_link'),
      'name'  => $this->get_field_name('btn_link'),
      'type'  => 'text',
      'title' => __( 'Buttom Link :', 'groppe-core' ),
    );
    echo cs_add_element( $btn_link_field, $btn_link_value );

  }

  /**
   * Processes the widget's values
   */
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;

    // Update values
    $instance['title']      = strip_tags( stripslashes( $new_instance['title'] ) );
    $instance['icon']      = strip_tags( stripslashes( $new_instance['icon'] ) );
    $instance['btn_txt']    = strip_tags( stripslashes( $new_instance['btn_txt'] ) );
    $instance['btn_link']    = strip_tags( stripslashes( $new_instance['btn_link'] ) );

    return $instance;
  }

  /**
   * Output the contents of the widget
   */
  public function widget( $args, $instance ) {
    // Extract the arguments
    extract( $args );

    $title      = apply_filters( 'widget_title', $instance['title'] );
    $icon    = $instance['icon'];
    $btn_txt    = $instance['btn_txt'];
    $btn_link    = $instance['btn_link'];

    if ($icon) {
      $icon = wp_get_attachment_url( $icon );
    }

    echo '<section class="grop-callout_area team_cal_out"><div class="grop-vertical_middle  grop-fix container grop-callout_container"><div class="grop-float_right grop-callout_btn_warp"><a class="grop-btn grop-btn_overly grop-callout_btn" href="'.$instance['btn_link'].'"><span>'.$instance['btn_txt'].'</span></a></div><div class="grop-float_left  grop-callout_txt_warp"><div class="grop-callout_icon"><img src="'.esc_url($icon).'" alt="" /></div> <p>'.$instance['title'].'</p></div></div></section>';

  }
}

// Register the widget using an annonymous function
add_action( 'widgets_init', create_function( '', 'register_widget( "vt_call_to_action_widget" );' ) );

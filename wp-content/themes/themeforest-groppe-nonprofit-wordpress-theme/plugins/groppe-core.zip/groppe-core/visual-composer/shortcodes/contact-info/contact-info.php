<?php
/* ==========================================================
  Contact Adress
=========================================================== */
if ( !function_exists('contact_address_func')) {
  function contact_address_func( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'title'  => '',
      'description'  => '',
      'items'  => '',
      'class'  => '',
      'section_class'  => '',
    ), $atts));
    $addresses = (array) vc_param_group_parse_atts( $items );
    $get_contact_address = array();
    foreach ( $addresses as $addresses_info ) {
      $each_item = $addresses_info;
      $each_item['prefix'] = $addresses_info['prefix'] ? $addresses_info['prefix'] : '';
      $each_item['address_title'] = $addresses_info['address_title'] ? $addresses_info['address_title'] : '';
      $each_item['url'] = $addresses_info['url'] ? $addresses_info['url'] : '';
      $get_contact_address[] = $each_item;
    }
    ob_start();
  if ($description) {
    $description =  nl2br( $description, false );
  } else {
    $description =  '';
  }
?>
<div class="grop-cgettouch_info <?php echo esc_attr( $section_class ); ?>">
  <?php
    if ($title) {
      echo '<h4>'.$title.'</h4>';
    }
  ?>
  <address class="grop-cgettouch_locn <?php echo esc_attr( $class ); ?>">
    <?php
    if ($description) {
      echo '<p>'.$description.'</p>';
    }
    foreach ( $get_contact_address as $each_item ) {
      $address_title = $each_item['address_title'];
      $url = $each_item['url'];
      $prefix = $each_item['prefix'];
      if ( !empty($prefix) ) {
        $prefix = $prefix.':';
      } else {
        $prefix = '';
      }
      if ( !empty($url) && !empty($address_title) ) {
        echo '<span>'.$prefix.'<a href="'.$url.'">'.$address_title.'</a></span>';
      } else {
        echo '<span>'.$prefix.''.$address_title.'</span>';
      }
    } ?>
  </address>
</div>
<?php
    return ob_get_clean();
  }
}
add_shortcode( 'contact_address', 'contact_address_func' );

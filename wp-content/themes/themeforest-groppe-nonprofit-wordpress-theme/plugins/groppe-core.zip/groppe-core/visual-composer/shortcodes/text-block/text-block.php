<?php
/* ===========================================================
    Button
=========================================================== */
if ( !function_exists('groppe_text_block_function')) {
  function groppe_text_block_function( $atts, $content = NULL ) {
    extract(shortcode_atts(array(
      "text_tag" => '',
      "text_content" => '',
      // styles
      "text_align"  => '',
      "text_size" => '',
      "text_color" => '',
      "text_bottom_space" => '',
      "text_line_height"  => '',

      "class" => '',
      "css" => '',
    ), $atts));
   // Shortcode Style CSS
    $custom_css = ( function_exists( 'vc_shortcode_custom_css_class' ) ) ? vc_shortcode_custom_css_class( $css, ' ' ) : '';
    $text_tag = $text_tag ? $text_tag : 'div';
    $e_uniqid       = uniqid();
    $inline_style   = '';
    
      if ($text_size){
        $txt_id = '-'.$text_size;
      } else {
        $txt_id = '';
      }
      if ($text_color) {
        $color = str_replace("#","",$text_color);
        $txt_clr = '-'.$color;
      } else {
        $txt_clr = '';
      }

    // Text
    if ( $text_color || $text_size || $text_bottom_space || $text_line_height ) {
      $inline_style .= '.grop-txt-block-'. $e_uniqid.$txt_id.$txt_clr.'{';
      $inline_style .= ( $text_color ) ? 'color:'. $text_color .';' : '';
      $inline_style .= ( $text_size ) ? 'font-size:'. groppe_core_check_px($text_size) .';' : '';
      $inline_style .= ( $text_bottom_space ) ? 'padding-bottom:'. groppe_core_check_px($text_bottom_space) .';' : '';
      $inline_style .= ( $text_line_height ) ? 'line-height:'. groppe_core_check_px($text_line_height) .';' : '';
      $inline_style .= '}';
    }
    

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-txt-block-'. $e_uniqid.$txt_id.$txt_clr.'';

    $text_align = $text_align ? $text_align : 'text-center';
    
    // Output  
    $result = '';

    $result .= '<'.$text_tag.' class="grop-txt-blck '.esc_attr( $styled_class.' '.$custom_css.' '.$text_align).'">'.$text_content.'</'.$text_tag.'>';

    return $result; 
  }
}
add_shortcode( 'groppe_text_block', 'groppe_text_block_function' );

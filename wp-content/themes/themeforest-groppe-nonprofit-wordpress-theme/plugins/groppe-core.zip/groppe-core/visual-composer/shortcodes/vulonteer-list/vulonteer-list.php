<?php
/* ==========================================================
  Vulonteers
=========================================================== */
if ( !function_exists('grop_vulonteers_function')) {
  function grop_vulonteers_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'vulonteer_items'  => '',
      'class'  => '',

      // Style
      'title_color'  => '',
      'title_size'  => '',
      'title_hover_color' => '',
      'content_color'  => '',
      'content_size'  => '',
    ), $atts));

    $vulonteer_items = (array) vc_param_group_parse_atts( $vulonteer_items );
    $get_each_vulonteer = array();
    foreach ( $vulonteer_items as $vulonteer_item ) {
      $each_vulonteer = $vulonteer_item;
      $each_vulonteer['icon'] = isset( $vulonteer_item['icon'] ) ? $vulonteer_item['icon'] : '';
      $each_vulonteer['link'] = isset( $vulonteer_item['link'] ) ? $vulonteer_item['link'] : '';
      $each_vulonteer['title'] = isset( $vulonteer_item['title'] ) ? $vulonteer_item['title'] : '';
      $each_vulonteer['desc'] = isset( $vulonteer_item['desc'] ) ? $vulonteer_item['desc'] : '';
      $each_vulonteer['open_link'] = isset( $vulonteer_item['open_link'] ) ? $vulonteer_item['open_link'] : '';
      $get_each_vulonteer[] = $each_vulonteer;
    }
    // Style
    
    $e_uniqid        = uniqid();
    $inline_style  = '';
    // Name Color
    if ( $title_color || $title_size ) {
      $inline_style .= '.grop-vulonteer-'. $e_uniqid .'.grop-bvlist_text h4, .grop-vulonteer-'. $e_uniqid .'.grop-bvlist_text h4 a{';
      $inline_style .= ( $title_color ) ? 'color:'. $title_color .';' : '';
      $inline_style .= ( $title_size ) ? 'font-size:'. groppe_core_check_px($title_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $title_hover_color) {
      $inline_style .= '.grop-vulonteer-'. $e_uniqid .'.grop-bvlist_text h4:hover, .grop-vulonteer-'. $e_uniqid .'.grop-bvlist_text h4 a:hover{';
      $inline_style .= ( $title_hover_color ) ? 'color:'. $title_hover_color .';' : '';
      $inline_style .= '}';
    }
    if ( $content_color || $content_size ) {
      $inline_style .= '.grop-vulonteer-'. $e_uniqid .'.grop-bvlist_text p{';
      $inline_style .= ( $content_color ) ? 'color:'. $content_color .';' : '';
      $inline_style .= ( $content_size ) ? 'font-size:'. groppe_core_check_px($content_size) .';' : '';
      $inline_style .= '}';
    }


    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-vulonteer-'. $e_uniqid;

  ob_start(); ?>
  <div class="grop-bvtxt_list <?php echo esc_attr( $class ); ?>">
  <?php 
    foreach ( $get_each_vulonteer as $each_vulonteer ) { 
      $open_link = $each_vulonteer['open_link'] ? 'target="_blank"' : ''; 
      $link = $each_vulonteer['link'];
      $title = $each_vulonteer['title'];
      $desc = $each_vulonteer['desc'];
      $icon = wp_get_attachment_url( $each_vulonteer['icon'] ); ?>
      <div class="grop-fix grop-bvlist_single">
        <div class="grop-float_left  grop-bvlist_icon">
          <img src="<?php echo esc_url( $icon ); ?>" alt="<?php echo esc_attr( $title ); ?>" />
        </div>
        <div class="grop-fix  grop-bvlist_text">
          <?php
            if ($link) {
              echo '<h4><a href="'.$link.'" '.$open_link.'>'.$title.'</a></h4>';
            } else {
              echo '<h4>'.$title.'</h4>';
            }
            if ($desc) {
              echo '<p>'.$desc.'</p>';
            }
          ?>
        </div>
      </div>
  <?php } ?>
  </div>
<?php
 
    return ob_get_clean();
  }
}
add_shortcode( 'grop_vulonteers', 'grop_vulonteers_function' );

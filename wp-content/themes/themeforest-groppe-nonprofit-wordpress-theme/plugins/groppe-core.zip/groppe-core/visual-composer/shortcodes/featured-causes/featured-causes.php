<?php
/* ==========================================================
  Causes
=========================================================== */
if ( !function_exists('grop_featured_causes_function')) {
  function grop_featured_causes_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'class'  => '',
      'show_cause'  => '',
    ), $atts));

    $short_content = '25';

  // Turn output buffer on
  ob_start(); ?>
  <!-- Causes Start -->
  <section class="grop-fix grop-featured_causes_area <?php echo esc_attr( $class ); ?>">
    <?php
    $args = array(
      'post_type' => 'give_forms',
      'post_status' => 'publish',
      'posts_per_page' => 1,
      'orderby' => 'none',
      'order' => 'DESC',
      'post__in' => (array) $show_cause,
    );
    $grop_cas = new WP_Query( $args ); ?>

      <?php
      if ($grop_cas->have_posts()) : while ($grop_cas->have_posts()) : $grop_cas->the_post();

        // Featured Image
        $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
        if ($large_image) {
          $featured_img = $large_image[0];
        } else {
          $featured_img = GROPPE_PLUGIN_ASTS . '/images/1000x800.jpg';
        }

        $form        = new Give_Donate_Form( get_the_ID() );
        $goal_option = get_post_meta( get_the_ID(), '_give_goal_option', true );
        $goal        = $form->goal;
        $goal_format = get_post_meta( get_the_ID(), '_give_goal_format', true );
        $income      = $form->get_earnings();
        //Sanity check - ensure form has goal set to output
        if ( empty( $form->ID ) || ( is_singular( 'give_forms' ) && ! give_is_setting_enabled( $goal_option ) ) || ! give_is_setting_enabled( $goal_option ) || $goal == 0 ) {
          return false;
        }
        $income = give_human_format_large_amount( give_format_amount( $income ) );
        $goal = give_human_format_large_amount( give_format_amount( $goal ) );
        
        $button_label       = ( ! empty( $display_label_field ) ? $display_label_field : esc_html__( 'Donate To Cause', 'groppe' ) );
        ?>

        <div class="col-md-6  col-sm-12 grop-fetrd_cause_image">
          <img src="<?php echo esc_url( $featured_img ); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" />
        </div>
        
        <div class="col-md-6  col-sm-12  grop-fetrd_cause_cont">
          <h2 class="grop-fetrd_cause_title">Education to Every Children</h2>
          <div class="grop-fetrdcs_dnt_stats">
            <?php echo __('Raised: <span class="grop-rasd_amount">'.apply_filters( 'give_goal_amount_raised_output', give_currency_filter( $income ) ).'</span>', 'groppe'); ?> / <?php echo __('Goal: '.apply_filters( 'give_goal_amount_target_output', give_currency_filter( $goal ) ), 'groppe'); ?>
          </div>
          <p>
            <?php 
              if (groppe_framework_active()) {
                groppe_excerpt($short_content);
              } else {
                the_excerpt();
              }
            ?>
          </p>
          <a class="grop-btn grop-btn_overly grop-fetrdcs_dnt_btn" href="<?php echo esc_url( get_the_permalink() ); ?>"><span><?php echo $button_label; ?></span></a>
        </div>
      <?php
      endwhile;
      endif;
      wp_reset_postdata(); ?>
  </section>
    <?php
    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'grop_featured_causes', 'grop_featured_causes_function' );

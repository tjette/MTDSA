<?php
/**
 * Donation Progress - Shortcode Options
 */
add_action( 'init', 'grop_donation_progress_vc_map' );
if ( ! function_exists( 'grop_donation_progress_vc_map' ) ) {
  function grop_donation_progress_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Donation Progress", 'groppe-core'),
      "base" => "grop_donation_progress",
      "description" => esc_html__( "Donation Progress Styles", 'groppe-core'),
      "icon" => "fa fa-line-chart color-red",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Target Amount", 'groppe-core' ),
          "param_name" => "target_amount",
          'value' => '',
        ),
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Raised Amount", 'groppe-core' ),
          "param_name" => "raised_amount",
          'value' => '',
        ),
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Curency", 'groppe-core' ),
          "param_name" => "curency",
          'value' => '',
        ),

        GroppeLib::vt_class_option(),
      )
    ) );
  }
}

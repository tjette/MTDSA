<?php
/**
 * Accordion - Shortcode Options
 */

add_action( 'init', 'grop_accordion_vc_map' );
if ( ! function_exists( 'grop_accordion_vc_map' ) ) {
  function grop_accordion_vc_map() {

    vc_map( array(
      'name'            => esc_html__( 'Groppe Accordion', 'groppe-core'),
      'base'            => 'vc_accordion',
      'is_container'    => true,
      'description'     => esc_html__( 'Accordion Styles', 'groppe-core'),
      'icon'            => 'fa fa-bars color-pink',
      'category'        => GroppeLib::grop_cat_name(),
      'params'          => array(
        GroppeLib::vt_id_option(),
        GroppeLib::vt_class_option(),
        array(
          'type'        => 'textfield',
          'heading'     => esc_html__( 'Active tab', 'groppe-core'),
          'param_name'  => 'active_tab',
          'description' => esc_html__( "Which tab you want to be active on load. [Eg. 1 or 2 or 3]", 'groppe-core'),
        ),
      ),

      'custom_markup'   => '<div class="wpb_accordion_holder wpb_holder clearfix vc_container_for_children">%content%</div><div class="tab_controls"><a class="add_tab" title="Add section"><span class="vc_icon"></span> <span class="tab-label">Add section</span></a></div>',
      'default_content' => '
        [vc_accordion_tab title="Accordion Tab 1" sub_title="Sub Title 1"][/vc_accordion_tab]
        [vc_accordion_tab title="Accordion Tab 2" sub_title="Sub Title 2"][/vc_accordion_tab]
      ',
      'js_view'         => 'VcAccordionView'
    ) );

    // ==========================================================================================
    // VC ACCORDION TAB
    // ==========================================================================================
    vc_map( array(
      'name'                      => esc_html__( 'Accordion Section', 'groppe-core'),
      'base'                      => 'vc_accordion_tab',
      'is_container'              => true,
      'content_element'           => false,
      'category'                  => GroppeLib::grop_cat_name(),
      'params'                    => array(
        array(
          'type'        => 'textfield',
          'heading'     => esc_html__( 'Title', 'groppe-core'),
          'param_name'  => 'title',
        ),
      ),
      'js_view'         => 'VcAccordionTabView'
    ) );

  }
}
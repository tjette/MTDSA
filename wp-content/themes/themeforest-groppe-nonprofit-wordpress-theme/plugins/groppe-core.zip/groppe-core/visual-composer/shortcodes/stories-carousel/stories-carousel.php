<?php
/* ==========================================================
  Impact Carousel
=========================================================== */
if ( !function_exists('grop_story_carousel_func')) {
  function grop_story_carousel_func( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'title'  => '',
      'link'  => '',
      'description'  => '',
      'items'  => '',
      'class'  => '',
    ), $atts));
    $items = (array) vc_param_group_parse_atts( $items );
    $get_carousel_item = array();
    foreach ( $items as $story_logo ) {
      $each_item = $story_logo;
      $each_item['image'] = isset( $story_logo['image'] ) ? $story_logo['image'] : '';
      $each_item['title'] = isset( $story_logo['title'] ) ? $story_logo['title'] : '';
      $get_carousel_item[] = $each_item;
    }
    ob_start();

  $description =  nl2br( $description, false );
?>
<section class="grop-suess_strisst2_area <?php echo esc_attr( $class ); ?>">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="grop-suess_strisst2_txt">
        <?php 
          if ( $link ) {
            echo '<h2><a href="'.esc_url($link).'">'.$title.'</a></h2>';
          } else {
            echo '<h2>'.$title.'</h2>';
          }
          if ( $description ) {
            echo '<p>'.$description.'</p>';
          } ?>
        </div>
      </div>
      <div class="col-md-8">
        <div class="owl-carousel  grop-suess_strisst2_carousel"
              data-items="2" 
              data-items-tablet="2" 
              data-items-mobile="1" 
              data-autoplay="false" 
              data-dots="true" 
              data-nav="false" 
              data-margin="30">
          <?php
          foreach ( $get_carousel_item as $each_item ) {
            $groppe_alt = get_post_meta($each_item['image'], '_wp_attachment_image_alt', true);
            $image_url = wp_get_attachment_url( $each_item['image'] ); ?>
            <div class="grop-suess_strisst2_post_item">
              <div class="grop-suess_strisst2_media">
                <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $groppe_alt ); ?>" />
              </div>
              <div class="grop-suess_strisst2_pst_txt">
                <h4><?php echo $each_item['title']; ?></h4>
              </div>
            </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
</section>
<?php
    return ob_get_clean();
  }
}
add_shortcode( 'grop_story_carousel', 'grop_story_carousel_func' );

<?php
/* ==========================================================
  Client Carousel
=========================================================== */
if ( !function_exists('grop_custom_gallery_func')) {
  function grop_custom_gallery_func( $atts, $content = true ) {
    extract(shortcode_atts(array(
      'gallery_column'  => '',
      'items'  => '',
      'class'  => '',
    ), $atts));
    $content = wpb_js_remove_wpautop($content, true);
    // Group Field
    $items = (array) vc_param_group_parse_atts( $items );
    $get_gallery_item = array();
    foreach ( $items as $client_logo ) {
      $each_item = $client_logo;
      $each_item['image'] = isset( $client_logo['image'] ) ? $client_logo['image'] : '';
      $each_item['url'] = isset( $client_logo['url'] ) ? $client_logo['url'] : '';
      $get_gallery_item[] = $each_item;
    }

    $output = '<div class="grop-fix  grop-our_gallery_warp '.esc_attr( $gallery_column ).'"><div class="grop-our_gallery_cntner">';
    // Group Param Output
      foreach ( $get_gallery_item as $each_item ) {
        $groppe_alt = get_post_meta($each_item['image'], '_wp_attachment_image_alt', true);
        $image_url = wp_get_attachment_url( $each_item['image'] );
        $url = $each_item['url'];
        $output .= '<div class="grop-gallery-single-item"><div class="grop-gallery-item"><a href="'.esc_url($url).'"><img src="'. $image_url .'" alt="'.esc_attr($groppe_alt).'" ></a></div></div>';
      }
    $output .= '</div></div>';
    return $output;
  }
}
add_shortcode( 'grop_custom_gallery', 'grop_custom_gallery_func' );

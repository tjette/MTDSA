<?php
/* ==========================================================
  Services
=========================================================== */
if ( !function_exists('grop_missions_function')) {
  function grop_missions_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'mission_column'  => '',
      'mission_items'  => '',
      'class'  => '',

      // Style
      'title_color'  => '',
      'title_hover_color'  => '',
      'title_size'  => '',
      'content_color'  => '',
      'content_size'  => '',
    ), $atts));

    $mission_items = (array) vc_param_group_parse_atts( $mission_items );
    $get_each_mission = array();
    foreach ( $mission_items as $mission_item ) {
      $each_mission = $mission_item;
      $each_mission['icon'] = isset( $mission_item['icon'] ) ? $mission_item['icon'] : '';
      $each_mission['link'] = isset( $mission_item['link'] ) ? $mission_item['link'] : '';
      $each_mission['title'] = isset( $mission_item['title'] ) ? $mission_item['title'] : '';
      $each_mission['open_link'] = isset( $mission_item['open_link'] ) ? $mission_item['open_link'] : '';
      $get_each_mission[] = $each_mission;
    }
    // Style
    $e_uniqid        = uniqid();
    $inline_style  = '';
    // Name Color
    if ( $title_color || $title_size ) {
      $inline_style .= '.grop-mission-'. $e_uniqid .' .grop-missions_txt h4, .grop-mission-'. $e_uniqid .'.grop-missions_txt h4 a{';
      $inline_style .= ( $title_color ) ? 'color:'. $title_color .';' : '';
      $inline_style .= ( $title_size ) ? 'font-size:'. groppe_core_check_px($title_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $title_hover_color) {
      $inline_style .= '.grop-mission-'. $e_uniqid .' .grop-missions_txt h4:hover, .grop-mission-'. $e_uniqid .'.grop-missions_txt h4 a:hover{';
      $inline_style .= ( $title_hover_color ) ? 'color:'. $title_hover_color .';' : '';
      $inline_style .= '}';
    }
    if ( $content_color || $content_size ) {
      $inline_style .= '.grop-mission-'. $e_uniqid .' .grop-missions_txt p{';
      $inline_style .= ( $content_color ) ? 'color:'. $content_color .';' : '';
      $inline_style .= ( $content_size ) ? 'font-size:'. groppe_core_check_px($content_size) .';' : '';
      $inline_style .= '}';
    }

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-mission-'. $e_uniqid;

    $mission_column = $mission_column ? $mission_column: 'col-3';
    if ( $mission_column == 'col-2' ) {
      $col_class = 'col-md-6';
    } elseif($mission_column == 'col-4') {
      $col_class = 'col-md-3 col-sm-6';
    } else {
      $col_class = 'col-md-4 col-sm-6';
    }
  ob_start(); 
?>
    <section class="grop-missions_area <?php echo esc_attr( $styled_class ); ?>">
      <div class="row">
        <?php $count = 0;
        foreach ( $get_each_mission as $each_mission ) { 
          $link = $each_mission['link'];
          $count++;
          $open_link = $each_mission['open_link'] ? 'target="_blank"' : ''; 
          if ($mission_column == 'col-3' && $count == 3) {
            $ofset_class = ' col-sm-offset-3  col-md-offset-0';
          } else {
            $ofset_class = '';
          } ?>
          <div class="<?php echo esc_attr( $col_class.$ofset_class ); ?>">
            <div class="grop-missions_single">
              <?php if( $each_mission['icon'] ) {
                $groppe_alt = get_post_meta( $each_mission['icon'], '_wp_attachment_image_alt', true);
                $icon = wp_get_attachment_url( $each_mission['icon'] ); ?>
                <div class="grop-float_left  grop-missions_icon">
                  <img src="<?php echo esc_url( $icon ); ?>" alt="<?php echo esc_attr( $groppe_alt ); ?>" />
                </div>
              <?php } ?>
              <div class="grop-fix grop-missions_txt">
                <?php
                if( !empty($link) ){
                  echo '<h4><a href="'.$each_mission['link'].'" '.$open_link.'>'.$each_mission['title'].'</a></h4>'; 
                } else {
                 echo '<h4>'.$each_mission['title'].'</h4>';
                } 
                if (!empty($each_mission['desc'])) {
                  echo '<p>'.$each_mission['desc'].'</p>';
                } ?>
              </div><!--/end-->
            </div>
          </div>
        <?php } ?>

      </div>
    </section>
<?php
    return ob_get_clean();
  }
}
add_shortcode( 'grop_missions', 'grop_missions_function' );

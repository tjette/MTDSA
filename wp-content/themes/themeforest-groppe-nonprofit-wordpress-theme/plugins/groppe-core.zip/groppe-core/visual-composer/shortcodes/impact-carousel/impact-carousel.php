<?php
/* ==========================================================
  Client Carousel
=========================================================== */
if ( !function_exists('grop_impact_func')) {
  function grop_impact_func( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'impact_title' => '',
      'impact_description' => '',
      'impact_content' => '',
      'btn_txt' => '',
      'btn_link' => '',
      'open_link' => '',
      'title'  => '',
      'items'  => '',
      'class'  => '',
      // Carousel
      'carousel_dots'  => '',
      'carousel_nav'  => '',
      'carousel_loop'  => '',
      'carousel_items'  => '',
      'carousel_margin'  => '',
      'carousel_autoplay_timeout'  => '',
      'carousel_autoplay'  => '',
      'carousel_animate_out'  => '',
      'carousel_mousedrag'  => '',
    ), $atts));
    $content = wpb_js_remove_wpautop($content, true);
    // Group Field
    $items = (array) vc_param_group_parse_atts( $items );
    $get_carousel_item = array();
    foreach ( $items as $client_logo ) {
      $each_item = $client_logo;
      $each_item['image'] = isset( $client_logo['image'] ) ? $client_logo['image'] : '';
      $each_item['title'] = isset( $client_logo['title'] ) ? $client_logo['title'] : '';
      $get_carousel_item[] = $each_item;
    }

    // Carousel Data's
    $carousel_loop = $carousel_loop !== 'true' ? ' data-loop="true"' : ' data-loop="false"';
    $carousel_dots = $carousel_dots ? ' data-dots="'. $carousel_dots .'"' : ' data-items="true"';
    $carousel_nav = $carousel_nav ? ' data-nav="'. $carousel_nav .'"' : ' data-nav="false"';
    $carousel_items = $carousel_items ? ' data-items="'. $carousel_items .'"' : ' data-items="5"';
    $carousel_margin = $carousel_margin ? ' data-margin="'. $carousel_margin .'"' : ' data-margin="30"';
    $carousel_autoplay_timeout = $carousel_autoplay_timeout ? ' data-autoplay-timeout="'. $carousel_autoplay_timeout .'"' : '';
    $carousel_autoplay = $carousel_autoplay ? ' data-autoplay="'. $carousel_autoplay .'"' : '';
    $carousel_animate_out = $carousel_animate_out ? ' data-animateout="'. $carousel_animate_out .'"' : '';
    $carousel_mousedrag = $carousel_mousedrag !== 'true' ? ' data-mouse-drag="true"' : ' data-mouse-drag="false"';


    $impact_title = $impact_title ? '<h3>'.$impact_title.'</h3>' : '';
    $impact_description = $impact_description ? '<p class="grop-oimt_semi">'.$impact_description.'</p>' : '';
    $impact_content = $impact_content ? '<p>'.$impact_content.'</p>' : '';
    $open_tab = $open_link ? 'target="_blank"' : '';
    $btn_link = $btn_link ? '<a class="grop-btn grop-btn_overly grop-grop-oimtrm_btn" href="'.$btn_link.'" '.$open_tab.'><span>'.$btn_txt.'</span></a>':'<span class="grop-btn grop-btn_overly grop-grop-oimtrm_btn"><span>'.$btn_txt.'</span></span>';
    $button_actual = $btn_txt ? $btn_link : '';

    $output = '<div class="grop-fix grop-oimt_warp">';
    $output .= '<div class="grop-float_left  grop-oimt_crosl_warp">';
    $output .= '<div class="owl-carousel  grop-oimt_carousel"
          '. $carousel_loop . $carousel_items . $carousel_margin . $carousel_autoplay_timeout . $carousel_autoplay . $carousel_animate_out . $carousel_mousedrag . $carousel_dots .'>';

    // Group Param Output
    foreach ( $get_carousel_item as $each_item ) {
      $groppe_alt = get_post_meta($each_item['image'], '_wp_attachment_image_alt', true);
      $image_url = wp_get_attachment_url( $each_item['image'] );
      $output .= '<div class="grop-oimt_single"><img src="'. $image_url .'" alt="'.esc_attr($groppe_alt).'" ><h5 class="text-center  grop-oimt_cption">'.$each_item['title'].'</h5></div>';
    }
    $output .= '</div>';
    $output .= '</div>';
    $output .= '<div class="grop-fix  grop-oimt_txt">';
    $output .= $impact_title . $impact_description . $impact_content . $button_actual;
    $output .= '</div>';
    $output .= '</div>';

    return $output;
  }
}
add_shortcode( 'grop_impact_carousel', 'grop_impact_func' );

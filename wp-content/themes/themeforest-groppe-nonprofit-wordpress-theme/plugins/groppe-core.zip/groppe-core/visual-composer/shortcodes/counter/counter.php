<?php
/* ==========================================================
  Counter
=========================================================== */
if ( !function_exists('grop_counter_function')) {
  function grop_counter_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'counter_style'  => '',
      'counter_column'  => '',
      'counter_title'  => '',
      'counter_desc'  => '',
      'counters'  => '',
      'background_image'  => '',
      'counters2'  => '',
      'class'  => '',

      // Style
      'counter_title_color'  => '',
      'counter_value_color'  => '',
      'counter_title_size'  => '',
      'counter_value_size'  => '',
    ), $atts));
    if( $counter_style == 'enhanced' ) {
      $counters = $counters;
    } else {
      $counters = $counters2;
    }

    $counters = (array) vc_param_group_parse_atts( $counters );
    $get_counter_item = array();
    foreach ( $counters as $counter ) {
      $each_item = $counter;
      $each_item['image'] = isset( $counter['image'] ) ? $counter['image'] : '';
      $each_item['title'] = isset( $counter['title'] ) ? $counter['title'] : '';
      $each_item['pre'] = isset( $counter['pre'] ) ? $counter['pre'] : '';
      $each_item['post'] = isset( $counter['post'] ) ? $counter['post'] : '';
      $each_item['counter_value'] = isset( $counter['counter_value'] ) ? $counter['counter_value'] : '';
      $get_counter_item[] = $each_item;
    }
  ob_start();

  if( $counter_style == 'standard' ){
    $col_class_s = $counter_column;
  } else {
    $col_class_s = '';
  }

    if ($counter_column == 'col-2') {
      $col_class = 'col-sm-6';
    } elseif ($counter_column == 'col-3') {
      $col_class = 'col-sm-4';
    } elseif ($counter_column == 'col-4') {
      $col_class = 'col-sm-6 col-md-3';
    } elseif ($counter_column == 'col-5') {
      $col_class = 'col-5';
    } else{
      $col_class = '';
    }
  if( $counter_style == 'enhanced' ){ 
    if ($background_image) {
      $background_image = 'style="background-image: url('.wp_get_attachment_url( $background_image ).');"';
    } else {
      $background_image = '';
    }
    ?>
    <section class="grop-prlax_height-280  grop-parallax_normel grop-oicter_area" <?php echo $background_image; ?>>
      <div class="grop-full_height  container">
        <div class="row  grop-flax_vr-middle">
            <?php if (!empty($counter_title)) {
              echo '<div class="col-sm-4"><div class="text-center  grop-oic_txt">'.$counter_title.'</div></div>';
              $wrap_class = 'col-sm-8';
              $style = '';
            } else {
              $wrap_class = 'container-fluid'; 
              $style = ' style="width:100%;"'; 
            } ?>
          
          <!--Impacts counter warp start \-->
          <div class="<?php echo esc_attr( $wrap_class ); ?>" <?php echo $style; ?>>
            <div class="row  grop-oic_row">
              <?php 
              foreach ($get_counter_item as $key => $each_item) {
                $title = $each_item['title'];
                $value = $each_item['counter_value'];
                $imageid = $each_item['image'];
                $image = wp_get_attachment_url( $imageid );
                echo '
                  <div class="'.esc_attr( $col_class ).'">
                    <div class="text-center  grop-oic_singl_warp">';
                      if (!empty($imageid)) {
                echo '<div class="grop-oic_icon">
                        <img src="'.esc_url($image).'" alt="#" />
                      </div>';
                      }
                echo '<h2><span class="grop-conter">'.$value.'</span></h2>
                      <p>'.$title.'</p>
                    </div>
                  </div>
                  ';
              } ?>
            </div>
          </div><!--/Impacts counter warp end-->
        </div>
      </div>
    </section>
<?php } elseif( $counter_style == 'standard' ){ ?>
      <div class="grop-fix  grop-stryabtus_cnter_warp">
        <?php 
        foreach ($get_counter_item as $key => $each_item) {
          $title = $each_item['title'];
          $pre = $each_item['pre'];
          $post = $each_item['post'];
          $value = (int) $each_item['counter_value'];
          echo '<div class="text-center text-uppercase   grop-float_left  grop-stryabtus_box_single '.esc_attr( $col_class_s ).'">
          <div class="grop-stryabtus_box_txt">
            <h5>'.$title.'</h5>
            <h2 class="grop-stryabtus_counter">
              '.$pre.'<span class="grop-conter">'.$value.'</span>'.$post.'
            </h2>
          </div>
        </div>';
        } ?>
      </div>
  <?php } else { ?>
      <section class="grop-counter_area">
        <div class="row">
        <?php 
        foreach ($get_counter_item as $key => $each_item) {
          $title = $each_item['title'];
          $pre = $each_item['pre'];
          $post = $each_item['post'];
          $value = $each_item['counter_value']; ?>
          <div class="<?php echo esc_attr( $col_class ); ?>">
            <div class="text-uppercase  text-center grop-counter_cont">
              <h2><?php echo $pre; ?><span class="grop-conter"><?php echo $value; ?></span><?php echo $post; ?></h2>
              <?php if(!empty( $title )){ echo '<p>'.$title.'</p>'; } ?>
            </div>
          </div>
        <?php } ?>
        </div>
      </section>
    <?php }
    // Output
    return ob_get_clean();
  }
}
add_shortcode( 'grop_counter', 'grop_counter_function' );

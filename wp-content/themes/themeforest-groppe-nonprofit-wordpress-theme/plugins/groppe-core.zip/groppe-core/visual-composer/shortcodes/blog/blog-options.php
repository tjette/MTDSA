<?php
/**
 * Blog - Shortcode Options
 */
add_action( 'init', 'grop_blog_vc_map' );
if ( ! function_exists( 'grop_blog_vc_map' ) ) {
  function grop_blog_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Blog", 'groppe-core'),
      "base" => "grop_blog",
      "description" => esc_html__( "Blog Styles", 'groppe-core'),
      "icon" => "fa fa-newspaper-o color-red",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(

        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Blog Style', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Style List', 'groppe-core' ) => 'blog-list',
            esc_html__( 'Style Grid', 'groppe-core' ) => 'blog-grid',
          ),
          'admin_label' => true,
          'param_name' => 'blog_style',
          'description' => esc_html__( 'Select your blog style.', 'groppe-core' ),
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Columns', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Blog Columns', 'groppe-core' ) => '',
            esc_html__( 'Column Two', 'groppe-core' ) => 'grop-blog-col-2',
            esc_html__( 'Column Three', 'groppe-core' ) => 'grop-blog-col-3',
            esc_html__( 'Column Four', 'groppe-core' ) => 'grop-blog-col-4',
          ),
          'admin_label' => true,
          'param_name' => 'blog_column',
          'description' => esc_html__( 'Select your blog column.', 'groppe-core' ),
          'dependency' => array(
            'element' => 'blog_style',
            'value' => 'blog-grid',
          ),
        ),
        array(
          "type"        =>'textfield',
          "heading"     =>esc_html__('Limit', 'groppe-core'),
          "param_name"  => "blog_limit",
          "value"       => "",
          'admin_label' => true,
          "description" => esc_html__( "Enter the number of items to show.", 'groppe-core'),
        ),

        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Meta's to Hide", 'groppe-core' ),
    			"param_name"  => 'mts_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
    		),
        array(
          "type"        => 'switcher',
          "heading"     => esc_html__('Category', 'groppe-core'),
          "param_name"  => "blog_category",
          "value"       => "",
          "std"         => false,
          'edit_field_class' => 'vc_col-md-3 vc_column vt_field_space',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Date', 'groppe-core'),
          "param_name"  => "blog_date",
          "value"       => "",
          "std"         => false,
          'edit_field_class'   => 'vc_col-md-3 vc_column vt_field_space',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Author', 'groppe-core'),
          "param_name"  => "blog_author",
          "value"       => "",
          "std"         => false,
          'edit_field_class'   => 'vc_col-md-3 vc_column vt_field_space',
          'dependency' => array(
            'element' => 'blog_style',
            'value' => 'blog-list',
          ),
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Comments', 'groppe-core'),
          "param_name"  => "blog_comments",
          "value"       => "",
          "std"         => false,
          'edit_field_class'   => 'vc_col-md-3 vc_column vt_field_space',
        ),

        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Listing", 'groppe-core' ),
    			"param_name"  => 'lsng_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
    		),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Order', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Blog Order', 'groppe-core' ) => '',
            esc_html__('Asending', 'groppe-core') => 'ASC',
            esc_html__('Desending', 'groppe-core') => 'DESC',
          ),
          'param_name' => 'blog_order',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Order By', 'groppe-core' ),
          'value' => array(
            esc_html__('None', 'groppe-core') => 'none',
            esc_html__('ID', 'groppe-core') => 'ID',
            esc_html__('Author', 'groppe-core') => 'author',
            esc_html__('Title', 'groppe-core') => 'title',
            esc_html__('Date', 'groppe-core') => 'date',
          ),
          'param_name' => 'blog_orderby',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Show only certain categories?', 'groppe-core'),
          "param_name"  => "blog_show_category",
          "value"       => "",
          "description" => esc_html__( "Enter category SLUGS (comma separated) you want to display.", 'groppe-core')
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Short Content (Excerpt Length)', 'groppe-core'),
          "param_name"  => "short_content",
          "value"       => "",
          "description" => esc_html__( "Enter the numeric value of, how many words you want in short content paragraph.", 'groppe-core')
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Pagination', 'groppe-core'),
          "param_name"  => "blog_pagination",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        =>'textfield',
          "heading"     =>esc_html__('Read More Button Text', 'groppe-core'),
          "param_name"  => "read_more_txt",
          "value"       => "",
          'dependency' => array(
            'element' => 'blog_style',
            'value' => 'blog-list',
          ),
          "description" => esc_html__( "Enter read more button text.", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        =>'textfield',
          "heading"     =>esc_html__('Miss-Aligned? Mention Minimum Height :', 'groppe-core'),
          "param_name"  => "miss_align_height",
          "value"       => "",
          "description" => esc_html__( "Enter the px value for minimum height. This will fix miss-aligned issue with your listing items.", 'groppe-core')
        ),
        GroppeLib::vt_class_option(),

      )
    ) );
  }
}

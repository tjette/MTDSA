<?php
/* ==========================================================
  Project
=========================================================== */
if ( !function_exists('grop_project_function')) {
  function grop_project_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'project_style'  => '',
      'project_limit'  => '',
      'project_column'  => '',
      // Enable & Disable
      'project_filter'  => '',
      'project_pagination'  => '',
      'project_no_space'  => '',
      'disable_size_limit'  => '',
      // Listing
      'project_order'  => '',
      'project_orderby'  => '',
      'project_show_category'  => '',
      'class'  => '',
      // Style - Filter
      'filter_color'  => '',
      'filter_active_color'  => '',
      'filter_size'  => '',
      // Style - Colors And Sizes
      'project_title_size'  => '',
      'project_title_color'  => '',
      'project_title_hover_color'  => '',
      'btn_bg_color'  => '',
      'btn_text_color'  => '',
      'btn_text'  => '',
    ), $atts));

    // Shortcode Style CSS
    $e_uniqid        = uniqid();
    $inline_style  = '';

    // Title Color
    if ( $project_title_size || $project_title_color  || $project_title_hover_color ) {
      $inline_style .= '.grop-project-'. $e_uniqid .' .grop-projct_content_warp h4 a {';
      $inline_style .= ( $project_title_color ) ? 'color:'. $project_title_color .';' : '';
      $inline_style .= ( $project_title_size ) ? 'font-size:'. groppe_core_check_px($project_title_size) .';' : '';
      $inline_style .= '}';
      $inline_style .= '.grop-project-'. $e_uniqid .' .grop-projct_content_warp h4 a:hover{';
      $inline_style .= ( $project_title_hover_color ) ? 'color:'. $project_title_hover_color .' !important;' : '';
      $inline_style .= '}';
    }
    // Button
    if ( $btn_bg_color || $btn_text_color ) {
      $inline_style .= '.grop-project-'. $e_uniqid .' .grop-projct_content_warp .grop-vpjct_btn {';
      $inline_style .= ( $btn_bg_color ) ? 'background-color:'. $btn_bg_color .';' : '';
      $inline_style .= ( $btn_text_color ) ? 'color:'. $btn_text_color .';' : '';
      $inline_style .= '}';
    }

    // Filter
    if ( $filter_color || $filter_size ) {
      $inline_style .= '#grop_filters.grop-project-'. $e_uniqid .' ul li {';
      $inline_style .= ( $filter_color ) ? 'color:'. $filter_color .';' : '';
      $inline_style .= ( $filter_size ) ? 'font-size:'. groppe_core_check_px($filter_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $filter_active_color ) {
      $inline_style .= '#grop_filters.grop-project-'. $e_uniqid .' ul li.is-active {';
      $inline_style .= ( $filter_active_color ) ? 'background-color:'. $filter_active_color .' !important;' : '';
      $inline_style .= '}';
      $inline_style .= '#grop_filters.grop-project-'. $e_uniqid .' ul li:hover {';
      $inline_style .= ( $filter_active_color ) ? 'background-color:'. $filter_active_color .' !important;' : '';
      $inline_style .= '}';
    }

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-project-'. $e_uniqid;

    // Style
    // $project_style = $project_style === 'bpw-style-two' ? 'bpw-style-two' : 'bpw-style-one';
    $project_column = $project_column ? $project_column : 'bpw-col-3';

    // View Details Button
    if (groppe_framework_active()) {
      $view_more_text = cs_get_option('project_read_more_txt');
      if ($btn_text) {
        $btn_text = $btn_text;
      } else {
        $btn_text = __('View Project', 'groppe-core');
      }
    } else {
      $btn_text = $btn_text ? $btn_text : __('View Project', 'groppe-core');
    }

    // Project No Space
    $project_no_space = $project_no_space ? 'bpw-no-gutter' : '';

    // Turn output buffer on
    ob_start(); ?>
    <div class="grop-project_grid_area">
      <div class="container">
        <div class="grop-filter_content_warp">

          <!-- Project Filter -->
          <?php
          if ($project_filter) {
          ?>
          <div id="grop_filters" class="text-left grop-projctfilter_nav <?php echo esc_html($styled_class); ?>">
            <ul class="text-uppercase list-inline">
        			<li class="grop-filte_btn is-active" data-filter="*"><?php echo esc_attr('Show All', 'groppe-core'); ?></li>
              <?php
                if ($project_show_category) {
                  $cat_name = explode(',', $project_show_category);
                  $terms = $cat_name;
                  $count = count($terms);
                  if ($count > 0) {
                    foreach ($terms as $term) {
                      echo '<li class="cat-'. preg_replace('/\s+/', "", strtolower($term)) .' cat-'. preg_replace('/\s+/', "", strtolower($term)) .'" data-filter=".cat-'. preg_replace('/\s+/', "", strtolower($term)) .'" title="' . str_replace('-', " ", strtolower($term)) . '">' . str_replace('-', " ", strtolower($term)) . '</li>';
                     }
                  }
                } else {
                  $terms = get_terms('project_category');
                  $count = count($terms);
                  $i=0;
                  $term_list = '';
                  if ($count > 0) {
                    foreach ($terms as $term) {
                      $i++;
                      $term_list .= '<li class="grop-filte_btn cat-'. $term->slug .'" data-filter=".'. $term->slug .'" title="' . esc_attr($term->name) . '">' . $term->name . '</li>';
                      if ($count != $i) {
                        $term_list .= '';
                      } else {
                        $term_list .= '';
                      }
                    }
                    echo $term_list;
                  }
                }
              ?>
        		</ul>
          </div>
          <?php
          }

          // Pagination
          global $paged;
          if( get_query_var( 'paged' ) )
            $my_page = get_query_var( 'paged' );
          else {
            if( get_query_var( 'page' ) )
              $my_page = get_query_var( 'page' );
            else
              $my_page = 1;
            set_query_var( 'paged', $my_page );
            $paged = $my_page;
          }

          $args = array(
            // other query params here,
            'paged' => $my_page,
            'post_type' => 'project',
            'posts_per_page' => (int)$project_limit,
            'project_category' => esc_attr($project_show_category),
            'orderby' => $project_orderby,
            'order' => $project_order
          );

          $grop_port = new WP_Query( $args ); ?>

          <!-- Project Start -->
          <div class="grop-filter_content  grop-projctfilter_content">

            <?php
            if ($grop_port->have_posts()) : while ($grop_port->have_posts()) : $grop_port->the_post();

              // Category
              global $post;
              $terms = wp_get_post_terms($post->ID,'project_category');
              foreach ($terms as $term) {
                $cat_class = $term->slug;
              }
              $count = count($terms);
              $i=0;
              $cat_class = '';
              if ($count > 0) {
                foreach ($terms as $term) {
                  $i++;
                  $cat_class .= $term->slug .' ';
                  if ($count != $i) {
                    $cat_class .= '';
                  } else {
                    $cat_class .= '';
                  }
                }
              }

              // Featured Image
              $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
              $large_image = $large_image[0];
              if (!$disable_size_limit) {
                  if(class_exists('Aq_Resize')) {
                    $project_img = aq_resize( $large_image, '360', '234', true );
                  } else {$project_img = $large_image;}
                  $featured_img = ( $project_img ) ? $project_img : GROPPE_PLUGIN_ASTS . '/images/420x280.jpg';
                
              } else {
                $featured_img = ( $large_image ) ? $large_image : '';
              }

            ?>
            <div class="grop-filter_single_col  grop-projctfilter_col <?php echo esc_attr($project_column); ?> <?php echo esc_attr($styled_class); ?> <?php echo esc_attr($cat_class); ?>">
              <div class="grop-projct_itm_warp">
                <!--project Media box start \-->
                <div class="grop-projct_media_box">
                  <a class="grop-cause_media_img" href="">
                    <img src="<?php echo esc_url($featured_img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" />
                  </a>
                  
                </div><!--/end-->
                
                <!--project content text start \-->
                <div class="grop-projct_content_warp">  
                  <h4>
                    <a href="<?php esc_url(the_permalink()); ?>"><?php esc_attr(the_title()); ?></a>
                  </h4>
                  <p><?php  groppe_excerpt('20'); ?></p>
                  <!--  project btn start  \-->
                  <a class="grop-btn grop-btn_overly grop-vpjct_btn" href="<?php esc_url(the_permalink()); ?>">
                    <span><?php echo esc_attr($btn_text); ?></span>
                  </a><!--/end-->
                </div>
              </div>
            </div>

            <?php
            endwhile;
            endif;
            wp_reset_postdata(); ?>

          </div>
          <!-- Project End -->

        </div>
      </div>
          <?php
          if ($project_pagination) {
            groppe_custom_paging_nav($grop_port->max_num_pages,"",$paged);
          } ?>
    </div>      

    <?php
    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'grop_project', 'grop_project_function' );

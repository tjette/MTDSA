<?php
/**
 * Event Carousel - Shortcode Options
 */
add_action( 'init', 'event_carousel_vc_map' );
if ( ! function_exists( 'event_carousel_vc_map' ) ) {
  function event_carousel_vc_map() {

  $cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );
  $contact_forms = array();
  if ( $cf7 ) {
    foreach ( $cf7 as $cform ) {
      $contact_forms[ $cform->post_title ] = $cform->ID;
    }
  } else {
    $contact_forms[ esc_html__( 'No contact forms found', 'groppe-core' ) ] = 0;
  }


  $events = get_posts( 'post_type="tribe_events"&numberposts=-1' );
  $select_event = array();
  if ( $events ) {
    foreach ( $events as $event ) {
      $select_event[ $event->post_title ] = $event->ID;
    }
  } else {
    $select_event[ esc_html__( 'No Event Found', 'groppe-core' ) ] = 0;
  }
    vc_map( array(
      "name" => __( "Event Carousel", 'groppe-core'),
      "base" => "grop_event_carousel",
      "description" => __( "Event Carousel", 'groppe-core'),
      "icon" => "fa fa-shield color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          "type"        =>'textfield',
          "heading"     =>esc_html__('Section Title', 'groppe-core'),
          "param_name"  => "title",
          "value"       => "",
          'admin_label' => true,
          "description" => esc_html__( "Enter the number of items to show.", 'groppe-core'),
        ),
        array(
          "type"        =>'textfield',
          "heading"     =>esc_html__('Event Limit', 'groppe-core'),
          "param_name"  => "event_limit",
          "value"       => "",
          "description" => esc_html__( "Enter the number of items to show.", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Order', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Event Order', 'groppe-core' ) => '',
            esc_html__('Asending', 'groppe-core') => 'ASC',
            esc_html__('Desending', 'groppe-core') => 'DESC',
          ),
          'param_name' => 'event_order',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Order By', 'groppe-core' ),
          'value' => array(
            esc_html__('None', 'groppe-core') => 'none',
            esc_html__('ID', 'groppe-core') => 'ID',
            esc_html__('Author', 'groppe-core') => 'author',
            esc_html__('Title', 'groppe-core') => 'title',
            esc_html__('Date', 'groppe-core') => 'date',
          ),
          'param_name' => 'event_orderby',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "checkbox",
          "heading" => esc_html__( "Show Events", 'groppe-core' ),
          "param_name" => "perticular_event",
          "value" => $select_event,
          "admin_label" => true,
          "description" => esc_html__( "Select team Members.", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Share Buttons', 'groppe-core'),
          "param_name"  => "event_share_btn",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Contact Button', 'groppe-core'),
          "param_name"  => "event_popup_btn",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Contact Button Type', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Simple Link', 'groppe-core' ) => 'link',
            esc_html__( 'Pop-up', 'groppe-core' ) => 'popup',
          ),
          'dependency' => array(
            'element' => 'event_popup_btn',
            'value' => 'true',
          ),
          'param_name' => 'contact_btn_type',
          'description' => esc_html__( 'Select your contact button type.', 'groppe-core' ),
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Contact Button Link', 'groppe-core'),
          "param_name"  => "contact_btn_link",
          "value"       => "",
          'dependency' => array(
            'element' => 'contact_btn_type',
            'value' => 'link',
          ),
          "description" => esc_html__( "Enter contatc button link.", 'groppe-core')
        ),

        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Select pop-up contact form', 'js_composer' ),
          'param_name' => 'popup_form_id',
          'value' => $contact_forms,
          'save_always' => true,
          'dependency' => array(
            'element' => 'contact_btn_type',
            'value' => 'popup',
          ),
          'description' => esc_html__( 'Choose previously created contact form from the drop down list.', 'js_composer' ),
        ),


        GroppeLib::vt_class_option(),

        // Carousel
        GroppeLib::vt_notice_field(__( "Basic Options", 'groppe-core' ),'bsic_opt','cs-warning', 'Carousel'), // Notice
        GroppeLib::vt_carousel_loop(), // Loop
        GroppeLib::vt_carousel_items(), // Items
        GroppeLib::vt_carousel_margin(), // Margin
        GroppeLib::vt_notice_field(__( "Auto Play & Interaction", 'groppe-core' ),'apyi_opt','cs-warning', 'Carousel'), // Notice
        GroppeLib::vt_carousel_autoplay_timeout(), // Autoplay Timeout
        GroppeLib::vt_carousel_autoplay(), // Autoplay
        GroppeLib::vt_carousel_animateout(), // Animate Out
        GroppeLib::vt_carousel_mousedrag(), // Mouse Drag
        GroppeLib::vt_notice_field(__( "Width & Height", 'groppe-core' ),'wah_opt','cs-warning', 'Carousel'), // Notice
        GroppeLib::vt_carousel_autowidth(), // Auto Width
        GroppeLib::vt_carousel_autoheight(), // Auto Height
        GroppeLib::vt_notice_field('Responsive Options','res_opt','cs-warning', 'Carousel'), // Notice
        GroppeLib::vt_carousel_tablet(), // Tablet
        GroppeLib::vt_carousel_mobile(), // Mobile
        GroppeLib::vt_carousel_small_mobile(), // Small Mobile

      )
    ) );
  }
}

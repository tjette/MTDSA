<?php
/**
 * Project - Shortcode Options
 */
add_action( 'init', 'grop_project_vc_map' );
if ( ! function_exists( 'grop_project_vc_map' ) ) {
  function grop_project_vc_map() {
    vc_map( array(
      "name" => __( "Project", 'groppe-core'),
      "base" => "grop_project",
      "description" => __( "Project Styles", 'groppe-core'),
      "icon" => "fa fa-briefcase color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(

        array(
          "type"        =>'textfield',
          "heading"     =>__('Limit', 'groppe-core'),
          "param_name"  => "project_limit",
          "value"       => "",
          'admin_label' => true,
          "description" => __( "Enter the number of items to show.", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => __( 'Columns', 'groppe-core' ),
          'value' => array(
            __( 'Select Project Columns', 'groppe-core' ) => '',
            __( 'Column Two', 'groppe-core' ) => 'bpw-col-2',
            __( 'Column Three', 'groppe-core' ) => 'bpw-col-3',
            __( 'Column Four', 'groppe-core' ) => 'bpw-col-4',
          ),
          'admin_label' => true,
          'param_name' => 'project_column',
          'description' => __( 'Select your project column.', 'groppe-core' ),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),

        array(
    			"type"        => "notice",
    			"heading"     => __( "Enable & Disable", 'groppe-core' ),
    			"param_name"  => 'ends_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
    		),
        array(
          "type"        =>'switcher',
          "heading"     =>__('Filter', 'groppe-core'),
          "param_name"  => "project_filter",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>__('Pagination', 'groppe-core'),
          "param_name"  => "project_pagination",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>__('No Space', 'groppe-core'),
          "param_name"  => "project_no_space",
          "value"       => "",
          "std"         => false,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type"        => 'switcher',
          "heading"     => __('Disable Featured Image Size Limit', 'groppe-core'),
          "param_name"  => "disable_size_limit",
          "value"       => "",
          "std"         => false,
        ),

        array(
    			"type"        => "notice",
    			"heading"     => __( "Listing", 'groppe-core' ),
    			"param_name"  => 'lsng_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
    		),
        array(
          'type' => 'dropdown',
          'heading' => __( 'Order', 'groppe-core' ),
          'value' => array(
            __( 'Select Project Order', 'groppe-core' ) => '',
            __('Asending', 'groppe-core') => 'ASC',
            __('Desending', 'groppe-core') => 'DESC',
          ),
          'param_name' => 'project_order',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => __( 'Order By', 'groppe-core' ),
          'value' => array(
            __('None', 'groppe-core') => 'none',
            __('ID', 'groppe-core') => 'ID',
            __('Author', 'groppe-core') => 'author',
            __('Title', 'groppe-core') => 'title',
            __('Date', 'groppe-core') => 'date',
          ),
          'param_name' => 'project_orderby',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        => 'textfield',
          "heading"     => __('Show only certain categories?', 'groppe-core'),
          "param_name"  => "project_show_category",
          "value"       => "",
          "description" => __( "Enter category SLUGS (comma separated) you want to display.", 'groppe-core')
        ),
        GroppeLib::vt_class_option(),

        // Stylings
        array(
    			"type"        => "notice",
    			"heading"     => __( "Filter", 'groppe-core' ),
    			"param_name"  => 'flst_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
          "group"       => __('Style', 'groppe-core'),
    		),
        array(
          "type"        => 'colorpicker',
          "heading"     => __('Filter Text Color', 'groppe-core'),
          "param_name"  => "filter_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => __('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => __('Active Color', 'groppe-core'),
          "param_name"  => "filter_active_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => __('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'textfield',
          "heading"     => __('Text Size', 'groppe-core'),
          "param_name"  => "filter_size",
          "value"       => "",
          "group"       => __('Style', 'groppe-core'),
          "description" => __( "Enter filter text size in px.", 'groppe-core'),
        ),

        // Size
        array(
    			"type"        => "notice",
    			"heading"     => __( "Item Style", 'groppe-core' ),
    			"param_name"  => 'itm_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
          "group"       => __('Style', 'groppe-core'),
    		),
        array(
          "type"        => 'textfield',
          "heading"     => __('Title Size', 'groppe-core'),
          "param_name"  => "project_title_size",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => __('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => __('Title Color', 'groppe-core'),
          "param_name"  => "project_title_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => __('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => __('Title Hover Color', 'groppe-core'),
          "param_name"  => "project_title_hover_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => __('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => __('Button BG Color', 'groppe-core'),
          "param_name"  => "btn_bg_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => __('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => __('Button Text Color', 'groppe-core'),
          "param_name"  => "btn_text_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => __('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'textfield',
          "heading"     => __('Button Text', 'groppe-core'),
          "param_name"  => "btn_text",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => __('Style', 'groppe-core'),
        ),

      )
    ) );
  }
}

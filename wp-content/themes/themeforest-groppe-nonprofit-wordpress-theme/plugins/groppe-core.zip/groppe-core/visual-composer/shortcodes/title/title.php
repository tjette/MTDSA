<?php
/* ===========================================================
    Button
=========================================================== */
if ( !function_exists('grop_title_function')) {
  function grop_title_function( $atts, $content = NULL ) {
    extract(shortcode_atts(array(
      "title" => '',
      "title_tag" => '',
      "description" => '',
      "section_class" => '',
      // styles
      "text_align"  => '',
      "title_size" => '',
      "title_color" => '',
      "title_bottom_space" => '',
      "desc_color" => '',
      "desc_size" => '',
      "desc_line_height" => '',
      "title_type" => '',

      "class" => '',
      "css" => '',
    ), $atts));
   // Shortcode Style CSS
    $custom_css = ( function_exists( 'vc_shortcode_custom_css_class' ) ) ? vc_shortcode_custom_css_class( $css, ' ' ) : '';
    $title_tag = $title_tag ? $title_tag : 'div';
    $e_uniqid       = uniqid();
    $inline_style   = '';
    // Heading
    if ($title_type === 'tag') {
      if ( $title_color || $title_size || $title_bottom_space ) {
        $inline_style .= '.grop-heading-'. $e_uniqid. '{';
        $inline_style .= ( $title_color ) ? 'color:'. $title_color .';' : '';
        $inline_style .= ( $title_size ) ? 'font-size:'. groppe_core_check_px($title_size) .';' : '';
        $inline_style .= ( $title_bottom_space ) ? 'padding-bottom:'. groppe_core_check_px($title_bottom_space) .';' : '';
        $inline_style .= '}';
      }
    } else {
      if ( $title_color || $title_size || $title_bottom_space ) {
        $inline_style .= '.grop-section_text.grop-heading-'. $e_uniqid .' '.$title_tag.'{';
        $inline_style .= ( $title_color ) ? 'color:'. $title_color .';' : '';
        $inline_style .= ( $title_size ) ? 'font-size:'. groppe_core_check_px($title_size) .';' : '';
        $inline_style .= ( $title_bottom_space ) ? 'padding-bottom:'. groppe_core_check_px($title_bottom_space) .';' : '';
        $inline_style .= '}';
      }
    }
    // Description
      if ( $desc_color || $desc_size ) {
        $inline_style .= '.grop-section_text.grop-heading-'. $e_uniqid .' p{';
        $inline_style .= ( $desc_color ) ? 'color:'. $desc_color .';' : '';
        $inline_style .= ( $desc_size ) ? 'font-size:'. groppe_core_check_px($desc_size) .';' : '';
        $inline_style .= '}';
      }
      if ( $desc_line_height ) {
        $inline_style .= '.grop-section_text.grop-heading-'. $e_uniqid .' p{';
        $inline_style .= ( $desc_line_height ) ? 'line-height:'. groppe_core_check_px($desc_line_height) .';' : '';
        $inline_style .= '}';
      }

      // add inline style
      add_inline_style( $inline_style );
        $styled_class  = ' grop-heading-'. $e_uniqid.' ';

        $text_align = $text_align ? $text_align : 'text-center';

      if ( $title_type == 'tag' ) {
        $title_before = '';
        $title_after = '';
        $tag_before = ' class="text-uppercase grop-sctn_title_fntSz-30 '.esc_attr($styled_class.' '.$custom_css.' '.$class.' '.$text_align).'"';
      } else{
        $title_before = '<div class="grop-section_text '.esc_attr( $section_class.' '.$styled_class.' '.$custom_css.' '.$text_align).'">';
        $title_after = '</div>';
        $tag_before = ' class="text-uppercase grop-sctn_title_fntSz-30 '.esc_attr($class.' '.$styled_class.' '.$text_align).'"';
      }
    $result = '';

    $result .= $title_before;
    $result .= '<'.$title_tag.$tag_before.'>'.$title.'</'.$title_tag.'>';
    if ($description) {
      $result .= '<p>'.$description.'</p>';
    }
    $result .= $title_after;

    return $result; 
  }
}
add_shortcode( 'grop_title', 'grop_title_function' );

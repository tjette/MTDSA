<?php
/* ==========================================================
  Event
=========================================================== */
if ( !function_exists('grop_event_function')) {
  function grop_event_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'event_style'  => '',
      'event_limit'  => '',
      'event_column'  => '',
      // Enable & Disable
      'event_filter'  => '',
      'event_pagination'  => '',
      // Listing
      'event_order'  => '',
      'event_orderby'  => '',
      'event_show_category'  => '',
      'event_share_btn' => '',
      'event_popup_btn' => '',
      'contact_btn_type' => '',
      'contact_btn_link' => '',
      'popup_title'  => '',
      'popup_form_id' => '',
      'class'  => '',
      // Style - Filter
      'filter_color'  => '',
      'filter_active_color'  => '',
      'filter_active_bg'  => '',
      'filter_size'  => '',
      // Style - Colors And Sizes
      'event_title_size'  => '',
      'event_title_color'  => '',
      'event_title_hover_color'  => '',
    ), $atts));

    // Shortcode Style CSS
    $e_uniqid        = uniqid();
    $inline_style  = '';

    // Title Color
    if ( $event_title_size || $event_title_color  || $event_title_hover_color ) {
      $inline_style .= '.bpw-style-one .grop-event-'. $e_uniqid .' .bpw-content .bpw-heading, .bpw-col-5.bpw-normal-size.bpw-style-one .grop-event-'. $e_uniqid .' .bpw-content .bpw-heading, .bpw-style-two .grop-event-'. $e_uniqid .' .bpw-content .bpw-heading {';
      $inline_style .= ( $event_title_color ) ? 'color:'. $event_title_color .';' : '';
      $inline_style .= ( $event_title_size ) ? 'font-size:'. $event_title_size .';' : '';
      $inline_style .= '}';
      $inline_style .= '.bpw-style-two .grop-event-item.grop-event-'. $e_uniqid .':hover .bpw-content .bpw-heading {';
      $inline_style .= ( $event_title_hover_color ) ? 'color:'. $event_title_hover_color .';' : '';
      $inline_style .= '}';
    }

    // Filter
    if ( $filter_color || $filter_size ) {
      $inline_style .= '.grop-event-'. $e_uniqid .'.bpw-filter a {';
      $inline_style .= ( $filter_color ) ? 'color:'. $filter_color .';' : '';
      $inline_style .= ( $filter_size ) ? 'font-size:'. groppe_core_check_px($filter_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $filter_active_color ) {
      $inline_style .= '.grop-event-'. $e_uniqid .'.bpw-filter .btn-active {';
      $inline_style .= ( $filter_active_color ) ? 'color:'. $filter_active_color .';' : '';
      $inline_style .= '}';
    }
    if ( $filter_active_bg ) {
      $inline_style .= '.grop-event-'. $e_uniqid .'.bpw-filter li .btn-active:after {';
      $inline_style .= ( $filter_active_bg ) ? 'background-color:'. $filter_active_bg .';' : '';
      $inline_style .= '}';
    }

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-event-'. $e_uniqid;

    // Style
    if ($event_style === 'event-grid') {
    	$event_style_class = 'grop-filter_content_warp';
    } else {
    	$event_style_class = 'grop-events_list_warp';
    }
    $event_column = $event_column ? $event_column : 'column-three';


  if (groppe_framework_active()) {
    $excerpt_length = cs_get_option('theme_event_excerpt');
    $short_content = $excerpt_length ? $excerpt_length : '55';
    // $short_content = '19';
    // if ($excerpt_length) {
    //   $short_content = $excerpt_length;
    // } else {
    //   $short_content = $excerpt_length;
    // }
  } else {
    $short_content = '15';
  }
    // Turn output buffer on
    ob_start(); ?>

        <!-- Event Start -->
  <div class="grop-events <?php echo esc_attr($event_style_class.' '.$event_column.' '.$class); ?>">
    <?php if ($event_filter) { ?>
    <div id="grop_filters" class="text-center grop-evnfilter_nav">
      <ul class="text-uppercase  list-inline">
  			<li class="grop-filte_btn is-active" data-filter="*"><?php echo esc_html__('show All', 'groppe' ); ?></li>
        <?php
          if ($event_show_category) {
            $cat_name = explode(',', $event_show_category);
            $terms = $cat_name;
            $count = count($terms);
            if ($count > 0) {
              foreach ($terms as $term) {
                echo '<li class="grop-filte_btn" data-filter=".cat-'. preg_replace('/\s+/', "", strtolower($term)) .'">' . str_replace('-', " ", strtolower($term)) . '</li>';
               }
            }
          } else {
            $terms = get_terms('tribe_events_cat');
            $count = count($terms);
            $i=0;
            $term_list = '';
            if ($count > 0) {
              foreach ($terms as $term) {
                $i++;
                $term_list .= '<li class="grop-filte_btn" data-filter=".cat-'. $term->slug .'">' . $term->name . '</li>';
                if ($count != $i) {
                  $term_list .= '';
                } else {
                  $term_list .= '';
                }
              }
              echo $term_list;
            }
          }
        ?>
      </ul>
		</div>
    <?php
    }
  if ($event_style == 'event-grid') {
    echo '<div class="grop-filter_content  grop-evnfilter_content">';
  }
    // Pagination
    $paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;

    $args = array(
      // other query params here,
      'paged' => $paged,
      'post_type' => 'tribe_events',
      'posts_per_page' => (int)$event_limit,
      'tribe_events_cat' => esc_attr($event_show_category),
      'orderby' => $event_orderby,
      'order' => $event_order
    );

    $grop_evnt = new WP_Query( $args ); ?>

      <?php
      if ($grop_evnt->have_posts()) : while ($grop_evnt->have_posts()) : $grop_evnt->the_post();

        // Category
        global $post;
        $terms = wp_get_post_terms($post->ID,'tribe_events_cat');
        foreach ($terms as $term) {
          $cat_class = 'cat-' . $term->slug;
        }
        $count = count($terms);
        $i=0;
        $cat_class = '';
        if ($count > 0) {
          foreach ($terms as $term) {
            $i++;
            $cat_class .= 'cat-'. $term->slug .' ';
            if ($count != $i) {
              $cat_class .= '';
            } else {
              $cat_class .= '';
            }
          }
        }
        // Featured Image
        $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
        $large_image = $large_image[0];
        if ($large_image) {
          if(class_exists('Aq_Resize')) {
            $event_grid_image = aq_resize( $large_image, '370', '230', true );
            $event_list_image = aq_resize( $large_image, '320', '200', true );
          } else {
            $event_grid_image = $large_image;
            $event_list_image = $large_image;
          }
        }
        $event_grid_image = $event_grid_image ? $event_grid_image : GROPPE_PLUGIN_ASTS . '/images/1000x800.jpg';
        $event_list_image = $event_list_image ? $event_list_image : GROPPE_PLUGIN_ASTS . '/images/1000x800.jpg';

        $event_popup_options = get_post_meta( get_the_ID(), '_event_popup_form_metabox', true );
        if ($event_popup_options) {
          if ($event_popup_options['popup_btn']){
            $event_contact_btn = $event_popup_options['popup_btn'];
            $event_popup_form_id = $event_popup_options['form_id'];
            $event_contact_btn_type = $event_popup_options['contact_btn_type'];
            $event_contact_btn_link = $event_popup_options['contact_btn_link'] ? $event_popup_options['contact_btn_link'] : $contact_btn_link;
          } elseif($event_popup_btn) {
            $event_contact_btn = $event_popup_btn;
            $event_popup_form_id = $popup_form_id;
            $event_contact_btn_type = $contact_btn_type;
            $event_contact_btn_link = $contact_btn_link ? $contact_btn_link : cs_get_option('contact_btn_link');
          } else {
            $event_contact_btn = cs_get_option('popup_btn');
            $event_popup_form_id = cs_get_option('form_id');
            $event_contact_btn_type = cs_get_option('contact_btn_type');
            $event_contact_btn_link = cs_get_option('contact_btn_link');
          }
        } elseif($event_popup_btn) {
          $event_contact_btn = $event_popup_btn;
          $event_popup_form_id = $popup_form_id;
          $event_contact_btn_type = $contact_btn_type;
          $event_contact_btn_link = $contact_btn_link ? $contact_btn_link : cs_get_option('contact_btn_link');
        } else {
          $event_contact_btn = cs_get_option('popup_btn');
          $event_popup_form_id = cs_get_option('form_id');
          $event_contact_btn_type = cs_get_option('contact_btn_type');
          $event_contact_btn_link = cs_get_option('contact_btn_link');
        }

      $post_meta = get_post_meta( get_the_ID() );
      $s_date = $post_meta['_EventStartDate'];
      $s_createDate = new DateTime($s_date[0]);
      $s_year = $s_createDate->format('Y');
      $s_month = $s_createDate->format('M');
      $s_day = $s_createDate->format('d');
      $s_full_date = $s_createDate->format('d M Y');
      $s_hour = $s_createDate->format('H:i a');
      // end date
      $e_date = $post_meta['_EventEndDate'];
      $e_createDate = new DateTime($e_date[0]);
      $e_year = $e_createDate->format('Y');
      $e_month = $e_createDate->format('M');
      $e_day = $e_createDate->format('d');
      $e_full_date = $e_createDate->format('d M Y');
      $e_hour = $e_createDate->format('H:i a');

      $venu_details = tribe_get_venue_details ( get_the_ID() );
        if ($event_style === 'event-grid') { ?>
          <div class="grop-filter_single_col  <?php echo esc_attr($cat_class); ?>">
            <div class="grop-evnt_fltr_itm_warp">
              <div class="grop-ucoming_evnt_sigl_item">
                <div class="grop-ucoming_evnt_image">
                  <img src="<?php echo esc_url($event_grid_image); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                </div>
                <div class="grop-ucoming_evnt_cont_warp">
						      <div class="grop-ucoming_evnt_txt_cont">
                    <div class="grop-ucoming_evnt_date">
                      <?php echo esc_html__( $s_full_date, 'groppe-core' ); ?>
                    </div>
                    <h4 class="grop-ucoming_evnt_title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html(the_title()); ?></a></h4>
                    <?php if(!empty($venu_details['address']) || !empty($venu_details['linked_name'])){ ?>
                    <p class="grop-ucoming_evnt_location">
                      <?php
                      if(!empty($venu_details['linked_name'])){
                        echo '<i class="fa fa-map-marker"></i>';
                        echo $venu_details['linked_name'];
                      } else {
                        echo $venu_details['address'];
                      } ?>
                    </p>
                    <?php } ?>
                    <a class="grop-btn grop-btn_overly grop-ucom_evnt_dtls_btn" href="<?php esc_url(the_permalink()); ?>"><span><?php echo esc_html__('Details', 'groppe' ); ?></span></a><!--/end-->
                  </div><!--/Home upcoming events text content end-->
                      <div class="grop-fix  grop-ucoming_evnt_footr">
                        <div class="grop-fix  grop-float_left  grop-ucoming_evnt_social">
                          <div class="grop-ucoevnt_socil">
                            <?php if ($event_contact_btn) {
                              if ($event_contact_btn_type === 'popup') { ?>
                                <a class="grop-evs_evpop" href="mailto:?subject=<?php print(urlencode( get_the_title() )); ?>&amp;body=<?php print(urlencode( get_permalink( get_the_ID() ) )); ?>" data-toggle="modal" data-target="#<?php echo $event_popup_form_id; ?>"><i class="fa fa-envelope-o"></i></a>
                              <?php } else { ?>
                                <a href="<?php echo esc_url($event_contact_btn_link); ?>" target="_blank" class="grop-evs_evpop"><i class="fa fa-envelope-o"></i></a>
                              <?php }
                            }
                            if ($event_share_btn) {
                              groppe_event_share_option();
                            } ?>
                          </div>
                        </div><!--/end-->

                        <!--Home upcoming events time start \-->
                        <div class="grop-float_right  grop-ucoming_evnt_time">
                          <i class="fa fa-clock-o"></i><?php echo tribe_get_start_time().' - '.tribe_get_end_time(); ?>
                        </div><!--/end-->

                      </div><!--/end-->

    						</div>
              </div>
            </div>
          </div>
          <div class="grop-model_popup_warp">
          <?php $pop_id = $event_popup_form_id ? 'id='.$event_popup_form_id : ''; ?>
            <div <?php echo $pop_id; ?> class="modal fade" role="dialog">
              <div class="modal-dialog  grop-model_dialog">
                <div class="modal-content  grop-model_content">
                  <div class="modal-header grop-model_header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button><!--/ close btn end-->
                    <div class="grop-resform_headr">
                      <?php
                      $args = array('post_type' => 'wpcf7_contact_form', 'p'=>$event_popup_form_id);
                       $cf7Forms = get_posts( $args );
                       $form_titles = get_the_title( $event_popup_form_id );
                      echo esc_attr($form_titles); ?>
                    </div>
                  </div>
                  <!-- Modal Popup content body start\-->
                  <div class="modal-body grop-model_body">
                    <div class="grop-resform_form  grop-contact_poup_form">
                      <?php echo do_shortcode( '[contact-form-7 id="'. $event_popup_form_id .'"]' ); ?>
                    </div>
                  </div><!--/ Modal Popup content body end-->
                  <div class="modal-footer grop-model_footer">
                  </div>
                </div>
              </div>
            </div>
          </div>
        <?php
        } else {
      ?>
        <div class="grop-fix  grop-evnt_list_item">
          <div class="grop-float_left  grop-ucoming_evnt_image">
            <img src="<?php echo esc_url($event_list_image); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
            <div class="text-center  grop-evnt_list_date">
              <span class="grop-evnt_d"><?php echo $s_day; ?></span>
              <span class="grop-evnt_m-y">
                <?php echo $s_month; ?> <br> <?php echo esc_html__( $s_year, 'groppe-core' ); ?>
              </span>
            </div><!--/end-->
          </div>
          <div class="grop-fix  grop-ucoming_evnt_cont_warp">
            <div class="grop-ucoming_evnt_txt_cont">
              <!--Home upcoming events title start \-->
              <h4 class="grop-ucoming_evnt_title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html(the_title()); ?></a></h4>
              <div class="grop-ucoming_evnt_time">
                <i class="fa fa-clock-o"></i><?php echo tribe_get_start_time().' - '.tribe_get_end_time(); ?>
              </div>
              <?php if(!empty($venu_details['address']) || !empty($venu_details['linked_name'])){ ?>
              <p class="grop-ucoming_evnt_location">
                <?php
                if(!empty($venu_details['linked_name'])){
                  echo '<i class="fa fa-map-marker"></i>';
                  echo $venu_details['linked_name'];
                } else {
                  echo $venu_details['address'];
                } ?>
              </p>
              <?php } ?>
              <p>
                <?php
                  if (groppe_framework_active()) {
                    groppe_excerpt($short_content);
                  } else {
                    the_excerpt();
                  }
                ?>
              </p>
            </div><!--/Home upcoming events text content end-->
            <!--Home upcoming events footer  content start \-->
            <div class="grop-fix  grop-ucoming_evnt_footr">
              <div class="grop-fix  grop-float_left  grop-ucoming_evnt_social">
                <div class="grop-ucoevnt_socil">
                  <a class="grop-evs_evpop" href="mailto:?subject=<?php print(urlencode( get_the_title() )); ?>&amp;body=<?php print(urlencode( get_permalink( get_the_ID() ) )); ?>" data-toggle="modal" data-target="#<?php echo $event_popup_form_id; ?>"><i class="fa fa-envelope-o"></i></a>
                  <?php groppe_event_share_option(); ?>
                </div>
              </div>
            </div>
          </div>
          <div class="grop-model_popup_warp">
          <?php $pop_id = $event_popup_form_id ? 'id='.$event_popup_form_id : ''; ?>
            <div <?php echo $pop_id; ?> class="modal fade" role="dialog">
              <div class="modal-dialog  grop-model_dialog">
                <div class="modal-content  grop-model_content">
                  <div class="modal-header grop-model_header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button><!--/ close btn end-->
                    <div class="grop-resform_headr">
                      <?php
                      $args = array('post_type' => 'wpcf7_contact_form', 'p'=>$event_popup_form_id);
                       $cf7Forms = get_posts( $args );
                       $form_titles = get_the_title( $event_popup_form_id );
                      echo esc_attr($form_titles); ?>
                    </div>
                  </div>
                  <!-- Modal Popup content body start\-->
                  <div class="modal-body grop-model_body">
                    <div class="grop-resform_form  grop-contact_poup_form">
                      <?php echo do_shortcode( '[contact-form-7 id="'. $event_popup_form_id .'"]' ); ?>
                    </div>
                  </div><!--/ Modal Popup content body end-->
                  <div class="modal-footer grop-model_footer">
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

      <?php
        }
      endwhile;
      endif;
      wp_reset_postdata();
    if ($event_style == 'event-grid') {
      echo '</div>';
    }?>

    </div>
    <?php
    if ($event_pagination) {
      groppe_custom_paging_nav($grop_evnt->max_num_pages,"",$paged);
    }

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'grop_event', 'grop_event_function' );

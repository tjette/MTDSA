<?php
/* donors */
if ( !function_exists('grop_donors_function')) {
  function grop_donors_function( $atts, $content = NULL ) {
    extract(shortcode_atts(array(
      'class'  => '',
      'donors_column'  => '',
      'perticular_donors_member'  => '',
      'donors_limit'  => '',
    ), $atts));

    $donors_column = ( $donors_column ) ?  $donors_column : 'col-3';

    // Turn output buffer on
    ob_start();

    if (!empty($perticular_donors_member)) {
      $perticular_donors_member = explode(',', $perticular_donors_member);
    } else {
      $perticular_donors_member = array();
    }
    if ( class_exists( 'Give' ) ) {
      $args = array(
        'number' => (int) $donors_limit,
        'id' => $perticular_donors_member,
      );
      $donors = Give()->customers->get_customers( $args );
    } else {
      $donors = array();
    }
?>

    <div class="grop-donors <?php echo esc_attr( $class); ?>"> <!-- donors Starts -->
      <div class="container" style="width: 100%;">
        <div class="row  grop-dnatrsd_warp">
        <?php
          $args = array(
            'number' => $donors_limit,
          );
          foreach ($donors as $key => $donor) :
            $avatar_data = get_avatar_data( $donor->id, null );
            $have_avatar = $avatar_data['found_avatar'];
            $avatar_url = get_avatar_url( $donor->id, null );
            if ($have_avatar == true) {
              $avatar_url =  $avatar_url;
            } else {
               $avatar_url = GROPPE_PLUGIN_ASTS.'/images/avatar.png';
            }
            ?>
            <div class="text-center  grop-float_left  grop-dnatrsd_single <?php echo esc_attr( $donors_column ); ?>">
              <div class="grop-dnatrsd_cont_warp">
                <div class="grop-dnatrsd_cont">
                  <!--Volunteers people media image start \-->
                  <div class="grop-dnatrsd_media">
                    <!-- <img src="<?php echo esc_url( $avatar_url ); ?>" alt="<?php echo esc_attr( $donor->name ); ?>"> -->
                    <?php echo get_avatar( $donor->id, 120 ); ?>
                  </div><!--/Volunteers people media end-->
                  <h5 class="grop-dnatrsd_name"><?php echo $donor->name; ?></h5>
                  <h5 class="grop-dnatrsd_amount"> <?php echo esc_html__( 'Donated :', 'groppe-core' ); ?> <span><?php  echo  give_currency_filter( give_format_amount( $donor->purchase_value ) ); ?></span></h5>
                </div>
              </div>
            </div><!--/Volunteers people single intro end-->
            <?php
          endforeach;
          wp_reset_postdata();
        ?>
        </div> <!-- row -->
      </div> <!-- container -->
    </div> <!-- donors End -->
    <?php
    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'grop_donors', 'grop_donors_function' );
<?php
/* ==========================================================
  Impact Carousel
=========================================================== */
if ( !function_exists('grop_story_func')) {
  function grop_story_func( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'items'  => '',
      'story_column'  => '',
      'class'  => '',
    ), $atts));
    $items = (array) vc_param_group_parse_atts( $items );
    $get_carousel_item = array();
    foreach ( $items as $story_logo ) {
      $each_item = $story_logo;
      $each_item['image'] = isset( $story_logo['image'] ) ? $story_logo['image'] : '';
      $each_item['title'] = isset( $story_logo['title'] ) ? $story_logo['title'] : '';
      $get_carousel_item[] = $each_item;
    }

    if ($story_column == 'col-2') {
      $col_class = 'col-md-6 col-sm-6 col-xs-6';
    } elseif ($story_column == 'col-3') {
      $col_class = 'col-md-4 col-sm-6 col-xs-6';
    } elseif ($story_column == 'col-4') {
      $col_class = 'col-sm-6 col-md-3 col-xs-6';
    } elseif ($story_column == 'col-5') {
      $col_class = 'col-5';
    } else{
      $col_class = '';
    }

    ob_start();

  // $description =  nl2br( $description, false );
?>
<section class="story-area <?php echo esc_attr( $class ); ?>">
  <div class="row">
      <?php
      foreach ( $get_carousel_item as $each_item ) {
        $groppe_alt = get_post_meta($each_item['image'], '_wp_attachment_image_alt', true);
        $image_url = wp_get_attachment_url( $each_item['image'] ); 
        $title = $each_item['title']; ?>
        <div class="grop-stry-item <?php echo esc_attr( $col_class ); ?>">
          <div class="grop-suess_strisst2_post_item">
            <div class="grop-suess_strisst2_media">
              <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $groppe_alt ); ?>" />
            </div>
            <div class="grop-suess_strisst2_pst_txt">
              <h4><?php echo $title; ?></h4>
            </div>
          </div>
        </div>
      <?php } ?>
  </div>
</section>
<?php
    return ob_get_clean();
  }
}
add_shortcode( 'grop_story', 'grop_story_func' );

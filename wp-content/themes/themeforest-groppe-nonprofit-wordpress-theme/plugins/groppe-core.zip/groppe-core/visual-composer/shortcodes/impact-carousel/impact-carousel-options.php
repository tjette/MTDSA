<?php
/**
 * Impact Carousel - Shortcode Options
 */
add_action( 'init', 'impact_carousel_vc_map' );
if ( ! function_exists( 'impact_carousel_vc_map' ) ) {
  function impact_carousel_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Impact Carousel", 'groppe-core'),
      "base" => "grop_impact_carousel",
      "description" => esc_html__( "Impact Carousel", 'groppe-core'),
      "icon" => "fa fa-shield color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        // Impact Logos
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Title', 'groppe-core'),
          "param_name"  => "impact_title",
          "value"       => "",
          "description" => esc_html__( "Include your impact carousel title", 'groppe-core')
        ),
        array(
          "type"        => 'textarea',
          "heading"     => esc_html__('Description', 'groppe-core'),
          "param_name"  => "impact_description",
          "value"       => "",
          "description" => esc_html__( "Include your impact carousel description", 'groppe-core')
        ),
        array(
          "type"        => 'textarea',
          "heading"     => esc_html__('Content', 'groppe-core'),
          "param_name"  => "impact_content",
          "value"       => "",
          "description" => esc_html__( "Explain about section content.", 'groppe-core')
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Download Button Text', 'groppe-core'),
          "param_name"  => "btn_txt",
          "value"       => "",
          "description" => esc_html__( "Include your impact carousel download button text", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Download Button Link', 'groppe-core'),
          "param_name"  => "btn_link",
          "value"       => "",
          "description" => esc_html__( "Include your impact carousel download button link", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "switcher",
          "heading" => __( "Open New Tab?", 'groppe-core' ),
          "param_name" => "open_link",
          "std" => false,
          'value' => '',
          "on_text" => __( "Yes", 'groppe-core' ),
          "off_text" => __( "No", 'groppe-core' ),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),

        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Impact Images', 'groppe-core' ),
          'param_name' => 'items',
          'params' => array(
            array(
              'type' => 'attach_image',
              'value' => '',
              "admin_label"=> true,
              'heading' => esc_html__( 'Upload Image', 'groppe-core' ),
              'param_name' => 'image',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Image Title', 'groppe-core' ),
              'param_name' => 'title',
            )
          )
        ),
        GroppeLib::vt_class_option(),

        // Carousel
        GroppeLib::vt_notice_field(esc_html__( "Carousel Options", 'groppe-core' ),'bsic_opt','cs-warning', 'Carousel'), // Notice
        GroppeLib::vt_carousel_nav(), // nav
        GroppeLib::vt_carousel_dots(), // dots
        GroppeLib::vt_carousel_loop(), // Loop
        GroppeLib::vt_carousel_items(), // Items
        GroppeLib::vt_carousel_margin(), // Margin
        GroppeLib::vt_carousel_autoplay_timeout(), // Autoplay Timeout
        GroppeLib::vt_carousel_autoplay(), // Autoplay
        GroppeLib::vt_carousel_animateout(), // Animate Out
        GroppeLib::vt_carousel_mousedrag(), // Mouse Drag

      )
    ) );
  }
}

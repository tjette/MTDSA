<?php
/**
 * Form - Shortcode Options
 */
add_action( 'init', 'donation_form_vc_map' );
if ( ! function_exists( 'donation_form_vc_map' ) ) {
  function donation_form_vc_map() {
  $causes = get_posts( 'post_type="give_forms"&numberposts=-1' );
  $all_causes = array();
  if ( $causes ) {
    foreach ( $causes as $cause ) {
      $all_causes[ $cause->post_title ] = $cause->ID;
    }
  } else {
    $all_causes[ esc_html__( 'No contact forms found', 'groppe-core' ) ] = 0;
  }

    vc_map( array(
      "name" => esc_html__( "Donation Form", 'groppe-core'),
      "base" => "donation_form",
      "description" => esc_html__( "Donation Form Styles", 'groppe-core'),
      "icon" => "fa fa-briefcase color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Form Title", 'groppe-core' ),
          "param_name" => "form_title",
          "description" => esc_html__( "Enter your form title", 'groppe-core'),
        ),
        GroppeLib::vt_class_option(),
        array(
          "type" => "checkbox",
          "heading" => esc_html__( "Show Cause", 'groppe-core' ),
          "param_name" => "show_cause",
          "value" => $all_causes,
          "admin_label" => true,
          "description" => esc_html__( "Select featured cause.", 'groppe-core'),
        ),
      )
    ) );
  }
}

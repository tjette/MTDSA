<?php
/**
 * Title - Shortcode Options
 */
add_action( 'init', 'grop_title_vc_map' );
if ( ! function_exists( 'grop_title_vc_map' ) ) {
  function grop_title_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Groppe Title", 'groppe-core'),
      "base" => "grop_title",
      "description" => esc_html__( "Title Styles", 'groppe-core'),
      "icon" => "fa fa-header color-orange",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(        
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Title Type', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Section Title', 'groppe-core' ) => 'section',
            esc_html__( 'Title Tag', 'groppe-core' ) => 'tag',
          ),
          'admin_label' => true,
          'param_name' => 'title_type',
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),       
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Title Tags', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Div', 'groppe-core' ) => 'div',
            esc_html__( 'H1', 'groppe-core' ) => 'h1',
            esc_html__( 'H2', 'groppe-core' ) => 'h2',
            esc_html__( 'H3', 'groppe-core' ) => 'h3',
            esc_html__( 'H4', 'groppe-core' ) => 'h4',
            esc_html__( 'H5', 'groppe-core' ) => 'h5',
            esc_html__( 'H6', 'groppe-core' ) => 'h6',
          ),
          'admin_label' => true,
          'param_name' => 'title_tag',
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Section Class ", 'groppe-core' ),
          "param_name" => "section_class",
          'value' => '',
          'dependency' => array(
            'element' => 'title_type',
            'value' => 'section',
          ),
        ),
        array(
          "type" => "textarea",
          "heading" => esc_html__( "Title", 'groppe-core' ),
          "param_name" => "title",
          'value' => '',
          'admin_label' => true,
          "description" => esc_html__( "Enter your title.", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-12 vc_column vt_field_space',
        ),
        array(
          "type"      => 'textarea',
          "heading"   => esc_html__('Description', 'groppe-core'),
          "param_name" => "description",
          "value"      => "",
          "description" => esc_html__( "Enter your sub title here.", 'groppe-core'),
          'dependency' => array(
            'element' => 'title_type',
            'value' => 'section',
          ),
        ),
        GroppeLib::vt_class_option(),

        // Styling
        array(
          "type"        => "notice",
          "heading"     => esc_html__( "Title styles", 'groppe-core' ),
          "param_name"  => 'lsng_opt',
          'class'       => 'cs-warning',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'value'       => '',
        ),
        array(
          "type" => "dropdown",
          "heading" => esc_html__( "Text Align", 'groppe-core' ),
          "param_name" => "text_align",
          'value' => array(
            esc_html__( 'Center', 'groppe-core' ) => 'text-center',
            esc_html__( 'Left', 'groppe-core' ) => 'text-left',
            esc_html__( 'Right', 'groppe-core' ) => 'text-right',
          ),
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-12 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Title Size ", 'groppe-core' ),
          "param_name" => "title_size",
          'value' => '',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type" => "colorpicker",
          "heading" => esc_html__( "Title Color", 'groppe-core' ),
          "param_name" => "title_color",
          'value' => '',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Title Bottom Space ", 'groppe-core' ),
          "param_name" => "title_bottom_space",
          'value' => '',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type"        => "notice",
          "heading"     => esc_html__( "Description styles", 'groppe-core' ),
          "param_name"  => 'lsng_opt',
          'class'       => 'cs-warning',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'value'       => '',
          'dependency' => array(
            'element' => 'title_type',
            'value' => 'section',
          ),
        ),
        array(
          "type" => "colorpicker",
          "heading" => esc_html__( "Description Color", 'groppe-core' ),
          "param_name" => "desc_color",
          'value' => '',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
          'dependency' => array(
            'element' => 'title_type',
            'value' => 'section',
          ),
        ),
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Description Size ", 'groppe-core' ),
          "param_name" => "desc_size",
          'value' => '',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
          'dependency' => array(
            'element' => 'title_type',
            'value' => 'section',
          ),
        ),
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Description Line Height ", 'groppe-core' ),
          "param_name" => "desc_line_height",
          'value' => '',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
          'dependency' => array(
            'element' => 'title_type',
            'value' => 'section',
          ),
        ),
        // Design Tab
        array(
          "type" => "css_editor",
          "heading" => esc_html__( "Custom Style", 'groppe-core' ),
          "param_name" => "css",
          "group" => esc_html__( "Design", 'groppe-core'),
        ),

      )
    ) );
  }
}

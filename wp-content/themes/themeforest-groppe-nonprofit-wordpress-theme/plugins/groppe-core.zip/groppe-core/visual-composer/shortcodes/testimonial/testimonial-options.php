<?php
/**
 * Testimonial - Shortcode Options
 */
add_action( 'init', 'testimonial_vc_map' );
if ( ! function_exists( 'testimonial_vc_map' ) ) {
  function testimonial_vc_map() {
  $testi = get_posts( 'post_type="testimonial"&numberposts=-1' );
  $testimonials = array();
  if ( $testi ) {
    foreach ( $testi as $team ) {
      $testimonials[ $team->post_title ] = $team->ID;
    }
  } else {
    $testimonials[ esc_html__( 'No Testimonials Found', 'groppe-core' ) ] = 0;
  }
    vc_map( array(
    "name" => esc_html__( "Testimonial", 'groppe-core'),
    "base" => "grop_testimonial",
    "description" => esc_html__( "Testimonial Style", 'groppe-core'),
    "icon" => "fa fa-comment color-grey",
    "category" => GroppeLib::grop_cat_name(),
    "params" => array(

      array(
        "type" => "dropdown",
        "heading" => esc_html__( "Testimonial Column", 'groppe-core' ),
        "param_name" => "testimonial_column",
        "value" => array(
          esc_html__('Select Column', 'groppe-core') => '',
          esc_html__('Column One', 'groppe-core') => 'col-md-12',
          esc_html__('Column Two', 'groppe-core') => 'col-md-6',
          esc_html__('Column Three', 'groppe-core') => 'col-md-4',
        ),
        "admin_label" => true,
        "description" => esc_html__( "Select testimonial column.", 'groppe-core'),
      ),

      array(
        "type"        => "notice",
        "heading"     => esc_html__( "Listing", 'groppe-core' ),
        "param_name"  => 'lsng_opt',
        'class'       => 'cs-warning',
        'value'       => '',
      ),
      array(
        "type" => "checkbox",
        "heading" => esc_html__( "Show Testimonial", 'sewell-core' ),
        "param_name" => "perticular_testi",
        "value" => $testimonials,
        "admin_label" => true,
        "description" => esc_html__( "Select Testimonials.", 'sewell-core'),
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Limit', 'groppe-core'),
        "param_name"  => "testimonial_limit",
        "value"       => "",
        'admin_label' => true,
        "description" => esc_html__( "Enter the number of items to show.", 'groppe-core'),
      ),
      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Order', 'groppe-core' ),
        'value' => array(
          esc_html__( 'Select Testimonial Order', 'groppe-core' ) => '',
          esc_html__('Asending', 'groppe-core') => 'ASC',
          esc_html__('Desending', 'groppe-core') => 'DESC',
        ),
        'param_name' => 'testimonial_order',
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Order By', 'groppe-core' ),
        'value' => array(
          esc_html__('None', 'groppe-core') => 'none',
          esc_html__('ID', 'groppe-core') => 'ID',
          esc_html__('Author', 'groppe-core') => 'author',
          esc_html__('Title', 'groppe-core') => 'title',
          esc_html__('Date', 'groppe-core') => 'date',
        ),
        'param_name' => 'testimonial_orderby',
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      GroppeLib::vt_class_option(),

      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Content Color', 'groppe-core'),
        "param_name"  => "content_color",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Name Color', 'groppe-core'),
        "param_name"  => "name_color",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Profession Color', 'groppe-core'),
        "param_name"  => "profession_color",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      // Size
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Content Size', 'groppe-core'),
        "param_name"  => "content_size",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Name Size', 'groppe-core'),
        "param_name"  => "name_size",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Profession Size', 'groppe-core'),
        "param_name"  => "profession_size",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),

      ), // Params
    ) );
  }
}
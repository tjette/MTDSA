<?php
/* ==========================================================
  Contact Adress
=========================================================== */
if ( !function_exists('location_carousel_func')) {
  function location_carousel_func( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'title'  => '',
      'title_link'  => '',
      'description'  => '',
      'items'  => '',
      'class'  => '',
      'section_class'  => '',
      // Carousel
      'carousel_items'  => '',
      'carousel_margin'  => '',
      'carousel_dots'  => '',
      'carousel_nav'  => '',
      'carousel_autoplay_timeout'  => '',
      'carousel_autoplay'  => '',
      'carousel_tablet'  => '',
      'carousel_mobile'  => '',
    ), $atts));

    // Carousel Data's
    $carousel_items = $carousel_items ? 'data-items="'. $carousel_items .'"' : 'data-items="3"';
    $carousel_margin = $carousel_margin ? 'data-margin="'. $carousel_margin .'"' : 'data-margin="28"';
    $carousel_dots = $carousel_dots ? 'data-dots="'. $carousel_dots .'"' : 'data-dots="false"';
    $carousel_navv = $carousel_nav ? 'data-nav="'. $carousel_nav .'"' : 'data-nav="false"';
    $carousel_autoplay = $carousel_autoplay ? 'data-autoplay="'. $carousel_autoplay .'"' : '';
    $carousel_tablet = $carousel_tablet ? 'data-items-tablet="'. $carousel_tablet .'"' : 'data-items-tablet="2"';
    $carousel_mobile = $carousel_mobile ? 'data-items-mobile="'. $carousel_mobile .'"' : 'data-items-mobile="1"';


    $addresses = (array) vc_param_group_parse_atts( $items );
    $get_contact_address = array();
    foreach ( $addresses as $addresses_info ) {
      $each_item = $addresses_info;
      $each_item['item_title'] = isset( $addresses_info['item_title'] ) ? $addresses_info['item_title'] : '';
      $each_item['item_description'] = isset( $addresses_info['item_description'] ) ? $addresses_info['item_description'] : '';
      $each_item['prefix'] = isset( $addresses_info['prefix'] ) ? $addresses_info['prefix'] : '';
      $each_item['address_title'] = isset( $addresses_info['address_title'] ) ? $addresses_info['address_title'] : '';
      $each_item['url'] = isset( $addresses_info['url'] ) ? $addresses_info['url'] : '';
      $get_contact_address[] = $each_item;
    }
    ob_start();
  if ($description) {
    $description =  nl2br( $description, false );
  } else {
    $description =  '';
  }
?>
<section class="grop-offic_loc_area <?php echo esc_attr( $section_class ); ?> <?php echo esc_attr( $class ); ?>">
    <div class="row">
      <div class="col-md-3">
        <!--Office Location  start \-->
        <div class="grop-offic_loc_txt">
        <?php
          if ($title) {
            if ($title_link){
              echo '<h2><a href="'.esc_url($title_link).'">'.$title.'</a></h2>';
            } else {
              echo '<h2>'.$title.'</h2>';
            }
          }
          if (!empty($description)) {
            echo '<p>'.$description.'</p>';
          }
        ?>  
        </div><!--/end-->
        <?php if ( $carousel_nav ) { ?>
              <div class="grop-officlc_caro_nav"></div>
          <?php  } ?>
      </div>
      <div class="col-md-9">
      
        <!--Office Location carousel start \-->
        <div class="owl-carousel grop-offic_loc_carousel" data-loop="true" <?php echo $carousel_items .' '. $carousel_margin .' '. $carousel_dots .' '. $carousel_autoplay .' '. $carousel_navv .' '. $carousel_tablet .' '. $carousel_mobile; ?>>

        <?php
          foreach ( $get_contact_address as $each_item ) {
            $item_title = $each_item['item_title'];
            $item_description = $each_item['item_description'];
            $address_title = $each_item['address_title'];
            $url = $each_item['url'];
            $prefix = $each_item['prefix'];
            if ( !empty($prefix) ) {
              $prefix = $prefix.':';
            } else {
              $prefix = '';
            } ?>
            <div class="grop-officlc_single">
              <div class="grop-offic_loc"><?php echo esc_attr($item_title); ?></div>
              <address class="grop-offic_locfull">
              <p><?php echo esc_attr($item_description);?></p>
              <?php
                if ( !empty($url) && !empty($address_title) ) {
                  echo '<span>'.$prefix.'<a href="'.$url.'">'.$address_title.'</a></span>';
                } else {
                  echo '<span>'.$prefix.''.$address_title.'</span>';
                } 
              ?>
              </address>
              <a class="grop-btn grop-btn_overly grop-officloc_btn" href="">
                <span><i class="fa fa-map-marker"></i>Direction</span>
              </a>
                
            </div>
          <?php } ?>
          </div><!--/Office Location carousel end-->
        
      </div>
    </div>
</section>
<?php
    return ob_get_clean();
  }
}
add_shortcode( 'location_carousel', 'location_carousel_func' );

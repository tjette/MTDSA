<?php
/* ===========================================================
    Pricing
=========================================================== */
if ( !function_exists('contact_social_function')) {
  function contact_social_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'title'         => '',
      'description'     => '',
      'icon_items'         => '',
      'class'         => '',
    ), $atts));

    // Group Field
    $icon_items = (array) vc_param_group_parse_atts( $icon_items );

    // Atts
    $uniqtab     = uniqid();
    $title  = $title ? '<h3>'.$title.'</h3>' : '';
    $description  = $description ? '<p>'.$description.'</p>' : '';

    // Output
    $output = '<div class="grop-contact_social_area '.$class.'"><div class="container"><div class="text-center  grop-contact_social">'.$title.$description.'<ul class="list-inline  grop-csol_list">';

    // Foreach features
    $i = 1;
    foreach ( $icon_items as $list_item ) {

      $icon = $list_item['select_icon'] ? $list_item['select_icon'] : '';
      $icon_link = $list_item['icon_link'] ? $list_item['icon_link'] : '';

      if ($icon_link) {
        $output .= '<li><a href="'.esc_url($icon_link).'" target="_blank"><i class="'.$icon.'"></i></a></li>';
      } else {
        $output .= '<li><i class="'.$icon.'"></i></li>';
      }

    }
    $output .= '</ul></div></div></div>';

    return $output;

  }
}
add_shortcode( 'contact_social', 'contact_social_function' );

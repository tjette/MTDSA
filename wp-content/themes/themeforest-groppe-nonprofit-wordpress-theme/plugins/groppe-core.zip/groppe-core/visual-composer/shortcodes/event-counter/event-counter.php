<?php
/* ==========================================================
  Partner
=========================================================== */
if ( !function_exists('grop_event_counter_function')) {
  function grop_event_counter_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'event_title'  => '',
      'button_text'  => '',
      'heading_text'  => '',
      'event_url'  => '',
      'event_date'  => '',
      'class'  => '',
    ), $atts));

    $button_text = $button_text ? $button_text : esc_html__( 'Events Details', 'groppe-core' );
    $heading_text = $heading_text ? $heading_text : esc_html__( 'Upcoming Event', 'groppe-core' );

    $diff = strtotime($event_date)-time();
    ob_start();
    ?>
      <section class="grop-countdown_area">
        <div class="container">
          <div class="row">
            <!--  countdown area Upcoming Event text start  \-->
            <div class="col-md-4">
              <div class="grop-cntdwn_upevt_warp">
                <!--  icon start  \-->
                <div class="grop-float_left  grop-cntdwn_upevt_icn">
                  <i class="fa fa-calendar"></i>
                </div><!--/  icon end-->
                
                <!--  Text  start  \-->
                <div class="grop-fix  grop-cntdwn_upevt_txt">
                  <h5><?php echo esc_html__( $heading_text, 'groppe-core' ); ?></h5>
                  <h4><?php echo esc_html__( $event_title, 'groppe-core' ); ?></h4>
                </div><!--/  Text end-->
              </div>
            </div><!--/  countdown area Upcoming Event text end-->
              
            <!--countdown  counter area start  \--> 
            <div class="col-md-8">
              <div class="grop-fix  grop-countdown_warp">
                <!--Events Details btn start  \-->  
                  <div class="grop-float_right  grop-cntdwn_evt_btn_wrp">
                    <a class="grop-btn grop-btn_overly grop-cntdwn_evt_btn" href="<?php echo esc_url( $event_url ); ?>">
                      <span><?php echo esc_html__( $button_text, 'groppe-core' ); ?></span>
                    </a>
                  </div>
                <!--countdown  clock counter start  \-->  
                <div class="grop-float_right grop-countdown">
                  <div class="grop-flipclock" data-clockface="DailyCounter" data-diff="<?php echo esc_attr( $diff ); ?>" data-autoplay="true" data-autostart="false" data-countdown="true" data-defaultlanguage="english" data-minimumdigits="0">
                  </div>
                </div><!--/countdown clock counter end-->
              </div>
            </div><!--/countdown counter area end-->  
          </div>
        </div>
      </section>

  <?php
    // Output
    return ob_get_clean();

  }
}
add_shortcode( 'grop_event_counter', 'grop_event_counter_function' );

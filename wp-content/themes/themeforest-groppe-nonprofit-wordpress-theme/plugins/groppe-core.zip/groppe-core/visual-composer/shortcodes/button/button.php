<?php
/* ==========================================================
  Buttons
=========================================================== */
if ( !function_exists('grop_link_function')) {
  function grop_link_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'button_style'  => '',
      'callout_btn'   => '',
      'use_wrapper'  => '',
      'link_items'  => '',
      'overlay_active' => '',
      'uset_list'  => '',
      'class'  => '',

      // Style
      'text_color' => '',
      'text_hover_color' => '',
      'background_color' => '',
      'bg_hover_color' => '',
      'border_color' => '',
      'border_width' => '',
      'border_hover_color' => '',
      'text_size' => '',
      'font_weight' => '',
      'btn_height' => '',
      'btn_line_height' => '',
      'css'   => '',
    ), $atts));

    // Design Tab
    $custom_css = ( function_exists( 'vc_shortcode_custom_css_class' ) ) ? vc_shortcode_custom_css_class( $css, ' ' ) : '';
    // Group Field
    $link_items = (array) vc_param_group_parse_atts( $link_items );
    $get_each_link = array();
    foreach ( $link_items as $link_item ) {
      $each_link = $link_item;
      $each_link['link'] = isset( $link_item['link'] ) ? $link_item['link'] : '';
      $each_link['title'] = isset( $link_item['title'] ) ? $link_item['title'] : '';
      $each_link['class'] = isset( $link_item['class'] ) ? $link_item['class'] : '';
      $each_link['open_link'] = isset( $link_item['open_link'] ) ? $link_item['open_link'] : '';
      $each_link['wrap_span'] = isset( $link_item['wrap_span'] ) ? $link_item['wrap_span'] : '';
      $each_link['overlay_active'] = isset( $link_item['overlay_active'] ) ? $link_item['overlay_active'] : '';
      $get_each_link[] = $each_link;
    }
foreach ( $get_each_link as $each_link ) {
  $title = $each_link['title'] ? $each_link['title'] : '';


  if ($title) {
      $in_class = '-'.sanitize_title($title);
    } else {
      $in_class = '';
    }

    // Shortcode Style CSS
    $e_uniqid        = uniqid();
    $inline_style  = '';
    // Button Text Color
    if ( $text_color ) {
      $inline_style .= '.grop-btn-'.$e_uniqid .$in_class.'.grop-btn span, .grop-btn-'. $e_uniqid .$in_class.'.grop-big_link span {';
      $inline_style .= ( $text_color ) ? 'color:'. $text_color .';' : '';
      $inline_style .= '}';
    }
    // Button Text Hover Color
    if ( $text_hover_color ) {
      $inline_style .= '.grop-btn-'. $e_uniqid .$in_class.':hover, .grop-btn-'. $e_uniqid .$in_class.'.grop-cause_remor_btn:hover, .grop-btn-'. $e_uniqid .$in_class.'.grop-btn span:hover, .grop-btn-'. $e_uniqid .$in_class.'.grop-big_link:hover span {';
      $inline_style .= ( $text_hover_color ) ? 'color:'. $text_hover_color .' !important;' : '';
      $inline_style .= '}';
    }
    // Text Size
    if ( $text_size ) {
      $inline_style .= '.grop-btn-'. $e_uniqid .$in_class.'{';
      $inline_style .= ( $text_size ) ? 'font-size:'. groppe_core_check_px($text_size) .';' : '';
      $inline_style .= '}';
    }
    // Font Weight
    if ( $font_weight ) {
      $inline_style .= '.grop-btn-'. $e_uniqid .$in_class.'.grop-cause_remor_btn, .grop-btn-'. $e_uniqid .$in_class.'.grop-big_link {';
      $inline_style .= ( $font_weight ) ? 'font-weight:'. $font_weight .'!important;' : '';
      $inline_style .= '}';
    }
    // Button Height
    if ( $btn_height ) {
      $inline_style .= '.grop-btn-'. $e_uniqid .$in_class.'.grop-cause_remor_btn, .grop-btn-'. $e_uniqid .$in_class.'.grop-big_link {';
      $inline_style .= ( $btn_height ) ? 'height:'. groppe_core_check_px($btn_height) .';' : '';
      $inline_style .= '}';
    }
    // Button Line Height
    if ( $btn_line_height ) {
      $inline_style .= '.grop-btn-'. $e_uniqid .$in_class.'.grop-cause_remor_btn, .grop-btn-'. $e_uniqid .$in_class.'.grop-big_link {';
      $inline_style .= ( $btn_line_height ) ? 'line-height:'. groppe_core_check_px($btn_line_height) .';' : '';
      $inline_style .= '}';
    }
    // Background/Border
    if ( $background_color || $border_color ) {
      $inline_style .= '.grop-btn-'. $e_uniqid .$in_class.'.grop-big_link, .grop-btn-'. $e_uniqid .$in_class.'.grop-cause_remor_btn {';
      $inline_style .= ( $background_color ) ? 'background:'. $background_color .' !important;' : '';
      $inline_style .= ( $border_color ) ? 'border-color: '. $border_color .' !important;' : '';
      $inline_style .= '}';
    }
    if ( $border_width ) {
      $inline_style .= '.grop-btn-'. $e_uniqid .$in_class.'.grop-cause_remor_btn, .grop-btn-'. $e_uniqid .$in_class.'.grop-big_link {';
      $inline_style .= ( $border_width ) ? 'border-width:'. groppe_core_check_px($border_width) .';' : '';
      $inline_style .= '}';
    }
    // Button Hover Color
    if ( $bg_hover_color || $border_hover_color ) {
      $inline_style .= '.grop-btn-'. $e_uniqid .$in_class.'.grop-big_link:hover, .grop-btn-'. $e_uniqid .$in_class.'.grop-big_link:focus, .grop-btn-'. $e_uniqid .$in_class.'.grop-big_link:active, .grop-btn-'. $e_uniqid .$in_class.'.grop-cause_remor_btn:hover, .grop-btn-'. $e_uniqid .$in_class.'.grop-cause_remor_btn:focus, .grop-btn-'. $e_uniqid .$in_class.'.grop-cause_remor_btn:active, .grop-btn-'. $e_uniqid .$in_class.'.grop-btn_overly:before {';
      $inline_style .= ( $bg_hover_color ) ? 'background:'. $bg_hover_color .' !important;' : '';
      $inline_style .= ( $border_hover_color ) ? 'border-color: '. $border_hover_color .' !important;' : '';
      $inline_style .= '}';
    }

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-btn-'. $e_uniqid.$in_class;

}
    

    if ($button_style === 'style-two') {
      $btn_style_cls = 'grop-big_links_warp';
      $btn_link_cls = 'col-sm-6 text-center grop-big_link';
    } elseif ($button_style === 'style-three') {
      $btn_style_cls = 'grop-hm-3sildcapst3_button';
      $btn_link_cls = 'grop-hm-3sildcapst3_btn';
    } else {
      if ($callout_btn) {
        $btn_style_cls = 'grop-float_right grop-callout_btn_warp';
        $btn_link_cls = 'grop-btn grop-btn_overly grop-callout_btn';
      } else {
        $btn_style_cls = 'grop-cause_remor_btn_warp';
        $btn_link_cls = 'grop-btn grop-btn_overly grop-cause_remor_btn';
      }
    }

    if ( $use_wrapper ) {
      $wrap_before = '<div class="'.esc_attr($btn_style_cls).'">';
      $wrap_after = '</div>';
    } else {
      $wrap_before = '';
      $wrap_after = '';
    }

    $output = $wrap_before;

      foreach ( $get_each_link as $each_link ) {
        $link = $each_link['link'] ? $each_link['link'] : '';
        $title = $each_link['title'] ? $each_link['title'] : '';
        $open_link = $each_link['open_link'] ? ' target="_blank"' : ''; 
        if ($button_style === 'style-two') {
          $overlay_cls = $each_link['overlay_active'] ? ' grop-big_link_overly_active' : ''; 
        } elseif ($button_style === 'style-three') {
          $overlay_cls = $each_link['overlay_active'] ? ' grop-btn_active' : ''; 
        } else {
          $overlay_cls = '';
        }

        if ($each_link['wrap_span']) {
          $output .= '<div class="calout-btn"><a'.$open_link.' class="'.$btn_link_cls.$overlay_cls.$styled_class.' '.$each_link['class'].' '.$custom_css.'" href="'.esc_url($link).'"><span>'.esc_html__($title, 'groppe-core').'</span></a></div>';
        } else {
          $output .= '<div class="calout-btn"><a'.$open_link.' class="'.$btn_link_cls.$overlay_cls.$styled_class.' '.$each_link['class'].' '.$custom_css.'" href="'.esc_url($link).'">'.esc_html__($title, 'groppe-core').'</a></div>';
        }

      }

    $output .= $wrap_after;

    return $output;
  }
}
add_shortcode( 'grop_link', 'grop_link_function' );

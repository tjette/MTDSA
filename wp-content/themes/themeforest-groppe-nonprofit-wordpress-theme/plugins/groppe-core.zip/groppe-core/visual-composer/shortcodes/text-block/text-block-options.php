<?php
/**
 * Text Block - Shortcode Options
 */
add_action( 'init', 'groppe_text_vc_map' );
if ( ! function_exists( 'groppe_text_vc_map' ) ) {
  function groppe_text_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Groppe Text Block", 'groppe-core'),
      "base" => "groppe_text_block",
      "description" => esc_html__( "Text Block Styles", 'groppe-core'),
      "icon" => "fa fa-header color-orange",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(        
      
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Text Tags', 'groppe-core' ),
          'value' => array(
            esc_html__( 'div', 'groppe-core' ) => 'div',
            esc_html__( 'p', 'groppe-core' ) => 'p',
            esc_html__( 'pre', 'groppe-core' ) => 'pre',
            esc_html__( 'span', 'groppe-core' ) => 'span',
            esc_html__( 'h1', 'groppe-core' ) => 'h1',
            esc_html__( 'h2', 'groppe-core' ) => 'h2',
            esc_html__( 'h3', 'groppe-core' ) => 'h3',
            esc_html__( 'h4', 'groppe-core' ) => 'h4',
            esc_html__( 'h5', 'groppe-core' ) => 'h5',
            esc_html__( 'h6', 'groppe-core' ) => 'h6',
          ),
          'admin_label' => true,
          'param_name' => 'text_tag',
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"      => 'textarea',
          "heading"   => esc_html__('Content', 'groppe-core'),
          "param_name" => "text_content",
          "value"      => "",
          "description" => esc_html__( "Enter your text here.", 'groppe-core'),
        ),
        GroppeLib::vt_class_option(),

        // Styling
        array(
          "type"        => "notice",
          "heading"     => esc_html__( "Text styles", 'groppe-core' ),
          "param_name"  => 'lsng_opt',
          'class'       => 'cs-warning',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'value'       => '',
        ),
        array(
          "type" => "dropdown",
          "heading" => esc_html__( "Text Align", 'groppe-core' ),
          "param_name" => "text_align",
          'value' => array(
            esc_html__( 'Center', 'groppe-core' ) => 'text-center',
            esc_html__( 'Left', 'groppe-core' ) => 'text-left',
            esc_html__( 'Right', 'groppe-core' ) => 'text-right',
          ),
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-12 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Text Size ", 'groppe-core' ),
          "param_name" => "text_size",
          'value' => '',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type" => "colorpicker",
          "heading" => esc_html__( "Text Color", 'groppe-core' ),
          "param_name" => "text_color",
          'value' => '',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Text Bottom Space ", 'groppe-core' ),
          "param_name" => "text_bottom_space",
          'value' => '',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => esc_html__( "Text Line Height ", 'groppe-core' ),
          "param_name" => "text_line_height",
          'value' => '',
          "group" => esc_html__( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        // Design Tab
        array(
          "type" => "css_editor",
          "heading" => esc_html__( "Custom Style", 'groppe-core' ),
          "param_name" => "css",
          "group" => esc_html__( "Design", 'groppe-core'),
        ),

      )
    ) );
  }
}

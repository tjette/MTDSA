<?php
/**
 * Contact - Shortcode Options
 */
add_action( 'init', 'contact_vc_map' );
if ( ! function_exists( 'contact_vc_map' ) ) {
  function contact_vc_map() {

    $cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );
    $contact_forms = array();
    if ( $cf7 ) {
      foreach ( $cf7 as $cform ) {
        $contact_forms[ $cform->post_title ] = $cform->ID;
      }
    } else {
      $contact_forms[ esc_html__( 'No contact forms found', 'js_composer' ) ] = 0;
    }

    vc_map( array(
    "name" => esc_html__( "Contact Form 7", 'groppe-core'),
    "base" => "grop_contact",
    "description" => esc_html__( "Contact Form 7 Style", 'groppe-core'),
    "icon" => "icon-wpb-contactform7",
    "category" => GroppeLib::grop_cat_name(),
    "params" => array(

      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Style', 'groppe-core' ),
        'value' => array(
          esc_html__('Without Background', 'groppe-core') => 'no-bg',
          esc_html__('With Background', 'groppe-core') => 'with-bg',
        ),
        'param_name' => 'contact_style',
      ),
      array(
        'type' => 'textfield',
        'value' => '',
        'heading' => esc_html__( 'Contact Form Title', 'groppe-core' ),
        'description' => esc_html__( 'Enter contact form title.', 'groppe-core' ),
        'param_name' => 'form_title',
      ),

      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Select contact form', 'js_composer' ),
        'param_name' => 'id',
        'value' => $contact_forms,
        'save_always' => true,
        'admin_label' => true,
        'description' => esc_html__( 'Choose previously created contact form from the drop down list.', 'js_composer' ),
      ),
      GroppeLib::vt_class_option(),

      array(
        'type' => 'textfield',
        'value' => '',
        'heading' => esc_html__( 'Button Text Size', 'groppe-core' ),
        'description' => esc_html__( 'Enter text size for submit button.', 'groppe-core' ),
        'group' => esc_html__( 'Style', 'groppe-core' ),
        'param_name' => 'submit_size',
      ),
      array(
        'type' => 'colorpicker',
        'value' => '',
        'heading' => esc_html__( 'Button Text Color', 'groppe-core' ),
        'description' => esc_html__( 'Pick text color for submit button.', 'groppe-core' ),
        'group' => esc_html__( 'Style', 'groppe-core' ),
        'param_name' => 'submit_color',
      ),
      array(
        'type' => 'colorpicker',
        'value' => '',
        'heading' => esc_html__( 'Button BG Color', 'groppe-core' ),
        'description' => esc_html__( 'Pick button background color.', 'groppe-core' ),
        'group' => esc_html__( 'Style', 'groppe-core' ),
        'param_name' => 'submit_bg_color',
      ),

      ), 
    ) );
  }
}

<?php
/**
 * Sectors - Shortcode Options
 */
add_action( 'init', 'grop_sectors_vc_map' );
if ( ! function_exists( 'grop_sectors_vc_map' ) ) {
  function grop_sectors_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Donation Sector", 'groppe-core'),
      "base" => "grop_sectors",
      "description" => esc_html__( "Sector Shortcodes", 'groppe-core'),
      "icon" => "fa fa-cog color-brown",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Column', 'groppe-core' ),
          'value' => array(
            esc_html__( '3 Columns', 'groppe-core' ) => 'col-3',
            esc_html__( '2 Columns', 'groppe-core' ) => 'col-2',
            esc_html__( '4 Columns', 'groppe-core' ) => 'col-4',
          ),
          'admin_label' => true,
          'param_name' => 'sector_column',
          'description' => esc_html__( 'Select your sector column.', 'groppe-core' ),
        ),
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Sectors', 'groppe-core' ),
          'param_name' => 'sector_items',
          'params' => array(
            array(
              "type"      => 'attach_image',
              "heading"   => esc_html__('Upload Image', 'groppe-core'),
              "param_name" => "icon",
              "value"      => "",
              "description" => esc_html__( "Set your sector icon image.", 'groppe-core'),
            ),
            array(
              "type"      => 'textfield',
              "heading"   => esc_html__('Sector Title', 'groppe-core'),
              "param_name" => "title",
              "value"      => "",
              'admin_label' => true,
              "description" => esc_html__( "Enter your sector title.", 'groppe-core')
            ),
            array(
              "type"      => 'href',
              "heading"   => esc_html__('Sector Link', 'groppe-core'),
              "param_name" => "link",
              "value"      => "",
              "description" => esc_html__( "Set your link for read more.", 'groppe-core'),
            ),
            array(
              "type"      => 'textfield',
              "heading"   => esc_html__('Readmore Text', 'groppe-core'),
              "param_name" => "link_text",
              "value"      => "",
            ),
            GroppeLib::vt_open_link_tab(),
          ),
        ),
        GroppeLib::vt_class_option(),

        // Style
        GroppeLib::vt_notice_field(esc_html__( "Title Styling", 'groppe-core' ),'tle_opt','cs-warning', 'Style'), // Notice
        array(
          "type"      => 'colorpicker',
          "heading"   => esc_html__('Title Color', 'groppe-core'),
          "param_name" => "title_color",
          "value"      => "",
          "description" => esc_html__( "Pick your heading color.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"      => 'textfield',
          "heading"   => esc_html__('Title Size', 'groppe-core'),
          "param_name" => "title_size",
          "value"      => "",
          "description" => esc_html__( "Enter the numeric value for title size in px.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"      => 'colorpicker',
          "heading"   => esc_html__('Title Hover Color', 'groppe-core'),
          "param_name" => "title_hover_color",
          "value"      => "",
          "description" => esc_html__( "Pick your heading hover color.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        => "notice",
          "heading"     => esc_html__( "Read More Style", 'groppe-core' ),
          "param_name"  => 'rml_opt',
          'class'       => 'cs-warning',
          'value'       => '',
          "group" => esc_html__( "Style", 'groppe-core'),
        ),
        array(
          "type"      => 'colorpicker',
          "heading"   => esc_html__('Text Color', 'groppe-core'),
          "param_name" => "reademore_color",
          "value"      => "",
          "description" => esc_html__( "Pick your readmore text color.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"      => 'textfield',
          "heading"   => esc_html__('Text Size', 'groppe-core'),
          "param_name" => "reademore_size",
          "value"      => "",
          "description" => esc_html__( "Enter the numeric value for readmore text size in px.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"      => 'colorpicker',
          "heading"   => esc_html__('Background Color', 'groppe-core'),
          "param_name" => "reademore_bg",
          "value"      => "",
          "description" => esc_html__( "Pick your readmore background color.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"      => 'colorpicker',
          "heading"   => esc_html__('Hover Color', 'groppe-core'),
          "param_name" => "reademore_hover_color",
          "value"      => "",
          "description" => esc_html__( "Pick your readmore text hover color.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"      => 'colorpicker',
          "heading"   => esc_html__('Hover Background', 'groppe-core'),
          "param_name" => "reademore_hover_bg",
          "value"      => "",
          "description" => esc_html__( "Pick your readmore hover background color.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),

      )
    ) );
  }
}

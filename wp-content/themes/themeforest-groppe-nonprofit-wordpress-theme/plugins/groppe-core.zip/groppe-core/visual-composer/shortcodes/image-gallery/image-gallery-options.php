<?php
/**
 * Custom Gallery - Shortcode Options
 */
add_action( 'init', 'custom_gallery_vc_map' );
if ( ! function_exists( 'custom_gallery_vc_map' ) ) {
  function custom_gallery_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Custom Gallery", 'groppe-core'),
      "base" => "grop_custom_gallery",
      "description" => esc_html__( "Custom Gallery", 'groppe-core'),
      "icon" => "fa fa-shield color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Columns', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Causes Columns', 'groppe-core' ) => '',
            esc_html__( 'Column 2', 'groppe-core' ) => 'col-2',
            esc_html__( 'Column 3', 'groppe-core' ) => 'col-3',
            esc_html__( 'Column 4', 'groppe-core' ) => 'col-4',
            esc_html__( 'Column 5', 'groppe-core' ) => 'col-5',
          ),
          'admin_label' => true,
          'param_name' => 'gallery_column',
        ),
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Impact Images', 'groppe-core' ),
          'param_name' => 'items',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              'type' => 'attach_image',
              'value' => '',
              "admin_label"=> true,
              'heading' => esc_html__( 'Upload Image', 'groppe-core' ),
              'param_name' => 'image',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Image URL', 'groppe-core' ),
              'param_name' => 'url',
            )
          )
        ),
        GroppeLib::vt_class_option(),
      )
    ) );
  }
}

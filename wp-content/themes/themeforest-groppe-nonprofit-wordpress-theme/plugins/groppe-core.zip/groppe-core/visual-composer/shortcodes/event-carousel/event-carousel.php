<?php
/* ==========================================================
  Client Carousel
=========================================================== */
if ( !function_exists('grop_event_carousel_func')) {
  function grop_event_carousel_func( $atts, $content = NULL ) {
    extract(shortcode_atts(array(
      'class'  => '',
      'title'  => '',
      'event_limit'  => '',
      'perticular_event'  => '',
      'event_order'  => '',
      'event_orderby'  => '',
      'event_show_category'  => '',
      'event_share_btn' => '',
      'event_popup_btn' => '',
      'contact_btn_type' => '',
      'contact_btn_link' => '',
      'popup_title'  => '',
      'popup_form_id' => '',
      
      // Carousel
      'carousel_loop'  => '',
      'carousel_items'  => '',
      'carousel_margin'  => '',
      'carousel_autoplay_timeout'  => '',
      'carousel_autoplay'  => '',
      'carousel_animate_out'  => '',
      'carousel_mousedrag'  => '',
      'carousel_autowidth'  => '',
      'carousel_autoheight'  => '',
      'carousel_tablet'  => '',
      'carousel_mobile'  => '',
      'carousel_small_mobile'  => '',
    ), $atts));

    // Carousel Data's
    $carousel_loop = $carousel_loop !== 'true' ? ' data-loop="true"' : ' data-loop="false"';
    $carousel_items = $carousel_items ? ' data-items="'. $carousel_items .'"' : ' data-items="2"';
    $carousel_margin = $carousel_margin ? ' data-margin="'. $carousel_margin .'"' : ' data-margin="30"';
    $carousel_autoplay_timeout = $carousel_autoplay_timeout ? ' data-autoplay-timeout="'. $carousel_autoplay_timeout .'"' : '';
    $carousel_autoplay = $carousel_autoplay ? ' data-autoplay="'. $carousel_autoplay .'"' : '';
    $carousel_animate_out = $carousel_animate_out ? ' data-animateout="'. $carousel_animate_out .'"' : '';
    $carousel_mousedrag = $carousel_mousedrag !== 'true' ? ' data-mouse-drag="true"' : ' data-mouse-drag="false"';
    $carousel_autowidth = $carousel_autowidth ? ' data-auto-width="'. $carousel_autowidth .'"' : '';
    $carousel_autoheight = $carousel_autoheight ? ' data-auto-height="'. $carousel_autoheight .'"' : '';
    $carousel_tablet = $carousel_tablet ? ' data-items-tablet="'. $carousel_tablet .'"' : ' data-items-tablet="2"';
    $carousel_mobile = $carousel_mobile ? ' data-items-mobile-landscape="'. $carousel_mobile .'"' : ' data-items-mobile-landscape="1"';
    $carousel_small_mobile = $carousel_small_mobile ? ' data-items-mobile-portrait="'. $carousel_small_mobile .'"' : ' data-items-mobile-portrait="1"';
  ob_start();

    if (!empty($perticular_event)) {
      $perticular_event = explode(',', $perticular_event);
    } else {
      $perticular_event = array();
    }

    $args = array(
      // other query params here,
      'post_type' => 'tribe_events',
      'posts_per_page' => (int)$event_limit,
      'orderby' => $event_orderby,
      'post__in' => $perticular_event,
      'order' => $event_order
    );

  $grop_evnt = new WP_Query( $args );


  if ($grop_evnt->have_posts()) :
    $title = $title ? $title : esc_html__('Upcoming Events', 'grope-core');
     ?>
                
          
          <div class="grop-fix  grop-ucoming_evnt_tp_cont">
            <h3 class="grop-float_left text-uppercase"><?php echo esc_attr($title); ?></h3>
            <div class="grop-float_right  grop-ucoming_evnt_casel_nav"></div>
          </div>          
<?php
    echo '<div class="owl-carousel  grop-ucoming_evnt_carousel"
          '. $carousel_loop . $carousel_items . $carousel_margin . $carousel_autoplay_timeout . $carousel_autoplay . $carousel_animate_out . $carousel_mousedrag . $carousel_autowidth . $carousel_autoheight . $carousel_tablet . $carousel_mobile . $carousel_small_mobile .'>';

    // Group Param Output
    while ($grop_evnt->have_posts()) : $grop_evnt->the_post(); 
    $event_popup_options = get_post_meta( get_the_ID(), '_event_popup_form_metabox', true );
        if ($event_popup_options) {
          if ($event_popup_options['popup_btn']){
            $event_contact_btn = $event_popup_options['popup_btn'];
            $event_popup_form_id = $event_popup_options['form_id'];
            $event_contact_btn_type = $event_popup_options['contact_btn_type'];
            $event_contact_btn_link = $event_popup_options['contact_btn_link'] ? $event_popup_options['contact_btn_link'] : $contact_btn_link;
          } elseif($event_popup_btn) {
            $event_contact_btn = $event_popup_btn;
            $event_popup_form_id = $popup_form_id;
            $event_contact_btn_type = $contact_btn_type;
            $event_contact_btn_link = $contact_btn_link ? $contact_btn_link : cs_get_option('contact_btn_link');
          } else {
            $event_contact_btn = cs_get_option('popup_btn');
            $event_popup_form_id = cs_get_option('form_id');
            $event_contact_btn_type = cs_get_option('contact_btn_type');
            $event_contact_btn_link = cs_get_option('contact_btn_link');
          }
        } elseif($event_popup_btn) {
          $event_contact_btn = $event_popup_btn;
          $event_popup_form_id = $popup_form_id;
          $event_contact_btn_type = $contact_btn_type;
          $event_contact_btn_link = $contact_btn_link ? $contact_btn_link : cs_get_option('contact_btn_link');
        } else {
          $event_contact_btn = cs_get_option('popup_btn');
          $event_popup_form_id = cs_get_option('form_id');
          $event_contact_btn_type = cs_get_option('contact_btn_type');
          $event_contact_btn_link = cs_get_option('contact_btn_link');
        }
        $args = array('post_type' => 'wpcf7_contact_form', 'p'=>$event_popup_form_id);
        $cf7Forms = get_posts( $args );
        $form_titles = get_the_title( $event_popup_form_id );

      $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
      if ($large_image) {
        $featured_img = $large_image[0];
      } else {
        $featured_img = GROPPE_PLUGIN_ASTS . '/images/1000x800.jpg';
      }

      $post_meta = get_post_meta( get_the_ID() );
      $s_date = $post_meta['_EventStartDate'];
      $s_createDate = new DateTime($s_date[0]);
      $s_full_date = $s_createDate->format('d M Y');
      $s_hour = $s_createDate->format('H:i a');
      // end date
      $e_date = $post_meta['_EventEndDate'];
      $e_createDate = new DateTime($e_date[0]);
      $e_full_date = $e_createDate->format('d M Y');
      $e_hour = $e_createDate->format('H:i a');
      $venu_details = tribe_get_venue_details ( get_the_ID() );
    ?>
      <div class="grop-ucoming_evnt_sigl_item">
        <!--Home upcoming events image start \-->
        <div class="grop-ucoming_evnt_image">
          <img src="<?php echo esc_url($featured_img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" />
        </div><!--/end-->
        
        <!--Home upcoming events content start \-->
        <div class="grop-ucoming_evnt_cont_warp">
        
          <!--Home upcoming events text content start \-->
          <div class="grop-ucoming_evnt_txt_cont">
            <!--Home upcoming events date start \-->
            <div class="grop-ucoming_evnt_date">
              <?php echo esc_html__( $s_full_date, 'groppe-core' ); ?>
            </div><!--/end-->
            
            <!--Home upcoming events title start \-->
            <h4 class="grop-ucoming_evnt_title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html(the_title()); ?></a></h4><!--/end-->
            
            <!--Home upcoming events location start \-->
            <?php if(!empty($venu_details['address']) || !empty($venu_details['linked_name'])){ ?>
            <p class="grop-ucoming_evnt_location">
              <i class="fa fa-map-marker"></i>
              <?php 
              if(!empty($venu_details['linked_name'])){ 
                echo esc_html__( $venu_details['linked_name'], 'groppe-core' ); 
              } else {
                echo esc_html__( $venu_details['address'], 'groppe-core' ); 
              } ?>
            </p><!--/end-->
            <?php } ?>
            
            <!--Home upcoming events btn start \-->
            <a class="grop-btn grop-btn_overly grop-ucom_evnt_dtls_btn" href="<?php echo esc_url( get_permalink() ); ?>">
              <span><?php echo esc_html__('Details', 'groppe' ); ?></span>
            </a><!--/end-->
          </div><!--/Home upcoming events text content end-->
          
          <!--Home upcoming events footer  content start \-->
          <div class="grop-fix  grop-ucoming_evnt_footr">
            
            <!--Home upcoming events social start \-->
            <div class="grop-fix  grop-float_left  grop-ucoming_evnt_social">
              <div class="grop-ucoevnt_socil">
              <?php if ($event_contact_btn) { 
                if ($event_contact_btn_type === 'popup') { ?>
                  <a class="grop-evs_evpop" href="mailto:?subject=<?php print(urlencode( get_the_title() )); ?>&amp;body=<?php print(urlencode( get_permalink( get_the_ID() ) )); ?>" data-toggle="modal" data-target="#<?php echo $event_popup_form_id; ?>"><i class="fa fa-envelope-o"></i></a>
                <?php } else { ?>
                  <a href="<?php echo esc_url($event_contact_btn_link); ?>" target="_blank" class="grop-evs_evpop"><i class="fa fa-envelope-o"></i></a>
                <?php } 
              } ?>
                <?php groppe_event_share_option(); ?>
              </div>
            </div><!--/end-->
            
            <!--Home upcoming events time start \-->
            <div class="grop-float_right  grop-ucoming_evnt_time">
              <i class="fa fa-clock-o"></i><?php echo tribe_get_start_time().' - '.tribe_get_end_time(); ?>
            </div><!--/end-->
            
          </div><!--/end-->
        </div><!--/end-->
      </div>
      <?php
    endwhile;
    echo'</div>';?>
    <?php
    endif;
    if ($grop_evnt->have_posts()) :
      while ($grop_evnt->have_posts()) : $grop_evnt->the_post(); 
        $event_popup_options = get_post_meta( get_the_ID(), '_event_popup_form_metabox', true );
        if ($event_popup_options) {
          if ($event_popup_options['popup_btn']){
            $event_contact_btn = $event_popup_options['popup_btn'];
            $event_popup_form_id = $event_popup_options['form_id'];
            $event_contact_btn_type = $event_popup_options['contact_btn_type'];
            $event_contact_btn_link = $event_popup_options['contact_btn_link'] ? $event_popup_options['contact_btn_link'] : $contact_btn_link;
          } elseif($event_popup_btn) {
            $event_contact_btn = $event_popup_btn;
            $event_popup_form_id = $popup_form_id;
            $event_contact_btn_type = $contact_btn_type;
            $event_contact_btn_link = $contact_btn_link ? $contact_btn_link : cs_get_option('contact_btn_link');
          } else {
            $event_contact_btn = cs_get_option('popup_btn');
            $event_popup_form_id = cs_get_option('form_id');
            $event_contact_btn_type = cs_get_option('contact_btn_type');
            $event_contact_btn_link = cs_get_option('contact_btn_link');
          }
        } elseif($event_popup_btn) {
          $event_contact_btn = $event_popup_btn;
          $event_popup_form_id = $popup_form_id;
          $event_contact_btn_type = $contact_btn_type;
          $event_contact_btn_link = $contact_btn_link ? $contact_btn_link : cs_get_option('contact_btn_link');
        } else {
          $event_contact_btn = cs_get_option('popup_btn');
          $event_popup_form_id = cs_get_option('form_id');
          $event_contact_btn_type = cs_get_option('contact_btn_type');
          $event_contact_btn_link = cs_get_option('contact_btn_link');
        }
        $args = array('post_type' => 'wpcf7_contact_form', 'p'=>$event_popup_form_id);
        $cf7Forms = get_posts( $args );
        $form_titles = get_the_title( $event_popup_form_id );
        $pop_id = $event_popup_form_id ? 'id="'.$event_popup_form_id.'"': ''; ?>
          <div class="grop-model_popup_warp">
            <div <?php echo $pop_id; ?> class="modal fade" role="dialog">
              <div class="modal-dialog  grop-model_dialog">
                <div class="modal-content  grop-model_content">
                  <div class="modal-header grop-model_header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button><!--/ close btn end-->
                    <div class="grop-resform_headr">
                      <?php 
                      $args = array('post_type' => 'wpcf7_contact_form', 'p'=>$event_popup_form_id);
                       $cf7Forms = get_posts( $args );
                       $form_titles = get_the_title( $event_popup_form_id );
                      echo esc_attr($form_titles); ?>
                    </div>
                  </div>
                  <!-- Modal Popup content body start\-->
                  <div class="modal-body grop-model_body">
                    <div class="grop-resform_form  grop-contact_poup_form">
                      <?php echo do_shortcode( '[contact-form-7 id="'. $event_popup_form_id .'"]' ); ?>
                    </div>
                  </div><!--/ Modal Popup content body end-->
                  <div class="modal-footer grop-model_footer">
                  </div>
                </div>
              </div>
            </div>
          </div>
    <?php
    endwhile;
    endif;

    return ob_get_clean();
  }
}
add_shortcode( 'grop_event_carousel', 'grop_event_carousel_func' );

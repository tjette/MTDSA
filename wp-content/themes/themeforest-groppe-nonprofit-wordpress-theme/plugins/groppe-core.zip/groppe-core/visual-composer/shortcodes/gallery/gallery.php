<?php
/* ==========================================================
  Gallery
=========================================================== */
if ( !function_exists('grop_gallery_function')) {
  function grop_gallery_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'gallery_style'  => '',
      'gallery_limit'  => '',
      'gallery_column'  => '',
      // Enable & Disable
      'gallery_filter'  => '',
      'gallery_pagination'  => '',
      // Listing
      'gallery_order'  => '',
      'gallery_orderby'  => '',
      'gallery_show_category'  => '',
      'class'  => '',
      // Style - Filter
      'filter_color'  => '',
      'filter_active_color'  => '',
      'active_bg'  => '',
      'filter_size'  => '',
    ), $atts));

    // Shortcode Style CSS
    $e_uniqid        = uniqid();
    $inline_style  = '';

    // Filter
    if ( $filter_color || $filter_size ) {
      $inline_style .= '.grop-gallery-'. $e_uniqid .' #grop_filters ul li{';
      $inline_style .= ( $filter_color ) ? 'color:'. $filter_color .';' : '';
      $inline_style .= ( $filter_size ) ? 'font-size:'. groppe_core_check_px($filter_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $filter_active_color || $active_bg ) {
      $inline_style .= '.grop-gallery-'. $e_uniqid .' #grop_filters ul li.is-active{';
      $inline_style .= ( $filter_active_color ) ? 'color:'. $filter_active_color .';' : '';
      $inline_style .= ( $active_bg ) ? 'background-color:'. $active_bg .';' : '';
      $inline_style .= '}';
    }

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-gallery-'. $e_uniqid;

    // Style
    $gallery_column = $gallery_column ? $gallery_column : 'grop-galry_col-3';

    ob_start(); ?>
<div class="grop-gallery_grid_area">
  <div class="grop-gallery-container">
    <div class="grop-filter_content_warp">
  <?php  // Gallery Filter
    if ($gallery_filter) {
    ?>
    <div id="grop_filters" class="text-center grop-galryfilter_nav">
      <ul class="text-uppercase  list-inline">
  			<li class="grop-filte_btn is-active" data-filter="*"><?php echo esc_html__( 'All', 'groppe-core' ); ?></li>
        <?php
          if ($gallery_show_category) {
            $cat_name = explode(',', $gallery_show_category);
            $terms = $cat_name;
            $count = count($terms);
            if ($count > 0) {
              foreach ($terms as $term) {
                echo '<li class="grop-filte_btn" data-filter=".cat-'. preg_replace('/\s+/', "", strtolower($term)) .'">' . str_replace('-', " ", strtolower($term)) . '</li>';
               }
            }
          } else {
            $terms = get_terms('gallery_category');
            $count = count($terms);
            $i=0;
            $term_list = '';
            if ($count > 0) {
              foreach ($terms as $term) {
                $i++;
                $term_list .= '<li class="grop-filte_btn" data-filter=".cat-'. $term->slug .'">' . $term->name . '</li>';
                if ($count != $i) {
                  $term_list .= '';
                } else {
                  $term_list .= '';
                }
              }
              echo $term_list;
            }
          }
        ?>
  		</ul>
    </div>
    <?php
    }

    // Pagination
    global $paged;
      if( get_query_var( 'paged' ) )
        $my_page = get_query_var( 'paged' );
      else {
        if( get_query_var( 'page' ) )
          $my_page = get_query_var( 'page' );
        else
          $my_page = 1;
        set_query_var( 'paged', $my_page );
        $paged = $my_page;
      }

    $args = array(
      // other query params here,
      'paged' => $my_page,
      'post_type' => 'gallery',
      'posts_per_page' => (int)$gallery_limit,
      'gallery_category' => esc_attr($gallery_show_category),
      'orderby' => $gallery_orderby,
      'order' => $gallery_order
    );

    $grop_port = new WP_Query( $args ); ?>

    <!-- Gallery Start -->
      <div class="grop-filter_content  grop-galryfilter_content">
        <?php
        if ($grop_port->have_posts()) : while ($grop_port->have_posts()) : $grop_port->the_post();

          // Category
          global $post;
          $terms = wp_get_post_terms($post->ID,'gallery_category');
          foreach ($terms as $term) {
            $cat_class = 'cat-' . $term->slug;
          }
          $count = count($terms);
          $i=0;
          $cat_class = '';
          if ($count > 0) {
            foreach ($terms as $term) {
              $i++;
              $cat_class .= 'cat-'. $term->slug .' ';
              if ($count != $i) {
                $cat_class .= '';
              } else {
                $cat_class .= '';
              }
            }
          }
          // Featured Image
          $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
          if ( $large_image ) {
            $large_image = $large_image[0];
          } else {
            $large_image = GROPPE_PLUGIN_ASTS . '/images/1000x800.jpg';
          } 
          $gallery_metabox = get_post_meta( get_the_ID(), 'gallery_post_type_metabox', true );
          if ($gallery_metabox ) {
            $gallery_type = $gallery_metabox['gallery_type'];
            $video_post = $gallery_metabox['video_post'];
            $gallery_post_format = $gallery_metabox['gallery_post_images'];
            $link_post = $gallery_metabox['link_post'];
          } else {
            $gallery_type = '';
            $video_post = '';
            $gallery_post_format = array();
            $link_post = '';
          } ?>
          <div class="grop-filter_single_col <?php echo esc_attr( $gallery_column.' '.$cat_class ); ?>">
            <?php if ( $gallery_type == 'gallery' ) { ?>
              <div class="text-center grop-gallery-slider">
                <div class="owl-carousel  grop-galry_carousel" data-autoplay="false" data-center="true" data-dots="true" data-nav="true">
                  <?php $images = explode( ',', $gallery_post_format );
                  foreach ($images as $imagee) {
                    $image = wp_get_attachment_image_src( $imagee, 'full' ); 
                    $image_alt = get_post_meta($imagee, '_wp_attachment_image_alt', true);
                    $g_img = $image[0];
                    ?>
                    <div class="grop-galryslid_single">
                      <img src="<?php echo esc_url($g_img); ?>" alt="<?php esc_attr( $image_alt ); ?>" />
                    </div>
                  <?php } ?>
                </div>
                <?php if ($gallery_style === 'with_caption'){ ?>
                  <h5 class="grop-galry_cption"><?php echo esc_attr(get_the_title()); ?></h5>
                <?php } ?>

              </div>
            <?php } elseif( $gallery_type == 'video' ) {
              preg_match(
                '/[\\?\\&]v=([^\\?\\&]+)/',
                $video_post,
                $matches
              );
              $id = $matches[1];
             ?>
              <div class="text-center grop-gallery-video">
                <a class="grop-gvideo_btn" href="" data-toggle="modal" data-target="#myVideo<?php the_ID(); ?>">
                  <img src="<?php echo esc_url( $large_image ); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" />
                </a>
                <?php if ($gallery_style === 'with_caption'){ ?>
                  <h5 class="grop-galry_cption"><?php echo esc_attr(get_the_title()); ?></h5>
                <?php } ?>
              </div>
              <div class="grop-model_popup_warp">
                <!-- Your id here must be mach data-target="#your target here" btn-->
                <div id="myVideo<?php the_ID(); ?>" class="modal fade" role="dialog">
                  <div class="modal-dialog  grop-model_dialog  grop-model_video  vertical-align-center">
                    <div class="modal-content  grop-model_content">
                      <div class="modal-body grop-model_body">
                        <iframe width="560" height="315" src="<?php echo esc_url( 'https://www.youtube.com/embed/'.$id ); ?>" frameborder="0" allowfullscreen></iframe>
                        <?php if ($gallery_style === 'with_caption'){ ?>
                          <h5 class="grop-galry_cption"><?php echo esc_attr(get_the_title()); ?></h5>
                        <?php } ?>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            <?php } elseif( $gallery_type == 'link' ) { ?>
              <div class="text-center grop-gallery-image">
                <a href="<?php echo esc_url( $link_post ); ?>">
                  <img src="<?php echo esc_url( $large_image ); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" />
                  <?php if ($gallery_style === 'with_caption'){ ?>
                    <h5 class="grop-galry_cption"><?php echo esc_attr(get_the_title()); ?></h5>
                  <?php } ?>
                </a>
              </div>
            <?php } else { ?>
            <div class="text-center grop-gallery-image">
              <img src="<?php echo esc_url( $large_image ); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" />
              <?php if ($gallery_style === 'with_caption'){ ?>
                <h5 class="grop-galry_cption"><?php echo esc_attr(get_the_title()); ?></h5>
              <?php } ?>
            </div>
            <?php } ?>
          </div>
        <?php 
          endwhile;
          endif; 
        ?>
      </div>
    </div>
  </div>
</div>
<!-- Gallery End -->

    <?php
    if ($gallery_pagination) {
      groppe_custom_paging_nav($grop_port->max_num_pages,"",$paged);
    }

    // Return outbut buffer
    return ob_get_clean();
    wp_reset_postdata();

  }
}
add_shortcode( 'grop_gallery', 'grop_gallery_function' );

<?php
/* team */
if ( !function_exists('grop_team_function')) {
  function grop_team_function( $atts, $content = NULL ) {
    extract(shortcode_atts(array(
      'class'  => '',
      'team_style'  => '',
      'team_column'  => '',
      'team_standard_column' => '',
      // Listing
      'perticular_team_member'  => '',
      'team_limit'  => '',
      'team_order'  => '',
      'team_orderby'  => '',
      'team_short_content' => '',
      'team_pagination' => '',
      // Color & Style
      'name_color'  => '',
      'profession_color'  => '',
      'content_color'  => '',
      'profession_bg'  => '',
      'social_color'  => '',
      'social_hover_color'  => '',
      'social_title_color'  => '',

      'name_size'  => '',
      'profession_size'  => '',
      'social_size'  => '',
      'social_title_size'  => '',
      'content_size'  => '',
    ), $atts));

    if($team_style === 'standard'){
      $team_standard_column = ( $team_standard_column ) ?  $team_standard_column : 'col-3';
      if ($team_standard_column === 'col-4'){
        $col_class = 'col-md-3 col-sm-6 col-xs-6';
      } else {
        $col_class = 'col-md-4 col-sm-6 col-xs-6';
      }
    } else {
      $team_column = ( $team_column ) ?  $team_column : 'col-3';
      if ($team_column === 'col-4'){
        $col_class = 'col-md-3 col-sm-6 col-xs-6';
      } elseif ($team_column === 'col-5'){
        $col_class = 'grop-tm_single';
      } else {
        $col_class = 'col-md-4 col-sm-6 col-xs-6';
      }
    }

    // Shortcode Style CSS
    $e_uniqid        = uniqid();
    $inline_style  = '';
    // Name Color
    if ( $name_color || $name_size ) {
      $inline_style .= '.grop-team-'. $e_uniqid .' .grop-vltrs_peple_intro_txt h4, .grop-team-'. $e_uniqid .' .grop-vltrs_peple_intro_txt h4 a, .grop-team-'. $e_uniqid .' .grop-tm_intro h4, .grop-team-'. $e_uniqid .' .grop-tm_intro h4 a{';
      $inline_style .= ( $name_color ) ? 'color:'. $name_color .';' : '';
      $inline_style .= ( $name_size ) ? 'font-size:'. groppe_core_check_px($name_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $profession_color || $profession_size || $profession_bg ) {
      $inline_style .= '.grop-team-'. $e_uniqid .' .grop-vltrs_peple_intro, .grop-team-'. $e_uniqid .' .grop-tm_intro h6 {';
      $inline_style .= ( $profession_color ) ? 'color:'. $profession_color .';' : '';
      $inline_style .= ( $profession_bg ) ? 'background-color:'. $profession_bg .' !important;' : '';
      $inline_style .= ( $profession_size ) ? 'font-size:'. groppe_core_check_px($profession_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $content_color || $content_size ) {
      $inline_style .= '.grop-team-'. $e_uniqid .' .grop-vltrs_peple_intro_txt p {';
      $inline_style .= ( $content_color ) ? 'color:'. $content_color .';' : '';
      $inline_style .= ( $content_size ) ? 'font-size:'. groppe_core_check_px($content_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $social_color || $social_size || $social_hover_color || $social_title_color || $social_title_size ) {
      $inline_style .= '.grop-team-'. $e_uniqid .' .vltrs_peple_social ul li a{';
      $inline_style .= ( $social_color ) ? 'color:'. $social_color .';' : '';
      $inline_style .= ( $social_size ) ? 'font-size:'. groppe_core_check_px($social_size) .';' : '';
      $inline_style .= '}';
      $inline_style .= '.grop-team-'. $e_uniqid .' .vltrs_peple_social ul li a:hover{';
      $inline_style .= ( $social_hover_color ) ? 'color:'. $social_hover_color .'!important;' : '';
      $inline_style .= '}';
      $inline_style .= '.grop-team-'. $e_uniqid .' .grop-vltrs_peple_scil_title{';
      $inline_style .= ( $social_title_color ) ? 'color:'. $social_title_color .';' : '';
      $inline_style .= ( $social_title_size ) ? 'font-size:'. groppe_core_check_px($social_title_size) .';' : '';
      $inline_style .= '}';
    }

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-team-'. $e_uniqid;
    
    if (!empty($perticular_team_member)) {
      $perticular_team_member = explode(',', $perticular_team_member);
    } else {
      $perticular_team_member = array();
    }
    // Turn output buffer on
    ob_start();

    // Pagination
    global $paged;
    if( get_query_var( 'paged' ) )
      $my_page = get_query_var( 'paged' );
    else {
      if( get_query_var( 'page' ) )
        $my_page = get_query_var( 'page' );
      else
        $my_page = 1;
      set_query_var( 'paged', $my_page );
      $paged = $my_page;
    }
    $args = array(
      'paged' => $my_page,
      'post_type' => 'team',
      'posts_per_page' => (int) $team_limit,
      'orderby' => $team_orderby,
      'order' => $team_order,
      'post__in' => $perticular_team_member,
    );
    $count = 0;
    $grop_team = new WP_Query( $args );
    if ($grop_team->have_posts()) : ?>
    <div class="grop-team <?php echo esc_attr( $class.$styled_class ); ?>"> <!-- team Starts -->
      <div class="container" style="width: 100%;">
        <div class="row">
        <?php
          while ($grop_team->have_posts()) : $grop_team->the_post();
            $count++;
            $team_options = get_post_meta( get_the_ID(), 'team_options', true );
            $employee_name = $team_options['employee_name'];
            $team_job_position = $team_options['team_job_position'];
            $team_socials = $team_options['team_socials'];
            $team_link = $team_options['team_link'];
            if (!empty($team_link)) {
              $team_url = $team_link;
            } else {
              $team_url = get_the_permalink();
            }
            if ( $team_column == 'col-3' && $count == 3 ) {
              $ofset = ' col-sm-offset-3 col-md-offset-0';
            } else {
              $ofset = '';
            }
            // Featured Image
            $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
            $groppe_alt = get_post_meta( get_post_thumbnail_id(get_the_ID()), '_wp_attachment_image_alt', true);
            if ($large_image) {
              $large_image = $large_image[0];
            } else {
              $large_image = GROPPE_PLUGIN_IMGS.'/mate.jpg';
            } 
            if($team_style === 'standard'){
              if ( $team_column == 'col-4') {
                if(class_exists('Aq_Resize')) {
                  $large_image = aq_resize( $large_image, '263', '220', true );
                } else {
                  $large_image = $large_image;
                }
              } else {
                if(class_exists('Aq_Resize')) {
                  $large_image = aq_resize( $large_image, '370', '310', true );
                } else {
                  $large_image = $large_image;
                }
              }
            } else {
              if ( $team_column == 'col-5') {
                if(class_exists('Aq_Resize')) {
                  $large_image = aq_resize( $large_image, '210', '210', true );
                } else {
                  $large_image = $large_image;
                }
              } else {
                $large_image = $large_image;
              }
            }
            ?>
            <div class="grop-team-single-item <?php echo esc_attr( $col_class.$ofset ); ?>">
              <?php if($team_style === 'standard'){ ?>
              <div class="grop-vltrs_peple_sngle_intro  grop-tm_dr">
                <!--Volunteers people media image start \-->
                <div class="grop-vltrs_peple_media">
                  <?php 
                  if ($team_job_position) { 
                    echo '<div class="text-uppercase  grop-vltrs_peple_intro">'.$team_job_position.'</div>';
                  } ?>
                  <img src="<?php echo esc_url( $large_image ); ?>" alt="<?php echo esc_attr( $groppe_alt ); ?>" />
                </div><!--/Volunteers people media end-->
                <!--Volunteers people text start \-->
                <div class="grop-vltrs_peple_cont_warp">
                  <!--Volunteers people intro text start \-->
                  <div class="grop-vltrs_peple_intro_txt">
                    <?php if($employee_name){
                      echo '<h4><a href="'.esc_url( $team_url ).'">'.$employee_name.'</a></h4>';
                    } ?>
                    <p>
                      <?php 
                      if($team_short_content) {
                        $short_content = $team_short_content;
                      } else {
                        $short_content = '12';
                      }
                        if (groppe_framework_active()) {
                          groppe_excerpt($short_content);
                        } else {
                          the_excerpt();
                        } ?>
                    </p>
                  </div><!--/end-->
                  <!--Social  warp start \-->
                  <div class="grop-fix grop-vltrs_peple_social_warp">
                    <!--title text start \-->
                    <h5 class="text-left  col-xs-6 grop-vltrs_peple_scil_title"><?php echo esc_html__( 'Meet Me On:', 'groppe-core' ); ?></h5><!--/end-->
                    <!--Social  start \-->
                    <div class="col-xs-6  vltrs_peple_social">
                      <ul class="list-inline text-right">
                      <?php foreach ($team_socials as $key => $icon) : ?>
                        <li><a href="<?php echo $icon['team_social_link']; ?>">
                          <i class="<?php echo $icon['team_social_icon']; ?>"></i>
                        </a></li>
                      <?php endforeach; ?>
                      </ul>
                    </div><!--/end-->
                  </div><!--/Social  warp end-->
                  
                </div><!--/Volunteers people media end-->
                
              </div>

              <?php  } else { ?>
              <!--Team membars image start\-->
                  <div class="grop-tm_image">
                    <img src="<?php echo esc_url( $large_image ); ?>" alt="<?php echo esc_attr( $groppe_alt ); ?>" />
                  </div><!--/end-->
                  <!--Team membars intro start\-->
                  <div class="grop-tm_intro">
                    <?php if( $employee_name ){
                      echo '<h4><a href="'.esc_url( $team_url ).'">'.$employee_name.'</a></h4>';
                    }
                    if ($team_job_position) { 
                      echo '<h6>'.$team_job_position.'</h6>';
                    } ?>
                  </div><!--/end-->
              <?php } ?>
            </div><!--/Volunteers people single intro end-->
            <?php
          endwhile;
          
        ?>
        </div> <!-- row -->
      </div> <!-- container -->
    </div> <!-- team End -->
    <?php
    endif;

    if ($team_pagination) {
      groppe_custom_paging_nav($grop_team->max_num_pages,"",$paged);
    } 
    wp_reset_postdata();

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'grop_team', 'grop_team_function' );
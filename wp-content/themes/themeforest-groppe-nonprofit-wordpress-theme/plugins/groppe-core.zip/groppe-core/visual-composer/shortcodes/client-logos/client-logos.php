<?php
/* ==========================================================
  Client Carousel
=========================================================== */
if ( !function_exists('grop_logo_func')) {
  function grop_logo_func( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'open_link'  => '',
      'client_logos'  => '',
      'class'  => '',
    ), $atts));

    // Link Target
    $open_link = $open_link ? 'target="_blank"' : '';

    // Group Field
    $client_logos = (array) vc_param_group_parse_atts( $client_logos );
    $get_client_logos = array();
    foreach ( $client_logos as $client_logo ) {
      $each_logo = $client_logo;
      $each_logo['client_logo'] = isset( $client_logo['client_logo'] ) ? $client_logo['client_logo'] : '';
      $each_logo['client_link'] = isset( $client_logo['client_link'] ) ? $client_logo['client_link'] : '';
      $get_client_logos[] = $each_logo;
    }

    $output = '<div class="grop-clients_logos_area"><div class="container"><div class="grop-clients_logos"><ul class="grop-fix grop-list_unstyled">';
    // Group Param Output
    foreach ( $get_client_logos as $each_logo ) {
      $image_url = wp_get_attachment_url( $each_logo['client_logo'] );
      if ($each_logo['client_link']) {
        $output .= '<li><a href="'. $each_logo['client_link'] .'" '. $open_link .' class="client-logo"><img src="'. $image_url .'" alt=""></a></li>';
      } else {
        $output .= '<li><img src="'. $image_url .'" alt=""></li>';
      }
    }

    $output .= '</ul></div></div></div>';

    return $output;
  }
}
add_shortcode( 'grop_client_logos', 'grop_logo_func' );

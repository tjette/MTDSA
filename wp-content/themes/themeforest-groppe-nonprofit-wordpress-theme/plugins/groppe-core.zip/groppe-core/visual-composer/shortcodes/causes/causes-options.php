<?php
/**
 * Causes - Shortcode Options
 */
add_action( 'init', 'grop_causes_vc_map' );
if ( ! function_exists( 'grop_causes_vc_map' ) ) {
  function grop_causes_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Donation Causes", 'groppe-core'),
      "base" => "grop_causes",
      "description" => esc_html__( "Donation Causes Styles", 'groppe-core'),
      "icon" => "fa fa-briefcase color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Causes Style', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Style List', 'groppe-core' ) => 'causes-list',
            esc_html__( 'Style Grid', 'groppe-core' ) => 'causes-grid',
          ),
          'admin_label' => true,
          'param_name' => 'causes_style',
          'description' => esc_html__( 'Select your causes style.', 'groppe-core' ),
        ),
        array(
          "type"        =>'textfield',
          "heading"     =>esc_html__('Limit', 'groppe-core'),
          "param_name"  => "causes_limit",
          "value"       => "",
          'admin_label' => true,
          "description" => esc_html__( "Enter the number of items to show.", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Columns', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Causes Columns', 'groppe-core' ) => '',
            esc_html__( 'Column Two', 'groppe-core' ) => 'column-two',
            esc_html__( 'Column Three', 'groppe-core' ) => 'column-three',
            esc_html__( 'Column Four', 'groppe-core' ) => 'column-four',
            esc_html__( 'Column Five', 'groppe-core' ) => 'column-five',
          ),
          'admin_label' => true,
          'param_name' => 'causes_column',
          'description' => esc_html__( 'Select your causes column.', 'groppe-core' ),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'dependency' => array(
            'element' => 'causes_style',
            'value'     => 'causes-grid',
          )
        ),
        array(
          "type"        =>'textfield',
          "heading"     =>esc_html__('Excerpt Length', 'groppe-core'),
          "param_name"  => "short_content",
          "value"       => "",
          'admin_label' => true,
          "description" => esc_html__( "Enter the number of excerpt length.", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),

        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Enable & Disable", 'groppe-core' ),
    			"param_name"  => 'ends_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
    		),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Hide Excerpt?', 'groppe-core'),
          "param_name"  => "hide_excerpt",
          "value"       => "",
          "std"         => false,
          'dependency' => array(
            'element' => 'causes_style',
            'value'     => 'causes-grid',
          ),
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Filter', 'groppe-core'),
          "param_name"  => "causes_filter",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
          'dependency' => array(
            'element' => 'causes_style',
            'value'     => 'causes-grid',
          )
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Pagination', 'groppe-core'),
          "param_name"  => "causes_pagination",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Listing", 'groppe-core' ),
    			"param_name"  => 'lsng_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
    		),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Order', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Causes Order', 'groppe-core' ) => '',
            esc_html__('Asending', 'groppe-core') => 'ASC',
            esc_html__('Desending', 'groppe-core') => 'DESC',
          ),
          'param_name' => 'causes_order',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Order By', 'groppe-core' ),
          'value' => array(
            esc_html__('None', 'groppe-core') => 'none',
            esc_html__('ID', 'groppe-core') => 'ID',
            esc_html__('Author', 'groppe-core') => 'author',
            esc_html__('Title', 'groppe-core') => 'title',
            esc_html__('Date', 'groppe-core') => 'date',
          ),
          'param_name' => 'causes_orderby',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Show only certain categories?', 'groppe-core'),
          "param_name"  => "causes_show_category",
          "value"       => "",
          "description" => esc_html__( "Enter category SLUGS (comma separated) you want to display.", 'groppe-core')
        ),
        GroppeLib::vt_class_option(),

        // Stylings
        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Filter", 'groppe-core' ),
    			"param_name"  => 'flst_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'causes_style',
            'value'     => 'causes-grid',
          )
    		),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Color', 'groppe-core'),
          "param_name"  => "filter_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'causes_filter',
            'value' => 'true',
          ),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Active Color', 'groppe-core'),
          "param_name"  => "filter_active_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'causes_filter',
            'value' => 'true',
          ),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Active Background', 'groppe-core'),
          "param_name"  => "filter_active_bg",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'causes_filter',
            'value' => 'true',
          ),
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Text Size', 'groppe-core'),
          "param_name"  => "filter_size",
          "value"       => "",
          "group"       => esc_html__('Style', 'groppe-core'),
          "description" => esc_html__( "Enter filter text size in px.", 'groppe-core'),
          'dependency' => array(
            'element' => 'causes_filter',
            'value' => 'true',
          ),
        ),
        // Size
        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Item Style", 'groppe-core' ),
    			"param_name"  => 'itm_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
          "group"       => esc_html__('Style', 'groppe-core'),
    		),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Title Size', 'groppe-core'),
          "param_name"  => "causes_title_size",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Title Color', 'groppe-core'),
          "param_name"  => "causes_title_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Title Hover Color', 'groppe-core'),
          "param_name"  => "causes_title_hover_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'causes_style',
            'value' => 'bpw-style-two',
          ),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Content Color', 'groppe-core'),
          "param_name"  => "causes_content_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Content Size', 'groppe-core'),
          "param_name"  => "causes_content_size",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Donate Button Color', 'groppe-core'),
          "param_name"  => "causes_content_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Donate Button Size', 'groppe-core'),
          "param_name"  => "causes_content_size",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
        ),
      )
    ) );
  }
}

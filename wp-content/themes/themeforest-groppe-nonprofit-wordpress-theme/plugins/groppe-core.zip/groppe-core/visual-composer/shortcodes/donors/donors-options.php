<?php
/**
 * Donors - Shortcode Options
 */
add_action( 'init', 'donors_vc_map' );
if ( ! function_exists( 'donors_vc_map' ) ) {
  function donors_vc_map() {  
if ( class_exists( 'Give' ) ) {
  $args = array(
    'number' => -1,
  );

  $donors = Give()->customers->get_customers( $args );
  } else {
    $donors = array();
  }
  $donors_members = array();
  if ( $donors ) {
    foreach ( $donors as $donor ) {
      $donors_members[ $donor->name ] = $donor->id;
    }
  } else {
    $donors_members[ esc_html__( 'No Donors Member Found', 'groppe-core' ) ] = 0;
  }
    vc_map( array(
    "name" => esc_html__( "Donors", 'groppe-core'),
    "base" => "grop_donors",
    "description" => esc_html__( "Donors Style", 'groppe-core'),
    "icon" => "fa fa-users color-grey",
    "category" => GroppeLib::grop_cat_name(),
    "params" => array(
      array(
        "type" => "dropdown",
        "heading" => esc_html__( "Donors Column", 'groppe-core' ),
        "param_name" => "donors_column",
        "value" => array(
          esc_html__('Column Two', 'groppe-core') => 'col-2',
          esc_html__('Column Three', 'groppe-core') => 'col-3',
          esc_html__('Column Four', 'groppe-core') => 'col-4',
          esc_html__('Column Five', 'groppe-core') => 'col-5',
        ),
        "admin_label" => true,
        "description" => esc_html__( "Select donors column.", 'groppe-core'),
      ),
      array(
        "type" => "checkbox",
        "heading" => esc_html__( "Show Donors", 'groppe-core' ),
        "param_name" => "perticular_donors_member",
        "value" => $donors_members,
        "admin_label" => true,
        "description" => esc_html__( "Select donors Donors.", 'groppe-core'),
      ),
      GroppeLib::vt_class_option(),
      ), // Params
    ) );
  }
}
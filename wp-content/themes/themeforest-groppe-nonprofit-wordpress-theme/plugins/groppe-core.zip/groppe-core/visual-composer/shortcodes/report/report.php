<?php
/* ==========================================================
  Reports
=========================================================== */
if ( !function_exists('grop_report_function')) {
  function grop_report_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'report_style'  => '',
      'report_items'  => '',
      'curency'  => '',
      'class'  => '',
      // Style
      'text_color'  => '',
      'title_color'  => '',
      'text_size'  => '',
      'title_size'  => '',
    ), $atts));

    // Group Field
    $report_items = (array) vc_param_group_parse_atts( $report_items );
    $get_each_report = array();
    foreach ( $report_items as $report_item ) {
      $each_report = $report_item;
      $each_report['report_title'] = isset( $report_item['report_title'] ) ? $report_item['report_title'] : '';
      $each_report['amount'] = isset( $report_item['amount'] ) ? $report_item['amount'] : '';
      $each_report['chart_color'] = isset( $report_item['chart_color'] ) ? $report_item['chart_color'] : '';
      $get_each_report[] = $each_report;
    }

$raised_amount = array_reduce($get_each_report, function($carry, $item){
    $carry += str_replace(',', '', $item['amount']);
    return $carry;
});

    // Shortcode Style CSS
    $e_uniqid        = uniqid();
    $inline_style  = '';

    if ( $text_color || $text_size ) {
      $inline_style .= '.grop-report-'. $e_uniqid .' .grop-piechart_inrtxt h6, .grop-report-'. $e_uniqid .' .grop-piechart_inrtxt h5{';
      $inline_style .= ( $text_color ) ? 'color:'. $text_color .';' : '';
      $inline_style .= ( $text_size ) ? 'font-size:'. groppe_core_check_px($text_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $title_size || $title_color ) {
      $inline_style .= '.grop-report-'. $e_uniqid .'.grop-piechart_inrtxt h6 {';
      $inline_style .= ( $title_color ) ? 'color:'. $title_color .';' : '';
      $inline_style .= ( $title_size ) ? 'font-size:'. groppe_core_check_px($title_size) .';' : '';
      $inline_style .= '}';
    }

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-report-'. $e_uniqid;
    ob_start();
?>
  <div class="grop-flax_vr-middle  grop-pie_chart_warp <?php echo esc_attr( $class.    $styled_class ); ?>">
    <div class="grop-pie_chart">
      <div id="donut"></div>
      <div class="grop-piechart_inrtxt">
        <h6><?php echo esc_html__('Raised', 'groppe-core');  ?></h6>
        <h5><?php echo $curency.number_format($raised_amount); ?></h5>
      </div>
    </div>
  <div class="grop-fix grop-piechart_list">
    <ul data-pie-id="donut" data-options='{ 
                "donut":"true", 
                "donut_inner_ratio": "0.6", 
                "percent_offset": "0", 
                "show_text": "true", 
                "animation_speed":500, 
                "always_show_text": "false", 
                "show_grid": "true", 
                "bar_spacer": "100", 
                "bar_intervals": "6" }'>
    <?php
      $count = 0;
      foreach ( $get_each_report as $each_report ) {
        $progress = round( ( str_replace(',', '', $each_report['amount']) / $raised_amount ) * 100, 2 ); ?>
        <li data-id="g<?php echo $count; ?>" data-value="<?php echo esc_attr($progress); ?>" data-color="<?php echo esc_attr($each_report['chart_color']); ?>" data-title="<?php echo esc_attr( $each_report['report_title'] ); ?>">
          <span class="grop-pc_box"></span><?php echo $each_report['report_title'].' - '.$curency.$each_report['amount']; ?>
        </li>
    <?php $count++; } ?>
    </ul>
    </div>
    </div>
<?php
    return ob_get_clean();
  }
}
add_shortcode( 'grop_report', 'grop_report_function' );

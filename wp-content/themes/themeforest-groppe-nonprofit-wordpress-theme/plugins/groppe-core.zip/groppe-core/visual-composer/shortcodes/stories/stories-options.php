<?php
/**
 * Story - Shortcode Options
 */
add_action( 'init', 'story_vc_map' );
if ( ! function_exists( 'story_vc_map' ) ) {
  function story_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Groppe Story", 'groppe-core'),
      "base" => "grop_story",
      "description" => esc_html__( "Groppe Story", 'groppe-core'),
      "icon" => "fa fa-shield color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Story Column', 'groppe-core' ),
          'value' => array(
            esc_html__( '1 column', 'groppe-core' ) => 'col-1',
            esc_html__( '2 column', 'groppe-core' ) => 'col-2',
            esc_html__( '3 column', 'groppe-core' ) => 'col-3',
            esc_html__( '4 column', 'groppe-core' ) => 'col-4',
            esc_html__( '5 column', 'groppe-core' ) => 'col-5',
          ),
          'admin_label' => true,
          'param_name' => 'story_column',
        ),
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Story Images', 'groppe-core' ),
          'param_name' => 'items',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              'type' => 'attach_image',
              'value' => '',
              "admin_label"=> true,
              'heading' => esc_html__( 'Upload Image', 'groppe-core' ),
              'param_name' => 'image',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Image Title', 'groppe-core' ),
              'param_name' => 'title',
            )
          )
        ),
        GroppeLib::vt_class_option(),
      )
    ) );
  }
}

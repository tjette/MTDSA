<?php
/**
 * Call to Action - Shortcode Options
 */
add_action( 'init', 'impact_group_vc_map' );
if ( ! function_exists( 'impact_group_vc_map' ) ) {
 function impact_group_vc_map() {
   vc_map( array(
     "name" => esc_html__( "Group Impact", 'groppe-core'),
     "base" => "impact_group",
     "description" => esc_html__( "Impact Group", 'groppe-core'),
     "as_parent" => array('only' => 'single_impact'),
     "content_element" => true,
     "show_settings_on_create" => false,
     "is_container" => true,
     "icon" => "fa fa-bullhorn color-grey",
     "category" => GroppeLib::grop_cat_name(),
     "params" => array(
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Section Title', 'groppe-core'),
          "param_name"  => "title",
          "value"       => "",
          "admin_label" => true,
          "description" => esc_html__( "Enter title for the section", 'groppe-core')
        ),
        array(
          "type"        => 'textarea',
          "heading"     => esc_html__('Description', 'groppe-core'),
          "param_name"  => "description",
          "value"       => "",
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Button Text', 'groppe-core'),
          "param_name"  => "button_text",
          "value"       => "",
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Button URL', 'groppe-core'),
          "param_name"  => "button_link",
          "value"       => "",
        ),
        GroppeLib::vt_class_option(),

     ),
     "js_view" => 'VcColumnView'
   ) );
       //Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
    if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
        class WPBakeryShortCode_Impact_Group extends WPBakeryShortCodesContainer {
        }
    }
    if ( class_exists( 'WPBakeryShortCode' ) ) {
        class WPBakeryShortCode_Single_Impact extends WPBakeryShortCode {
        }
    }
 }
}

// Call to Action List
add_action( 'init', 'single_impact_vc_map' );
if ( ! function_exists( 'single_impact_vc_map' ) ) {
  function single_impact_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Impact Content", 'groppe-core'),
      "base" => "single_impact",
      "description" => esc_html__( "Impact content for group impact", 'groppe-core'),
      "icon" => "fa fa-font color-slate-blue",
      "as_child" => array('only' => 'impact_group'),
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Title', 'groppe-core'),
          "param_name"  => "title",
          "value"       => "",
          "admin_label" => true,
          "description" => esc_html__( "Enter the title of your impact", 'groppe-core')
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Title Link', 'groppe-core'),
          "param_name"  => "link",
          "value"       => "",
          "description" => esc_html__( "Enter the title link of your impact", 'groppe-core')
        ),
        array(
          "type"        => 'textarea',
          "heading"     => esc_html__('Description', 'groppe-core'),
          "param_name"  => "description",
          "value"       => "",
        ),
        array(
          "type"        => 'attach_image',
          "heading"     => esc_html__('Upload Image', 'groppe-core'),
          "param_name"  => "image",
          "value"       => "",
          "admin_label" => true,
        ),
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'List Items', 'groppe-core' ),
          'param_name' => 'list_items',
          'params' => array(
            array(
              "type"      => 'textfield',
              "heading"   => esc_html__('List Title', 'groppe-core'),
              "param_name" => "title",
              "value"      => "",
              'admin_label' => true,
            ),
            array(
              "type"      => 'textfield',
              "heading"   => esc_html__('List Link', 'groppe-core'),
              "param_name" => "link",
              "value"      => "",
            ),
          ),
        ),
      )
    ) );
  }
}
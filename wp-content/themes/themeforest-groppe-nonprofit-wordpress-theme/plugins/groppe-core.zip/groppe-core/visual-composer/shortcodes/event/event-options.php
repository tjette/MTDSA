<?php
/**
 * Event - Shortcode Options
 */
add_action( 'init', 'grop_event_vc_map' );
if ( ! function_exists( 'grop_event_vc_map' ) ) {
  function grop_event_vc_map() {
    $cf7 = get_posts( 'post_type="wpcf7_contact_form"&numberposts=-1' );
    $contact_forms = array();
    if ( $cf7 ) {
      foreach ( $cf7 as $cform ) {
        $contact_forms[ $cform->post_title ] = $cform->ID;
      }
    } else {
      $contact_forms[ esc_html__( 'No contact forms found', 'js_composer' ) ] = 0;
    }
    vc_map( array(
      "name" => esc_html__( "Event", 'groppe-core'),
      "base" => "grop_event",
      "description" => esc_html__( "Event Styles", 'groppe-core'),
      "icon" => "fa fa-briefcase color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(

        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Event Style', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Style List', 'groppe-core' ) => 'event-list',
            esc_html__( 'Style Grid', 'groppe-core' ) => 'event-grid',
          ),
          'admin_label' => true,
          'param_name' => 'event_style',
          'description' => esc_html__( 'Select your event style.', 'groppe-core' ),
        ),
        array(
          "type"        =>'textfield',
          "heading"     =>esc_html__('Limit', 'groppe-core'),
          "param_name"  => "event_limit",
          "value"       => "",
          'admin_label' => true,
          "description" => esc_html__( "Enter the number of items to show.", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Columns', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Event Columns', 'groppe-core' ) => '',
            esc_html__( 'Column Two', 'groppe-core' ) => 'column-two',
            esc_html__( 'Column Three', 'groppe-core' ) => 'column-three',
            esc_html__( 'Column Four', 'groppe-core' ) => 'column-four',
            esc_html__( 'Column Five', 'groppe-core' ) => 'column-five',
          ),
          'admin_label' => true,
          'param_name' => 'event_column',
          'description' => esc_html__( 'Select your event column.', 'groppe-core' ),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'dependency' => array(
            'element' => 'event_style',
            'value' => 'event-grid',
          ),
        ),

        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Enable & Disable", 'groppe-core' ),
    			"param_name"  => 'ends_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
    		),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Filter', 'groppe-core'),
          "param_name"  => "event_filter",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
          'dependency' => array(
            'element' => 'event_style',
            'value' => 'event-grid',
          ),
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Pagination', 'groppe-core'),
          "param_name"  => "event_pagination",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Listing", 'groppe-core' ),
    			"param_name"  => 'lsng_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
    		),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Order', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Event Order', 'groppe-core' ) => '',
            esc_html__('Asending', 'groppe-core') => 'ASC',
            esc_html__('Desending', 'groppe-core') => 'DESC',
          ),
          'param_name' => 'event_order',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Order By', 'groppe-core' ),
          'value' => array(
            esc_html__('None', 'groppe-core') => 'none',
            esc_html__('ID', 'groppe-core') => 'ID',
            esc_html__('Author', 'groppe-core') => 'author',
            esc_html__('Title', 'groppe-core') => 'title',
            esc_html__('Date', 'groppe-core') => 'date',
          ),
          'param_name' => 'event_orderby',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Show only certain categories?', 'groppe-core'),
          "param_name"  => "event_show_category",
          "value"       => "",
          "description" => esc_html__( "Enter category SLUGS (comma separated) you want to display.", 'groppe-core')
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Share Buttons', 'groppe-core'),
          "param_name"  => "event_share_btn",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Contact Button', 'groppe-core'),
          "param_name"  => "event_popup_btn",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Contact Button Type', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Simple Link', 'groppe-core' ) => 'link',
            esc_html__( 'Pop-up', 'groppe-core' ) => 'popup',
          ),
          'dependency' => array(
            'element' => 'event_popup_btn',
            'value' => 'true',
          ),
          'param_name' => 'contact_btn_type',
          'description' => esc_html__( 'Select your contact button type.', 'groppe-core' ),
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Contact Button Link', 'groppe-core'),
          "param_name"  => "contact_btn_link",
          "value"       => "",
          'dependency' => array(
            'element' => 'contact_btn_type',
            'value' => 'link',
          ),
          "description" => esc_html__( "Enter contatc button link.", 'groppe-core')
        ),

        array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Select pop-up contact form', 'js_composer' ),
        'param_name' => 'popup_form_id',
        'value' => $contact_forms,
        'save_always' => true,
        'dependency' => array(
          'element' => 'contact_btn_type',
          'value' => 'popup',
        ),
        'description' => esc_html__( 'Choose previously created contact form from the drop down list.', 'js_composer' ),
      ),
        GroppeLib::vt_class_option(),

        // Stylings
        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Filter", 'groppe-core' ),
    			"param_name"  => 'flst_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
          "group"       => esc_html__('Style', 'groppe-core'),
    		),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Color', 'groppe-core'),
          "param_name"  => "filter_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'event_filter',
            'value' => 'true',
          ),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Active Color', 'groppe-core'),
          "param_name"  => "filter_active_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'event_filter',
            'value' => 'true',
          ),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Active Background', 'groppe-core'),
          "param_name"  => "filter_active_bg",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'event_filter',
            'value' => 'true',
          ),
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Text Size', 'groppe-core'),
          "param_name"  => "filter_size",
          "value"       => "",
          "group"       => esc_html__('Style', 'groppe-core'),
          "description" => esc_html__( "Enter filter text size in px.", 'groppe-core'),
          'dependency' => array(
            'element' => 'event_filter',
            'value' => 'true',
          ),
        ),

        // Size
        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Item Style", 'groppe-core' ),
    			"param_name"  => 'itm_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
          "group"       => esc_html__('Style', 'groppe-core'),
    		),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Title Size', 'groppe-core'),
          "param_name"  => "event_title_size",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Title Color', 'groppe-core'),
          "param_name"  => "event_title_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Title Hover Color', 'groppe-core'),
          "param_name"  => "event_title_hover_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'event_style',
            'value' => 'bpw-style-two',
          ),
        ),
      )
    ) );
  }
}

<?php
/**
 * Call to Action - Shortcode Options
 */
add_action( 'init', 'banners_vc_map' );
if ( ! function_exists( 'banners_vc_map' ) ) {
 function banners_vc_map() {
   vc_map( array(
     "name" => esc_html__( "Top Banner", 'groppe-core'),
     "base" => "grop_banners",
     "description" => esc_html__( "Top Banner Group", 'groppe-core'),
     "as_parent" => array('only' => 'grop_banner,grop_link,vc_column_text'),
     "content_element" => true,
     "show_settings_on_create" => false,
     "is_container" => true,
     "icon" => "fa fa-bullhorn color-grey",
     "category" => GroppeLib::grop_cat_name(),
     "params" => array(
      array(
        "type"      => 'attach_image',
        "heading"   => esc_html__('Background Image', 'groppe-core'),
        "param_name" => "background",
        "value"      => "",
      ),
      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Overlay Color', 'groppe-core'),
        "param_name"  => "overlay",
        "value"       => "",
      ),
      array(
        'type' => 'dropdown',
        'heading' => __( 'Text Alignment', 'groppe-core' ),
        'value' => array(
          __( 'Left', 'groppe-core' ) => 'text-left',
          __( 'Right', 'groppe-core' ) => 'text-right',
          __( 'Center', 'groppe-core' ) => 'text-center',
        ),
        'param_name' => 'text_alignment',
        'description' => __( 'Select text alignment in this banner.', 'groppe-core' ),
      ),
      GroppeLib::vt_class_option(),

     ),
     "js_view" => 'VcColumnView'
   ) );
       //Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
    if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
        class WPBakeryShortCode_Grop_Banners extends WPBakeryShortCodesContainer {
        }
    }
    if ( class_exists( 'WPBakeryShortCode' ) ) {
        class WPBakeryShortCode_Grop_Banner extends WPBakeryShortCode {
        }
    }
 }
}

// Call to Action List
add_action( 'init', 'banner_vc_map' );
if ( ! function_exists( 'banner_vc_map' ) ) {
  function banner_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Top Banner - Content", 'groppe-core'),
      "base" => "grop_banner",
      "description" => esc_html__( "Top Banner Content", 'groppe-core'),
      "icon" => "fa fa-font color-slate-blue",
      "as_child" => array('only' => 'grop_banners'),
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          "type"        => 'textarea_html',
          "heading"     => esc_html__('Content', 'groppe-core'),
          "param_name"  => "content",
          "value"       => "",
          "description" => esc_html__( "Explain about your company achievement. Less than two paragraph is recommended.", 'groppe-core')
        ),
        GroppeLib::vt_class_option(),

      )
    ) );
  }
}
<?php
/* ==========================================================
  Links
=========================================================== */
if ( !function_exists('grop_donation_progress_function')) {
  function grop_donation_progress_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'target_amount'  => '',
      'raised_amount'  => '',
      'curency'  => '',
      'class'  => '',
    ), $atts));

    $target_amountt = (int) $target_amount;
    $raised_amountt = (int) $raised_amount;
    $progress = round( ( $raised_amountt / $target_amountt ) * 100, 2 );
    if ( $raised_amountt >= $target_amountt ) {
      $progress = 100;
    }
    $output = '<div class="grop-fix grop-cause_detail_cont">';
    $output .= '<div class="text-center  grop-float_left  grop-cause_detai_amunt_warp"><div class="grop-cause_detai_amunt_txt"><h4 class="grop-caudetai_title">'.esc_html__( 'Raised', 'groppe-core' ).'</h4><h4 class="grop-caudetai_amunt">'.$curency.'<span class="grop-conter">'. $raised_amount .'</span></h4></div></div>';
    $output .= '<div class="text-center  grop-float_left  grop-cause_detai_prgresbar_warp">
              <div class="text-left  grop-cause_detai_prgresbar">
                <div class="grop-skill_prgresbar">
                  <!-- bar 1 -->
                  <div class="grop-progress-bar" data-percentage="'.$progress.'%">
                    <div class="progress-title-holder">
                      <span class="progress-number-wrapper">
                        <span class="progress-number-mark">
                          <span class="percent"></span>
                          <span class="down-arrow"></span>
                        </span>
                      </span>
                    </div>
                    <div class="progress-content-outter">
                      <div class="progress-bar-striped animated progress-content"></div>
                    </div>
                  </div>
                </div>
              </div><!--/  end-->
            </div>';
    $output .= '<div class="text-center  grop-float_left  grop-cause_detai_amunt_warp">
              <div class="grop-cause_detai_amunt_txt">
                <h4 class="grop-caudetai_title">'.esc_html__( 'Goal', 'groppe-core' ).'</h4>
                <h4 class="grop-caudetai_amunt">'.$curency.'<span class="grop-conter">'. $target_amount.'</span></h4>
              </div>  
            </div>';
    $output .= '</div>';

    return $output;
  }
}
add_shortcode( 'grop_donation_progress', 'grop_donation_progress_function' );

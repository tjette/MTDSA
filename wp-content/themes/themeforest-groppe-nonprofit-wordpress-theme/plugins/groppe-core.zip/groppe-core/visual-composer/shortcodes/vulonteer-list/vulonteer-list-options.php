<?php
/**
 * Vulonteers - Shortcode Options
 */
add_action( 'init', 'grop_vulonteers_vc_map' );
if ( ! function_exists( 'grop_vulonteers_vc_map' ) ) {
  function grop_vulonteers_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Vulonteer List", 'groppe-core'),
      "base" => "grop_vulonteers",
      "description" => esc_html__( "Vulonteer List Shortcodes", 'groppe-core'),
      "icon" => "fa fa-list color-blue",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Vulonteers', 'groppe-core' ),
          'param_name' => 'vulonteer_items',
          'params' => array(
            array(
              "type"      => 'attach_image',
              "heading"   => esc_html__('Upload Icon', 'groppe-core'),
              "param_name" => "icon",
              "value"      => "",
              "description" => esc_html__( "Set your vulonteer icon image.", 'groppe-core'),
            ),
            array(
              "type"      => 'textfield',
              "heading"   => esc_html__('Vulonteer Title', 'groppe-core'),
              "param_name" => "title",
              "value"      => "",
              'admin_label' => true,
              "description" => esc_html__( "Enter your vulonteer list title.", 'groppe-core')
            ),
            array(
              "type"      => 'textfield',
              "heading"   => esc_html__('Vulonteer Link', 'groppe-core'),
              "param_name" => "link",
              "value"      => "",
              'admin_label' => true,
              "description" => esc_html__( "Enter your vulonteer title link.", 'groppe-core')
            ),
            array(
              "type"      => 'textarea',
              "heading"   => esc_html__('Description', 'groppe-core'),
              "param_name" => "desc",
              "value"      => "",
              "description" => esc_html__( "Enter your vulonteer content here.", 'groppe-core')
            ),
            GroppeLib::vt_open_link_tab(),
          ),
        ),
        GroppeLib::vt_class_option(),

        // Style
        GroppeLib::vt_notice_field(esc_html__( "Title Styling", 'groppe-core' ),'tle_opt','cs-warning', 'Style'), // Notice
        array(
          "type"      => 'colorpicker',
          "heading"   => esc_html__('Title Color', 'groppe-core'),
          "param_name" => "title_color",
          "value"      => "",
          "description" => esc_html__( "Pick your heading color.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"      => 'textfield',
          "heading"   => esc_html__('Title Size', 'groppe-core'),
          "param_name" => "title_size",
          "value"      => "",
          "description" => esc_html__( "Enter the numeric value for vulonteer_list size in px.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"      => 'colorpicker',
          "heading"   => esc_html__('Title Hover Color', 'groppe-core'),
          "param_name" => "title_hover_color",
          "value"      => "",
          "description" => esc_html__( "Pick your heading hover color.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        GroppeLib::vt_notice_field(esc_html__( "Description Styling", 'groppe-core' ),'tle_opt','cs-warning', 'Style'), // Notice
        array(
          "type"      => 'colorpicker',
          "heading"   => esc_html__('Description Color', 'groppe-core'),
          "param_name" => "content_color",
          "value"      => "",
          "description" => esc_html__( "Pick your content color.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"      => 'textfield',
          "heading"   => esc_html__('Description Size', 'groppe-core'),
          "param_name" => "content_size",
          "value"      => "",
          "description" => esc_html__( "Enter the numeric value for content size in px.", 'groppe-core'),
          "group" => esc_html__( "Style", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
      )
    ) );
  }
}

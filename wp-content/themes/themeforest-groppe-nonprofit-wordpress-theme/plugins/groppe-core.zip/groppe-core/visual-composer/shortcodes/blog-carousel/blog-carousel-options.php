<?php
/**
 * Blog Carousel - Shortcode Options
 */
add_action( 'init', 'blog_carousel_vc_map' );
if ( ! function_exists( 'blog_carousel_vc_map' ) ) {
  function blog_carousel_vc_map() {
  $blogs = get_posts( 'post_type="post"&numberposts=-1' );
  $blogsitems = array();
  if ( $blogs ) {
    foreach ( $blogs as $blog ) {
      $blogsitems[ $blog->post_title ] = $blog->ID;
    }
  } else {
    $blogsitems[ esc_html__( 'No post Found', 'groppe-core' ) ] = 0;
  }
    vc_map( array(
    "name" => esc_html__( "Blog Carousel", 'groppe-core'),
    "base" => "grop_blog_carousel",
    "description" => esc_html__( "Carousel Style Blog", 'groppe-core'),
    "icon" => "fa fa-comments color-green",
    "category" => GroppeLib::grop_cat_name(),
    "params" => array(

      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Title', 'groppe-core'),
        "param_name"  => "blog_title",
        "value"       => "",
        'admin_label' => true,
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Title Link', 'groppe-core'),
        "param_name"  => "blog_title_link",
        "value"       => "",
        'admin_label' => true,
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Description', 'groppe-core'),
        "param_name"  => "blog_desc",
        "value"       => "",
      ),
      array(
        "type"        => "notice",
        "heading"     => esc_html__( "Listing", 'groppe-core' ),
        "param_name"  => 'lsng_opt',
        'class'       => 'cs-warning',
        'value'       => '',
      ),
      array(
        "type" => "checkbox",
        "heading" => esc_html__( "Show Blog", 'groppe-core' ),
        "param_name" => "perticular_blog",
        "value" => $blogsitems,
        "admin_label" => true,
        "description" => esc_html__( "Select Blogs.", 'groppe-core'),
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Limit', 'groppe-core'),
        "param_name"  => "blog_limit",
        "value"       => "",
        'admin_label' => true,
        "description" => esc_html__( "Enter the number of items to show.", 'groppe-core'),
      ),
      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Order', 'groppe-core' ),
        'value' => array(
          esc_html__( 'Select Blog Order', 'groppe-core' ) => '',
          esc_html__('Asending', 'groppe-core') => 'ASC',
          esc_html__('Desending', 'groppe-core') => 'DESC',
        ),
        'param_name' => 'blog_order',
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Order By', 'groppe-core' ),
        'value' => array(
          esc_html__('None', 'groppe-core') => 'none',
          esc_html__('ID', 'groppe-core') => 'ID',
          esc_html__('Author', 'groppe-core') => 'author',
          esc_html__('Title', 'groppe-core') => 'title',
          esc_html__('Date', 'groppe-core') => 'date',
        ),
        'param_name' => 'blog_orderby',
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        => "notice",
        "heading"     => esc_html__( "Meta's to Hide", 'groppe-core' ),
        "param_name"  => 'mts_opt',
        'class'       => 'cs-warning',
        'value'       => '',
      ),
      array(
        "type"        => 'switcher',
        "heading"     => esc_html__('Category', 'groppe-core'),
        "param_name"  => "blog_category",
        "value"       => "",
        "std"         => false,
        'edit_field_class' => 'vc_col-md-3 vc_column vt_field_space',
      ),
      array(
        "type"        =>'switcher',
        "heading"     =>esc_html__('Date', 'groppe-core'),
        "param_name"  => "blog_date",
        "value"       => "",
        "std"         => false,
        'edit_field_class'   => 'vc_col-md-3 vc_column vt_field_space',
      ),
      array(
        "type"        =>'switcher',
        "heading"     =>esc_html__('Comments', 'groppe-core'),
        "param_name"  => "blog_comments",
        "value"       => "",
        "std"         => false,
        'edit_field_class'   => 'vc_col-md-3 vc_column vt_field_space',
      ),
      GroppeLib::vt_class_option(),

      // Carousel
      GroppeLib::vt_notice_field(esc_html__( "Basic Options", 'groppe-core' ),'bsic_opt','cs-warning', 'Carousel'), // Notice
      GroppeLib::vt_carousel_loop(), // Loop
      GroppeLib::vt_carousel_items(), // Items
      GroppeLib::vt_carousel_margin(), // Margin
      GroppeLib::vt_carousel_dots(), // Dots
      GroppeLib::vt_carousel_nav(), // Nav
      GroppeLib::vt_notice_field(esc_html__( "Auto Play & Interaction", 'groppe-core' ),'apyi_opt','cs-warning', 'Carousel'), // Notice
      GroppeLib::vt_carousel_autoplay_timeout(), // Autoplay Timeout
      GroppeLib::vt_carousel_autoplay(), // Autoplay
      GroppeLib::vt_carousel_animateout(), // Animate Out
      GroppeLib::vt_carousel_mousedrag(), // Mouse Drag
      GroppeLib::vt_notice_field(esc_html__( "Width & Height", 'groppe-core' ),'wah_opt','cs-warning', 'Carousel'), // Notice
      GroppeLib::vt_carousel_autowidth(), // Auto Width
      GroppeLib::vt_carousel_autoheight(), // Auto Height
      GroppeLib::vt_notice_field('Responsive Options','res_opt','cs-warning', 'Carousel'), // Notice
      GroppeLib::vt_carousel_tablet(), // Tablet
      GroppeLib::vt_carousel_mobile(), // Mobile
      GroppeLib::vt_carousel_small_mobile(), // Small Mobile

      ), // Params
    ) );
  }
}
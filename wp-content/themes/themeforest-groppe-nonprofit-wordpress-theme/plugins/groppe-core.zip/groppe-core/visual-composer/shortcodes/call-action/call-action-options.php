<?php
/**
 * Call to Action - Shortcode Options
 */
add_action( 'init', 'ctas_vc_map' );
if ( ! function_exists( 'ctas_vc_map' ) ) {
 function ctas_vc_map() {
   vc_map( array(
     "name" => esc_html__( "Call to Action", 'groppe-core'),
     "base" => "grop_ctas",
     "description" => esc_html__( "Call to Action Group", 'groppe-core'),
     "content_element" => true,
     "as_parent" => array('only' => 'grop_cta,grop_link,grop_title'),
     "show_settings_on_create" => false,
     "is_container" => true,
     "icon" => "fa fa-bullhorn color-grey",
     "category" => GroppeLib::grop_cat_name(),
     "params" => array(
        array(
          "type" => "dropdown",
          "heading" => __( "Call to Action Style", 'groppe-core' ),
          "param_name" => "cta_style",
          "value" => array(
            __('Style One', 'groppe-core') => 'style-one',
            __('Style Two', 'groppe-core') => 'style-two',
            __('Style Three (FAQ)', 'groppe-core') => 'style-three',
          ),
          "admin_label" => true,
          "description" => __( "Select Call to Action style.", 'groppe-core')
        ),
        GroppeLib::vt_class_option(),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Use Parallax?', 'groppe-core'),
          "param_name"  => "use_parallax",
          "value"       => "",
          "std"         => false,
          'dependency' => array(
            'element' => 'cta_style',
            'value' => 'style-one',
          ),
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Is Full Height?', 'groppe-core'),
          "param_name"  => "full_height",
          "value"       => "",
          "std"         => false,
          'dependency' => array(
            'element' => 'cta_style',
            'value' => 'style-one',
          ),
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          'type' => 'attach_image',
          'value' => '',
          'heading' => esc_html__( 'Upload Image', 'groppe-core' ),
          'param_name' => 'parallax_background',
          'dependency' => array(
            'element' => 'use_parallax',
            'value' => 'true',
          ),
        ),
        array(
          "type" => "textfield",
          "heading" => __( "Parallax Height", 'groppe-core' ),
          "param_name" => "parallax_height",
          'value' => '',
          'dependency' => array(
            'element' => 'cta_style',
            'value' => 'style-one',
          ),
          "description" => __( "Enter parallax height. [Eg: 340]", 'groppe-core'),
          "group" => __( "Styling", 'groppe-core'),
        ),
        array(
          "type" => "textfield",
          "heading" => __( "Call-to-action Height", 'groppe-core' ),
          "param_name" => "cta_height",
          'value' => '',
          'dependency' => array(
            'element' => 'cta_style',
            'value' => 'style-two',
          ),
          "description" => __( "Enter call-to-action height. [Eg: 150]", 'groppe-core'),
          "group" => __( "Styling", 'groppe-core'),
        ),
        // Design Tab
        array(
          "type" => "css_editor",
          "heading" => __( "Text Size", 'groppe-core' ),
          "param_name" => "css",
          'dependency' => array(
            'element' => 'cta_style',
            'value' => 'style-two',
          ),
          "group" => __( "Design", 'groppe-core'),
        ),

     ),
     "js_view" => 'VcColumnView'
   ) );
       //Your "container" content element should extend WPBakeryShortCodesContainer class to inherit all required functionality
    if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
        class WPBakeryShortCode_Grop_Ctas extends WPBakeryShortCodesContainer {
        }
    }
    if ( class_exists( 'WPBakeryShortCode' ) ) {
        class WPBakeryShortCode_Grop_Cta extends WPBakeryShortCode {
        }
    }
 }
}

// Call to Action List
add_action( 'init', 'cta_vc_map' );
if ( ! function_exists( 'cta_vc_map' ) ) {
  function cta_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Call to Action - Content", 'groppe-core'),
      "base" => "grop_cta",
      "description" => esc_html__( "Call to Action Content", 'groppe-core'),
      "icon" => "fa fa-font color-slate-blue",
      "as_child" => array('only' => 'grop_ctas'),
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(

        array(
          "type" => "dropdown",
          "heading" => __( "Content Style", 'groppe-core' ),
          "param_name" => "content_style",
          "value" => array(
            __('Style One', 'groppe-core') => 'style-one',
            __('Style Two', 'groppe-core') => 'style-two',
            __('Style Three', 'groppe-core') => 'style-three',
            __('Style Four (FAQ)', 'groppe-core') => 'style-four',
          ),
          "admin_label" => true,
          "description" => __( "Select Call to Action content style.", 'groppe-core')
        ),

        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Content Width', 'groppe-core'),
          "param_name"  => "content_width",
          "value"       => "",
          "admin_label" => true,
          "description" => esc_html__( "Enter your width in %. [Eg: 70%]. Rest of width will go for button.", 'groppe-core')
        ),
        array(
          "type"      => 'attach_image',
          "heading"   => __('Upload Left Side Image', 'groppe-core'),
          "param_name" => "cta_image",
          "value"      => "",
          'dependency' => array(
            'element' => 'content_style',
            'value' => 'style-one',
          ),
          "description" => __( "Set your left side image.", 'groppe-core'),
        ),
        array(
          "type"        => 'textarea_html',
          "heading"     => esc_html__('Content', 'groppe-core'),
          "param_name"  => "content",
          "value"       => "",
          "description" => esc_html__( "Explain about your company achievement. Less than two paragraph is recommended.", 'groppe-core')
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Title', 'groppe-core'),
          "param_name"  => "cta_three_title",
          "value"       => "",
          'dependency' => array(
            'element' => 'content_style',
            'value' => 'style-three',
          ),
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Description', 'groppe-core'),
          "param_name"  => "cta_three_description",
          "value"       => "",
          'dependency' => array(
            'element' => 'content_style',
            'value' => 'style-three',
          ),
        ),
        GroppeLib::vt_class_option(),

      )
    ) );
  }
}
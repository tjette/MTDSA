<?php
/* Call to Action */
if ( !function_exists('grop_banners_function')) {
  function grop_banners_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'class'  => '',
      'background'  => '',
      'overlay'  => '',
      'text_alignment' => '',
    ), $atts));

    $overlay = $overlay ? 'style="background-color:'. $overlay .';"' : '';
    if ($background) {
      $bg_image = wp_get_attachment_url( $background );
      $bg_image = '
          <div class="grop-rspnsive_fullheight grop-silder_banner">
            <img class="grop-img-full-screen" src="'.esc_url($bg_image).'" alt="#">
            <div class="grop-banner_overly-op-22" '.$overlay.'></div>
          </div>';
    } else {
      $bg_image = '';
    }
    // Output
    $output   = '
    <section class="grop-silder_area grop-silder_caption_text '.$class.''.$text_alignment.'">
        <div class="grop-silder">
          '.$bg_image.'
          <div class="grop-full_height  grop-silder_caption_area">
            <div class="grop-full_height  container">
              <div class="grop-vertical_middle">';
    $output  .= do_shortcode($content);
    $output  .= '
              </div>
            </div>
          </div>
        </div>
      </section>';
    return $output;

  }
}
add_shortcode( 'grop_banners', 'grop_banners_function' );

/* Call to Action */
if ( !function_exists('grop_banner_function')) {
  function grop_banner_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'class'  => '',
    ), $atts));

    // fix unclosed/unwanted paragraph tags in $content
    $content = wpb_js_remove_wpautop($content, true);
    $content = $content ? do_shortcode($content) : '';

    // Output
    return '<div class="grop-banner '. $class .'">'. $content .'</div>';

  }
}
add_shortcode( 'grop_banner', 'grop_banner_function' );
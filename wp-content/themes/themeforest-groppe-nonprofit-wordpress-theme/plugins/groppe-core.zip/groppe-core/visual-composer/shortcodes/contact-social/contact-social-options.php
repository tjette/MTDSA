<?php
/**
 * Contact Social - Shortcode Options
 */
add_action( 'init', 'contact_social_vc_map' );
if ( ! function_exists( 'contact_social_vc_map' ) ) {
  function contact_social_vc_map() {
    vc_map( array(
      "name" => __( "Contact Social", 'groppe-core'),
      "base" => "contact_social",
      "description" => __( "Contact Social Styles", 'groppe-core'),
      "icon" => "fa fa-usd color-orange",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(

        array(
          "type" => "textfield",
          "heading" => __( "Title", 'groppe-core' ),
          "param_name" => "title",
          'value' => '',
          'admin_label' => true,
          "description" => __( "Enter your title.", 'groppe-core'),
        ),
        array(
          "type" => "textarea",
          "heading" => __( "Description", 'groppe-core' ),
          "param_name" => "description",
          'value' => '',
          "description" => __( "Enter your description.", 'groppe-core'),
        ),

        GroppeLib::vt_class_option(),

        // List of features
        array(
          'type' => 'param_group',
          'value' => '',
          'param_name' => 'icon_items',
          'params' => array(
            array(
              "type" => "vt_icon",
              "heading" => __( "Select Icon", 'groppe-core' ),
              "param_name" => "select_icon",
              'value'      => '',
              'admin_label' => true,
              "description" => __( "Select Social icon.", 'groppe-core'),
              'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => __( 'Icon Link', 'groppe-core' ),
              'param_name' => 'icon_link',
            ),

          )
        ),

      )
    ) );
  }
}

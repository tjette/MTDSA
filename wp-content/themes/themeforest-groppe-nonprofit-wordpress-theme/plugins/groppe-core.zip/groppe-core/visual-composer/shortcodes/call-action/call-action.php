<?php
/* Call to Action */
if ( !function_exists('grop_ctas_function')) {
  function grop_ctas_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'class'  => '',
      'cta_style' => '',
      'use_parallax'  => '',
      'full_height'  => '',
      'parallax_height'  => '',
      'cta_height'  => '',
      'parallax_background'  => '',
      'css'   => '',
    ), $atts));

    // Design Tab
    $custom_css = ( function_exists( 'vc_shortcode_custom_css_class' ) ) ? vc_shortcode_custom_css_class( $css, ' ' ) : '';

    // Shortcode Style CSS
    $e_uniqid        = uniqid();
    $inline_style  = '';

    // Parallax Height
    if ( $parallax_height ) {
      $inline_style .= '.grop-parlx-'. $e_uniqid .' {';
      $inline_style .= ( $parallax_height ) ? 'height:'. groppe_core_check_px($parallax_height) .';' : '';
      $inline_style .= '}';
    }
    // Call-to-action Height
    if ( $cta_height ) {
      $inline_style .= '.grop-parlx-'. $e_uniqid .' {';
      $inline_style .= ( $cta_height ) ? 'height:'. groppe_core_check_px($cta_height) .';' : '';
      $inline_style .= '}';
    }

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-parlx-'. $e_uniqid;


    if ($use_parallax) {
      if (!empty( $parallax_background )) {
        $bg_image = wp_get_attachment_url( $parallax_background );
        $bg_image = ' style="background-image:url('.esc_url($bg_image).')"';
      } else {
        $bg_image = '';
      }
      $parallax_class = ' grop-parallax_area ';
    } else {
      $bg_image = '';
      $parallax_class = '';
    }

    if ($full_height) {
      $content_class = ' grop-full_height';
    } else {
      $content_class = '';
    }
    // Output
    if ($cta_style === 'style-two'){
      $output = '<div class="grop-callout_area '. esc_attr( $class.$parallax_class.$styled_class ) .'"'.$bg_image.'><div class="grop-vertical_middle  grop-fix grop-callout_container '.$content_class.' '.$custom_css.'">';
    } elseif ($cta_style === 'style-three'){
      $output = '<div class="grop-callout3_area '. esc_attr( $class.$parallax_class.$styled_class ) .'"'.$bg_image.'><div class="container text-center grop-callout3_cont grop-callout3faq_cont '.$content_class.' '.$custom_css.'">';
    } else {
      $output = '<div class="grop-cta grop-parallax_normel'. esc_attr( $class.$parallax_class.$styled_class ) .'"'.$bg_image.'><div class="container'.$content_class.'">';
    }

    $output  .= do_shortcode($content);
    $output  .= '</div></div>';
    return $output;

  }
}
add_shortcode( 'grop_ctas', 'grop_ctas_function' );

/* Call to Action */
if ( !function_exists('grop_cta_function')) {
  function grop_cta_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'content_width'  => '',
      'content_style' => '',
      'content_two' => '',
      'cta_image' => '',
      'class'  => '',
    ), $atts));

    // fix unclosed/unwanted paragraph tags in $content
    
    if ($content_style === 'style-two') {
      $cta_image_actual = '';
      $content_cls = 'text-left col-md-9   text-uppercase  grop-hm3callout_txt';
    } elseif ($content_style === 'style-three') {
      $cta_image_actual = '';
      $content_cls = 'grop-ab_calut_txt';
    } else {
      $content_cls = 'grop-float_left  grop-callout_txt_warp';
      $cta_image_actual = $cta_image ? '<div class="grop-callout_icon"><img src="'.wp_get_attachment_url($cta_image).'" alt=""></div>' : '';
    }
      $content = wpb_js_remove_wpautop($content, true);
      $content = $content ? do_shortcode($content) : '';
    $content_width = $content_width ? 'style="max-width:'. $content_width .'; margin: 0 auto;"' : '';

    // Output
    if ($content_style === 'style-four') {
      $output = $content;
    } elseif ($content_style === 'style-three') {
      $output = '<div class="'.$content_cls.'">'.$cta_image_actual.''. $content .'</div>';
    } else {
      $output ='<div class="grop-cta-cnt '. $class .'" '. $content_width .'><div class="'.$content_cls.'">'.$cta_image_actual.''. $content .'</div></div>';
    }

    return $output;

  }
}
add_shortcode( 'grop_cta', 'grop_cta_function' );

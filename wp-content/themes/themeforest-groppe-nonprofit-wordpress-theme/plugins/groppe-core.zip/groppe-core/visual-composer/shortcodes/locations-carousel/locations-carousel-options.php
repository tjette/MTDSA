<?php
/**
 * Contact - Shortcode Options
 */
add_action( 'init', 'location_carousel_vc_map' );
if ( ! function_exists( 'location_carousel_vc_map' ) ) {
  function location_carousel_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Location Carosel", 'groppe-core'),
      "base" => "location_carousel",
      "description" => esc_html__( "Location Carosel", 'groppe-core'),
      "icon" => "fa fa-shield color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Title', 'groppe-core' ),
          'param_name' => 'title',
        ),
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Title Link', 'groppe-core' ),
          'param_name' => 'title_link',
        ),
        array(
          'type' => 'textarea',
          'value' => '',
          'heading' => esc_html__( 'Description', 'groppe-core' ),
          'param_name' => 'description',
        ),
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Contact Items', 'groppe-core' ),
          'param_name' => 'items',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Item Title', 'groppe-core' ),
              'param_name' => 'item_title',
            ),
            array(
              'type' => 'textarea',
              'value' => '',
              'heading' => esc_html__( 'Item Description', 'groppe-core' ),
              'param_name' => 'item_description',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Adreess Prefix', 'groppe-core' ),
              'param_name' => 'prefix',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Adreess Text', 'groppe-core' ),
              'param_name' => 'address_title',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Adreess URL', 'groppe-core' ),
              'param_name' => 'url',
            )
          )
        ),
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Section Class', 'groppe-core' ),
          'param_name' => 'section_class',
        ),
        GroppeLib::vt_class_option(),
        // Carousel
        GroppeLib::vt_notice_field(esc_html__( "Basic Options", 'groppe-core' ),'bsic_opt','cs-warning', 'Carousel'), // Notice
        GroppeLib::vt_carousel_items(), // Items
        GroppeLib::vt_carousel_margin(), // Margin
        GroppeLib::vt_carousel_dots(), // Dots
        GroppeLib::vt_carousel_nav(), // Nav
        GroppeLib::vt_notice_field(esc_html__( "Auto Play & Interaction", 'groppe-core' ),'apyi_opt','cs-warning', 'Carousel'), // Notice
        GroppeLib::vt_carousel_autoplay(), // Autoplay
        GroppeLib::vt_notice_field(esc_html__( "Width & Height", 'groppe-core' ),'wah_opt','cs-warning', 'Carousel'), // Notice
        GroppeLib::vt_carousel_autowidth(), // Auto Width
        GroppeLib::vt_carousel_autoheight(), // Auto Height
        GroppeLib::vt_notice_field('Responsive Options','res_opt','cs-warning', 'Carousel'), // Notice
        GroppeLib::vt_carousel_tablet(), // Tablet
        GroppeLib::vt_carousel_mobile(), // Mobile
        GroppeLib::vt_carousel_small_mobile(), // Small Mobile
      )
    ) );
  }
}

<?php
/* ==========================================================
  Causes
=========================================================== */
if ( !function_exists('donation_form_function')) {
  function donation_form_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'form_title' => '',
      'class'  => '',
      'show_cause'  => '',
    ), $atts));

  ob_start(); ?>
  <!-- Causes Start -->
  <div class="donation-form-wrap grop-donation-form">
    <?php if ($form_title) { ?>
      <h2 class="text-uppercase grop-sctn_title_fntSz-30  grop-heading-59ae740228e39   text-uppercase"><?php echo esc_attr($form_title); ?></h2>
    <?php } ?>
        <div class="submit-form <?php echo esc_attr($class); ?>">
          <?php
          $args = array(
            'post_type' => 'give_forms',
            'posts_per_page' => 1,
            'orderby' => 'none',
            'order' => 'ASC',
            'post__in' => (array) $show_cause,
          );
          $grop_cas = new WP_Query( $args ); ?>

            <?php
            if ($grop_cas->have_posts()) : while ($grop_cas->have_posts()) : $grop_cas->the_post(); 
            
            $form        = new Give_Donate_Form( get_the_ID() );
            $goal_option = get_post_meta( get_the_ID(), '_give_goal_option', true );
            $goal        = $form->goal;
            $goal_format = get_post_meta( get_the_ID(), '_give_goal_format', true );
            $income      = $form->get_earnings();
            $color       = get_post_meta( get_the_ID(), '_give_goal_color', true );
            //Sanity check - ensure form has goal set to output
            if ( empty( $form->ID ) || ( is_singular( 'give_forms' ) && ! give_is_setting_enabled( $goal_option ) ) || ! give_is_setting_enabled( $goal_option ) || $goal == 0 ) {
              return false;
            }
            $payment_mode = give_get_chosen_gateway( get_the_ID() );
            $form_action = add_query_arg( apply_filters( 'give_form_action_args', array( 'payment-mode' => $payment_mode, ) ),  give_get_current_page_url() );
            
            $args = array(
              'number' => -1,
            ); ?>
            <form id="give-form-<?php echo get_the_ID(); ?>" action="<?php echo esc_url_raw( $form_action ); ?>" method="post">
              <input type="hidden" name="give-form-id" value="<?php echo esc_attr( $form->ID ); ?>"/>
              <input type="hidden" name="give-form-title" value="<?php echo htmlentities( $form->post_title ); ?>"/>
              <input type="hidden" name="give-current-url"
                   value="<?php echo htmlspecialchars( give_get_current_page_url() ); ?>"/>
              <input type="hidden" name="give-form-url"
                   value="<?php echo htmlspecialchars( give_get_current_page_url() ); ?>"/>
              <input type="hidden" name="give-form-minimum"
                   value="<?php echo give_format_amount( give_get_form_minimum_price( $form->ID ) ); ?>"/>
              <span class="give-hidden" style="display: none !important;">
                <label for="give-form-honeypot-<?php echo get_the_ID(); ?>"></label>
                <input id="give-form-honeypot-<?php echo get_the_ID(); ?>" type="text" name="give-honeypot" class="give-honeypot give-hidden"/>
              </span>
            <?php
            // Price ID hidden field for variable (mult-level) donation forms.
            if ( give_has_variable_prices( get_the_ID() ) ) {
              // Get default selected price ID.
              $prices   = apply_filters( 'give_form_variable_prices', give_get_variable_prices( get_the_ID() ), get_the_ID() );
              $price_id = 0;
              //loop through prices.
              foreach ( $prices as $price ) {
                if ( isset( $price['_give_default'] ) && $price['_give_default'] === 'default' ) {
                  $price_id = $price['_give_id']['level_id'];
                };
              }
              ?>
              <input type="hidden" name="give-price-id" value="<?php echo esc_attr( $price_id ); ?>"/>
            <?php }
            // do_action( 'give_checkout_form_top', $form->ID, $args );
            do_action( 'give_donation_form_top', $form->ID, $args );
            do_action( 'give_payment_mode_select', $form->ID, $args );
            do_action( 'give_checkout_form_bottom', $form->ID, $args ); ?>
          </form>
        </div>

      <?php
       endwhile;
       endif;?>
  </div>     
    <?php
    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'donation_form', 'donation_form_function' );

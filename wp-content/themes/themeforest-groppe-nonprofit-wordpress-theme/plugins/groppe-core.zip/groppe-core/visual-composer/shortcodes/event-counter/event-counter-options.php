<?php
/**
 * Event Counter - Shortcode Options
 */
add_action( 'init', 'grop_event_counter_vc_map' );
if ( ! function_exists( 'grop_event_counter_vc_map' ) ) {
  function grop_event_counter_vc_map() {
    vc_map( array(
      "name" =>  esc_html__( "Event Counter", 'groppe-core'),
      "base" => "grop_event_counter",
      "description" =>  esc_html__( "Event Counter Styles", 'groppe-core'),
      "icon" => "fa fa-sort-numeric-asc color-blue",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          "type"        =>'textfield',
          "heading"     => esc_html__('Event Title', 'groppe-core'),
          "param_name"  => "event_title",
          "value"       => "",
          "description" =>  esc_html__( "Enter your event title.", 'groppe-core')
        ),
        array(
          "type"        =>'textfield',
          "heading"     => esc_html__('Event Title Caption', 'groppe-core'),
          "param_name"  => "heading_text",
          "value"       => "",
          "description" =>  esc_html__( "Enter your event title caption.", 'groppe-core')
        ),
        array(
          "type"        =>'textfield',
          "heading"     => esc_html__('Button Text', 'groppe-core'),
          "param_name"  => "button_text",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        =>'href',
          "heading"     => esc_html__('Event URL', 'groppe-core'),
          "param_name"  => "event_url",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        =>'textfield',
          "heading"     => esc_html__('Event Date', 'groppe-core'),
          "param_name"  => "event_date",
          "value"       => "",
          "description" =>  esc_html__( "Date Formate is YYYY-MM-DD HH:MM:S Example:- 2017-12-08 16:12:12", 'groppe-core')
        ),
        GroppeLib::vt_class_option(),
      )
    ) );
  }
}

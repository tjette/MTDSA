<?php
/**
 * Story Carousel - Shortcode Options
 */
add_action( 'init', 'grop_story_carousel_vc_map' );
if ( ! function_exists( 'grop_story_carousel_vc_map' ) ) {
  function grop_story_carousel_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Story Carousel", 'groppe-core'),
      "base" => "grop_story_carousel",
      "description" => esc_html__( "Story Carousel", 'groppe-core'),
      "icon" => "fa fa-shield color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'textarea',
          'value' => '',
          'heading' => esc_html__( 'Story Title', 'groppe-core' ),
          'param_name' => 'title',
        ),
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Story Title Link', 'groppe-core' ),
          'param_name' => 'link',
        ),
        array(
          'type' => 'textarea',
          'value' => '',
          'heading' => esc_html__( 'Story Description', 'groppe-core' ),
          'param_name' => 'description',
        ),
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Story Images', 'groppe-core' ),
          'param_name' => 'items',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              'type' => 'attach_image',
              'value' => '',
              "admin_label"=> true,
              'heading' => esc_html__( 'Upload Image', 'groppe-core' ),
              'param_name' => 'image',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Image Title', 'groppe-core' ),
              'param_name' => 'title',
            )
          )
        ),
        GroppeLib::vt_class_option(),
      )
    ) );
  }
}

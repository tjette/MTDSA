<?php
/**
 * Team - Shortcode Options
 */
add_action( 'init', 'team_vc_map' );
if ( ! function_exists( 'team_vc_map' ) ) {
  function team_vc_map() {  
  $teams = get_posts( 'post_type="team"&numberposts=-1' );
  $team_members = array();
  if ( $teams ) {
    foreach ( $teams as $team ) {
      $team_members[ $team->post_title ] = $team->ID;
    }
  } else {
    $team_members[ esc_html__( 'No Team Member Found', 'groppe-core' ) ] = 0;
  }
    vc_map( array(
    "name" => esc_html__( "Team", 'groppe-core'),
    "base" => "grop_team",
    "description" => esc_html__( "Team Style", 'groppe-core'),
    "icon" => "fa fa-users color-grey",
    "category" => GroppeLib::grop_cat_name(),
    "params" => array(
      array(
        "type" => "dropdown",
        "heading" => esc_html__( "Team Style", 'groppe-core' ),
        "param_name" => "team_style",
        "value" => array(
          esc_html__('Basic', 'groppe-core') => 'basic',
          esc_html__('Standard', 'groppe-core') => 'standard',
        ),
        "admin_label" => true,
        "description" => esc_html__( "Select team style.", 'groppe-core'),
      ),
      array(
        "type" => "dropdown",
        "heading" => esc_html__( "Team Column", 'groppe-core' ),
        "param_name" => "team_standard_column",
        "value" => array(
          esc_html__('Column Three', 'groppe-core') => 'col-3',
          esc_html__('Column Four', 'groppe-core') => 'col-4',
        ),
        'dependency' => array(
          'element' => 'team_style',
          'value' => 'standard',
        ),
        "description" => esc_html__( "Select team column.", 'groppe-core'),
      ),
      array(
        "type" => "dropdown",
        "heading" => esc_html__( "Team Column", 'groppe-core' ),
        "param_name" => "team_column",
        "value" => array(
          esc_html__('Column Two', 'groppe-core') => 'col-2',
          esc_html__('Column Three', 'groppe-core') => 'col-3',
          esc_html__('Column Four', 'groppe-core') => 'col-4',
          esc_html__('Column Five', 'groppe-core') => 'col-5',
        ),
        'dependency' => array(
          'element' => 'team_style',
          'value' => 'basic',
        ),
        "description" => esc_html__( "Select team column.", 'groppe-core'),
      ),
      array(
        "type"        => "notice",
        "heading"     => esc_html__( "Listing", 'groppe-core' ),
        "param_name"  => 'lsng_opt',
        'class'       => 'cs-warning',
        'value'       => '',
      ),
      array(
        "type" => "checkbox",
        "heading" => esc_html__( "Show Members", 'groppe-core' ),
        "param_name" => "perticular_team_member",
        "value" => $team_members,
        "admin_label" => true,
        "description" => esc_html__( "Select team Members.", 'groppe-core'),
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Limit', 'groppe-core'),
        "param_name"  => "team_limit",
        "value"       => "",
        'admin_label' => true,
        "description" => esc_html__( "Enter the number of items to show.", 'groppe-core'),
      ),
      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Order', 'groppe-core' ),
        'value' => array(
          esc_html__( 'Select Team Order', 'groppe-core' ) => '',
          esc_html__('Asending', 'groppe-core') => 'ASC',
          esc_html__('Desending', 'groppe-core') => 'DESC',
        ),
        'param_name' => 'team_order',
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        'type' => 'dropdown',
        'heading' => esc_html__( 'Order By', 'groppe-core' ),
        'value' => array(
          esc_html__('None', 'groppe-core') => 'none',
          esc_html__('ID', 'groppe-core') => 'ID',
          esc_html__('Author', 'groppe-core') => 'author',
          esc_html__('Title', 'groppe-core') => 'title',
          esc_html__('Date', 'groppe-core') => 'date',
        ),
        'param_name' => 'team_orderby',
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Excerpt', 'groppe-core'),
        "param_name"  => "team_short_content",
        "value"       => "",
        "description" => esc_html__( "Enter the excerpt length.", 'groppe-core'),
      ),
      array(
          "type"        => "notice",
          "heading"     => __( "Enable & Disable", 'groppe-core' ),
          "param_name"  => 'ends_opt',
          'class'       => 'cs-warning',
          'value'       => '',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>__('Pagination', 'groppe-core'),
          "param_name"  => "team_pagination",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
      GroppeLib::vt_class_option(),
      // Style
      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Name Color', 'groppe-core'),
        "param_name"  => "name_color",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Profession Color', 'groppe-core'),
        "param_name"  => "profession_color",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Profession Background', 'groppe-core'),
        "param_name"  => "profession_bg",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        'dependency' => array(
          'element' => 'team_style',
          'value' => 'standard',
        ),
      ),
      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Content Color', 'groppe-core'),
        "param_name"  => "content_color",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Social Color', 'groppe-core'),
        "param_name"  => "social_color",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        'dependency' => array(
          'element' => 'team_style',
          'value' => 'standard',
        ),
      ),
      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Social Hover Color', 'groppe-core'),
        "param_name"  => "social_hover_color",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        'dependency' => array(
          'element' => 'team_style',
          'value' => 'standard',
        ),
      ),
      array(
        "type"        =>'colorpicker',
        "heading"     =>esc_html__('Social Title Color', 'groppe-core'),
        "param_name"  => "social_title_color",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        'dependency' => array(
          'element' => 'team_style',
          'value' => 'standard',
        ),
      ),
      // Size
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Name Size', 'groppe-core'),
        "param_name"  => "name_size",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Profession Size', 'groppe-core'),
        "param_name"  => "profession_size",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Content Size', 'groppe-core'),
        "param_name"  => "content_size",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        'dependency' => array(
          'element' => 'team_style',
          'value' => 'standard',
        ),
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Social Size', 'groppe-core'),
        "param_name"  => "social_size",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        'dependency' => array(
          'element' => 'team_style',
          'value' => 'standard',
        ),
      ),
      array(
        "type"        =>'textfield',
        "heading"     =>esc_html__('Social Title Size', 'groppe-core'),
        "param_name"  => "social_title_size",
        "value"       => "",
        "group"       => esc_html__('Style', 'groppe-core'),
        'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        'dependency' => array(
          'element' => 'team_style',
          'value' => 'standard',
        ),
      ),
      ), // Params
    ) );
  }
}
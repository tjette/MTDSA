<?php
/**
 * List - Shortcode Options
 */
add_action( 'init', 'grop_list_vc_map' );
if ( ! function_exists( 'grop_list_vc_map' ) ) {
  function grop_list_vc_map() {
    vc_map( array(
      "name" => esc_html__( "List", 'groppe-core'),
      "base" => "grop_list",
      "description" => esc_html__( "List Styles", 'groppe-core'),
      "icon" => "fa fa-list color-red",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(

        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'List Style', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Style One (Image or Icon)', 'groppe-core' ) => 'grop-list-one',
            esc_html__( 'Style Two (Simple Circle)', 'groppe-core' ) => 'grop-list-two',
            esc_html__( 'Style Three (Contact Section)', 'groppe-core' ) => 'grop-list-three',
            esc_html__( 'Style Four (Person Details)', 'groppe-core' ) => 'grop-list-four',
          ),
          'admin_label' => true,
          'param_name' => 'list_style',
          'description' => esc_html__( 'Select your list style.', 'groppe-core' ),
        ),

        // List
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Lists', 'groppe-core' ),
          'param_name' => 'list_items',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              'type' => 'dropdown',
              'value' => array(
                esc_html__( 'Icon', 'groppe-core' ) => 'list_icon',
                esc_html__( 'Image', 'groppe-core' ) => 'list_image',
              ),
              'heading' => esc_html__( 'Icon or Image', 'groppe-core' ),
              'param_name' => 'icon_image',
            ),
            array(
              'type' => 'vt_icon',
              'value' => '',
              'heading' => esc_html__( 'Select Icon', 'groppe-core' ),
              'param_name' => 'select_icon',
              'dependency' => array(
                'element' => 'icon_image',
                'value' => 'list_icon',
              ),
            ),
            array(
              'type' => 'attach_image',
              'value' => '',
              'heading' => esc_html__( 'Upload Icon Image', 'groppe-core' ),
              'param_name' => 'select_image',
              'dependency' => array(
                'element' => 'icon_image',
                'value' => 'list_image',
              ),
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'admin_label' => true,
              'heading' => esc_html__( 'Title', 'groppe-core' ),
              'param_name' => 'list_title',
            ),
            array(
              'type' => 'textarea',
              'value' => '',
              'heading' => esc_html__( 'Text', 'groppe-core' ),
              'param_name' => 'list_text',
            ),

          )
        ),
        GroppeLib::vt_class_option(),

        // Style
        array(
          'type' => 'colorpicker',
          'value' => '',
          'heading' => esc_html__( 'Text Color', 'groppe-core' ),
          'param_name' => 'text_color',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'group' => esc_html__( 'Style', 'groppe-core' ),
        ),
        array(
          'type' => 'colorpicker',
          'value' => '',
          'heading' => esc_html__( 'Bullet/Icon Color', 'groppe-core' ),
          'param_name' => 'icon_color',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'group' => esc_html__( 'Style', 'groppe-core' ),
        ),
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Text Size', 'groppe-core' ),
          'param_name' => 'text_size',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'group' => esc_html__( 'Style', 'groppe-core' ),
        ),
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Bullet/Icon Size', 'groppe-core' ),
          'param_name' => 'icon_size',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'group' => esc_html__( 'Style', 'groppe-core' ),
        ),
        array(
          'type' => 'colorpicker',
          'value' => '',
          'heading' => esc_html__( 'Title Color', 'groppe-core' ),
          'param_name' => 'title_color',
          'group' => esc_html__( 'Style', 'groppe-core' ),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'description' => esc_html__( 'Pick your title color.', 'groppe-core' ),
        ),
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Title Size', 'groppe-core' ),
          'param_name' => 'title_size',
          'group' => esc_html__( 'Style', 'groppe-core' ),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'description' => esc_html__( 'Enter the px value if you used title area in list style type one.', 'groppe-core' ),
        ),

      )
    ) );
  }
}

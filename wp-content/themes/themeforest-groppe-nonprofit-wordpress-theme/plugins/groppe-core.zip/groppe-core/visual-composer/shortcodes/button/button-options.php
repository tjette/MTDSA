<?php
/**
 * Button - Shortcode Options
 */
add_action( 'init', 'grop_link_vc_map' );
if ( ! function_exists( 'grop_link_vc_map' ) ) {
  function grop_link_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Button", 'groppe-core'),
      "base" => "grop_link",
      "description" => esc_html__( "Button Styles", 'groppe-core'),
      "icon" => "fa fa-link color-red",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'dropdown',
          'heading' => __( 'Button Style', 'groppe-core' ),
          'value' => array(
            __( 'Style One', 'groppe-core' ) => 'style-one',
            __( 'Style Two (Big button)', 'groppe-core' ) => 'style-two',
            __( 'Style Three (Transparent)', 'groppe-core' ) => 'style-three',
          ),
          'admin_label' => true,
          'param_name' => 'button_style',
          'description' => __( 'Select button style', 'groppe-core' ),
        ),
        array(
          "type" => "switcher",
          "heading" => esc_html__( "Call-out Button", 'groppe-core' ),
          "param_name" => "callout_btn",
          'value' => '',
          "on_text" => esc_html__( "Yes", 'groppe-core' ),
          "off_text" => esc_html__( "No", 'groppe-core' ),
          'dependency' => array(
            'element' => 'button_style',
            'value' => 'style-one',
          ),
        ),
        array(
          "type" => "switcher",
          "heading" => esc_html__( "Use Wrapper?", 'groppe-core' ),
          "param_name" => "use_wrapper",
          "std" => false,
          'value' => '',
          "on_text" => esc_html__( "Yes", 'groppe-core' ),
          "off_text" => esc_html__( "No", 'groppe-core' ),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        // Button
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Buttons', 'groppe-core' ),
          'param_name' => 'link_items',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              'type' => 'textfield',
              'value' => '',
              'admin_label' => true,
              'heading' => esc_html__( 'Title', 'groppe-core' ),
              'param_name' => 'title',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Link', 'groppe-core' ),
              'param_name' => 'link',
            ),
            GroppeLib::vt_class_option(),
            array(
              "type" => "switcher",
              "heading" => esc_html__( "Button Overlay Active", 'groppe-core' ),
              "param_name" => "overlay_active",
              'value' => '',
              "std" => true,
              "on_text" => esc_html__( "Yes", 'groppe-core' ),
              "off_text" => esc_html__( "No", 'groppe-core' ),
              'description' => __( 'This overlay will affect only for style two & style three', 'groppe-core' ),
            ),
            array(
              "type" => "switcher",
              "heading" => esc_html__( "Wrap Text With Span?", 'groppe-core' ),
              "param_name" => "wrap_span",
              "std" => true,
              'value' => '',
              "on_text" => esc_html__( "Yes", 'groppe-core' ),
              "off_text" => esc_html__( "No", 'groppe-core' ),
            ),
            array(
              "type" => "switcher",
              "heading" => esc_html__( "Open New Tab?", 'groppe-core' ),
              "param_name" => "open_link",
              "std" => false,
              'value' => '',
              "on_text" => esc_html__( "Yes", 'groppe-core' ),
              "off_text" => esc_html__( "No", 'groppe-core' ),
            ),

          )
        ),
        // GroppeLib::vt_class_option(),
        // Styling
        array(
          "type" => "colorpicker",
          "heading" => __( "Text Color", 'groppe-core' ),
          "param_name" => "text_color",
          'value' => '',
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "colorpicker",
          "heading" => __( "Text Hover Color", 'groppe-core' ),
          "param_name" => "text_hover_color",
          'value' => '',
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "colorpicker",
          "heading" => __( "Background Color", 'groppe-core' ),
          "param_name" => "background_color",
          'value' => '',
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => __( "Border Width", 'groppe-core' ),
          "param_name" => "border_width",
          'value' => '',
          "description" => __( "Enter button border width. [Eg: 2]", 'groppe-core'),
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "colorpicker",
          "heading" => __( "Background Hover Color", 'groppe-core' ),
          "param_name" => "bg_hover_color",
          'value' => '',
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "colorpicker",
          "heading" => __( "Border Color", 'groppe-core' ),
          "param_name" => "border_color",
          'value' => '',
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "colorpicker",
          "heading" => __( "Border Hover Color", 'groppe-core' ),
          "param_name" => "border_hover_color",
          'value' => '',
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => __( "Text Size", 'groppe-core' ),
          "param_name" => "text_size",
          'value' => '',
          "description" => __( "Enter button text font size. [Eg: 14px]", 'groppe-core'),
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => __( "Font Weight", 'groppe-core' ),
          "param_name" => "font_weight",
          'value' => '',
          "description" => __( "Enter button text font weight. [Eg: 500]", 'groppe-core'),
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => __( "Button Height", 'groppe-core' ),
          "param_name" => "btn_height",
          'value' => '',
          "description" => __( "Enter button height. [Eg: 42px]", 'groppe-core'),
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type" => "textfield",
          "heading" => __( "Button Line Height", 'groppe-core' ),
          "param_name" => "btn_line_height",
          'value' => '',
          "description" => __( "Enter button line height. [Eg: 20px]", 'groppe-core'),
          "group" => __( "Styling", 'groppe-core'),
          'edit_field_class'  => 'vc_col-md-6 vc_column vt_field_space',
        ),
        // Design Tab
        array(
          "type" => "css_editor",
          "heading" => __( "Text Size", 'groppe-core' ),
          "param_name" => "css",
          "group" => __( "Design", 'groppe-core'),
        ),
      )
    ) );
  }
}

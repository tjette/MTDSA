<?php
/* ==========================================================
  Services
=========================================================== */
if ( !function_exists('grop_services_function')) {
  function grop_services_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'service_style'  => '',
      'service_width'  => '',
      'service_column'  => '',
      'service_items'  => '',
      'service_items_2'  => '',
      'read_more_link'  => '',
      'read_more_title'  => '',
      'class'  => '',

      // Style
      'section_bg'  => '',
      'title_color'  => '',
      'title_size'  => '',
      'content_color'  => '',
      'content_size'  => '',
      'title_hover_color'  => '',
      'reademore_color'  => '',
      'reademore_size'  => '',
      'reademore_bg'  => '',
      'reademore_hover_color'  => '',
      'reademore_hover_bg'  => '',
    ), $atts));
    if ($service_style == 'simple'|| $service_style == 'icon-left' || $service_style == 'call-out') {
      $service_items = $service_items_2;
    } else {
      $service_items = $service_items;
    }
    $service_items = (array) vc_param_group_parse_atts( $service_items );
    $get_each_service = array();
    foreach ( $service_items as $service_item ) {
      $each_service = $service_item;
      $each_service['icon'] = isset( $service_item['icon'] ) ? $service_item['icon'] : '';
      $each_service['link'] = isset( $service_item['link'] ) ? $service_item['link'] : '';
      $each_service['title'] = isset( $service_item['title'] ) ? $service_item['title'] : '';
      $each_service['desc'] = isset( $service_item['desc'] ) ? $service_item['desc'] : '';
      $each_service['link_text'] = isset( $service_item['link_text'] ) ? $service_item['link_text'] : '';
      $each_service['open_link'] = isset( $service_item['open_link'] ) ? $service_item['open_link'] : '';
      $each_service['overlay_active'] = isset( $service_item['overlay_active'] ) ? $service_item['overlay_active'] : '';
      $get_each_service[] = $each_service;
    }
    // Style
    
    $e_uniqid        = uniqid();
    $inline_style  = '';
    // Name Color
    if ( $title_color || $title_size ) {
      $inline_style .= '.grop-service-'. $e_uniqid .' .grop-missions_txt h4, .grop-service-'. $e_uniqid .'.grop-missions_txt h4 a, .grop-service-'. $e_uniqid .' .grop-suprtus_tday_txt h4, .grop-service-'. $e_uniqid .' .grop-suprtus_tday_txt h4 a, .grop-service-'. $e_uniqid .' .help_single_itm_warp h4 a, .grop-service-'. $e_uniqid .' .help_single_itm_warp h4, .grop-service-'. $e_uniqid .' .grop-hm4srv_txt h4, .grop-service-'. $e_uniqid .' .grop-hm4srv_txt h4 a{';
      $inline_style .= ( $title_color ) ? 'color:'. $title_color .';' : '';
      $inline_style .= ( $title_size ) ? 'font-size:'. groppe_core_check_px($title_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $title_hover_color) {
      $inline_style .= '.grop-service-'. $e_uniqid .' .grop-missions_txt h4:hover, .grop-service-'. $e_uniqid .' .grop-missions_txt h4 a:hover, .grop-service-'. $e_uniqid .' .grop-suprtus_tday_txt h4 a:hover, .grop-service-'. $e_uniqid .' .help_single_itm_warp h4 a:hover, .grop-service-'. $e_uniqid .' .grop-hm4srv_txt h4 a:hover{';
      $inline_style .= ( $title_hover_color ) ? 'color:'. $title_hover_color .' !important;' : '';
      $inline_style .= '}';
    }
    if ( $content_color || $content_size ) {
      $inline_style .= '.grop-service-'. $e_uniqid .' .grop-missions_txt p, .grop-service-'. $e_uniqid .' .grop-hm4srv_txt p, .grop-service-'. $e_uniqid .' .help_single_itm_warp p, .grop-service-'. $e_uniqid .' .grop-suprtus_tday_txt p{';
      $inline_style .= ( $content_color ) ? 'color:'. $content_color .';' : '';
      $inline_style .= ( $content_size ) ? 'font-size:'. groppe_core_check_px($content_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $reademore_color || $reademore_size || $reademore_bg ) {
      $inline_style .= '.grop-service-'. $e_uniqid .' .grop-hm4srv_btn, .grop-service-'. $e_uniqid .' .grop-btn_overly, .grop-service-'. $e_uniqid .' .grop-help_btn{';
      $inline_style .= ( $reademore_color ) ? 'color:'. $reademore_color .' !important;' : '';
      $inline_style .= ( $reademore_bg ) ? 'background-color:'. $reademore_bg .' !important;' : '';
      $inline_style .= ( $reademore_size ) ? 'font-size:'. groppe_core_check_px( $reademore_size ) .';' : '';
      $inline_style .= '}';
    }

    if ( $reademore_hover_color || $reademore_hover_bg ) {
      $inline_style .= '.grop-service-'. $e_uniqid .' .grop-hm4srv_btn:hover, .grop-service-'. $e_uniqid .' .grop-hm4srv_btn:focus, .grop-service-'. $e_uniqid .' .grop-hm4srv_btn:before{';
      $inline_style .= ( $reademore_hover_color ) ? 'color:'. $reademore_hover_color .';' : '';
      $inline_style .= ( $reademore_hover_bg ) ? 'background-color:'. $reademore_hover_bg .';' : '';
      $inline_style .= '}';
    }

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-service-'. $e_uniqid;

    $service_column = $service_column ? $service_column: 'col-3';

    if ( $service_column == 'col-2' ) {
      $col_class = 'col-md-6';
    } elseif($service_column == 'col-4') {
      $col_class = 'col-md-3 col-sm-6';
    } else {
      $col_class = 'col-md-4 col-sm-4';
    }

  ob_start();
if ( $service_style == 'simple' ) { ?>
      <div class="grop-suprtus_tday_block">
        <div class="con-class <?php echo esc_attr($class.$styled_class ); ?>">
          <div class="row">
            <?php
            $count = 0;
            foreach ( $get_each_service as $each_service ) { 
            $link = $each_service['link'];
            $count++;
            $open_link = $each_service['open_link'] ? 'target="_blank"' : ''; 
            if ($service_column == 'col-3' && $count == 3) {
              $ofset_class = ' col-sm-offset-3  col-md-offset-0';
            } else {
              $ofset_class = '';
            } ?>
            <!--  single cont start \-->
            <div class="<?php echo esc_attr( $col_class.$ofset_class ); ?>">
              <div class="text-center  grop-suprtus_tday_single">
                <!--  icon start \-->
                <?php if( $each_service['icon'] ) {
                $groppe_alt = get_post_meta( $each_service['icon'], '_wp_attachment_image_alt', true);
                $icon = wp_get_attachment_url( $each_service['icon'] ); ?>
                <div class="grop-suprtus_tday_icon">
                  <img src="<?php echo esc_url( $icon ); ?>" alt="<?php echo esc_attr( $groppe_alt ); ?>" />
                </div>
                <div class="grop-suprtus_tday_txt">
                <?php }
                  if( !empty($link) ){
                    echo '<h4><a href="'.$each_service['link'].'" '.$open_link.'>'.$each_service['title'].'</a></h4>'; 
                  } else {
                   echo '<h4>'.$each_service['title'].'</h4>';
                  } 
                  if (!empty($each_service['desc'])) {
                    echo '<p>'.$each_service['desc'].'</p>';
                  }
                 ?>
                </div><!--/ end-->
                
              </div>
            </div><!--/ end-->
            <?php } ?>
          </div>
          
        </div>
        
      </div>
<?php } elseif ( $service_style == 'standard' ) { ?>
      <div class="grop-help_block">
        <div class="con-class <?php echo esc_attr( $class.$styled_class ); ?>">
          <div class="row">
          <?php
          $count = 0;
          foreach ( $get_each_service as $each_service ) { 
          $link = $each_service['link'];
          $count++;
          $open_link = $each_service['open_link'] ? 'target="_blank"' : ''; 
          if ($service_column == 'col-3' && $count == 3) {
            $ofset_class = ' col-sm-offset-0  col-md-offset-0';
          } else {
            $ofset_class = '';
          } ?>
            <!--  Single help item start \-->
            <div class="<?php echo esc_attr( $col_class.$ofset_class ); ?>">
              <div class="text-center  help_single_itm_warp">
              <?php if( $each_service['icon'] ) {
                $groppe_alt = get_post_meta( $each_service['icon'], '_wp_attachment_image_alt', true);
                $icon = wp_get_attachment_url( $each_service['icon'] ); ?>
                <div class="center-block  grop-hlp_symbol_icon">
                  <img src="<?php echo esc_url( $icon ); ?>" alt="<?php echo esc_attr( $groppe_alt ); ?>" />
                </div>
              <?php } 
                if( !empty($link) ){
                  echo '<h4><a href="'.$each_service['link'].'" '.$open_link.'>'.$each_service['title'].'</a></h4>'; 
                } else {
                 echo '<h4>'.$each_service['title'].'</h4>';
                } 
                if (!empty($each_service['desc'])) {
                  echo '<p>'.$each_service['desc'].'</p>';
                }
                if (!empty($each_service['link_text'])  || !empty($each_service['link']) ) {
                  if (!empty($each_service['link'])) {
                    echo '<a class="grop-btn grop-btn_overly grop-help_btn" href="'.esc_url($each_service['link']).'"><span>'.$each_service['link_text'].'</span></a>';
                  } else {
                    echo '<a class="grop-btn grop-btn_overly grop-help_btn"><span>'.$each_service['link_text'].'</span></a>';
                  }
                } ?>
              </div>
            </div><!--/  Single help item end-->
          <?php } ?>
          </div>
        </div>
      </div>
<?php } elseif ( $service_style == 'call-out' ) { 
      if ($service_width === 'fullwidth'){
        $service_width_cls = ''; 
      } else {
        $service_width_cls = 'container ';
      }
    ?>
     <div class="grop-callout2_warp">
      <div class="con-class <?php echo esc_attr( $service_width_cls.$class.$styled_class ); ?>">
        <div class="row grop-callout2_row">
          <?php $count = 0;
          foreach ( $get_each_service as $each_service ) { 
            $link = $each_service['link'];
            $count++;
            $open_link = $each_service['open_link'] ? 'target="_blank"' : ''; 
            if ($service_column == 'col-3' && $count == 3) {
              $ofset_class = ' col-sm-offset-0  col-md-offset-0';
            } else {
              $ofset_class = '';
            } ?>
            <div class="grop-callout2_single_warp <?php echo esc_attr( $col_class.$ofset_class ); ?>">
              <div class="grop-callout2_single">
                <?php if( $each_service['icon'] ) {
                  $groppe_alt = get_post_meta( $each_service['icon'], '_wp_attachment_image_alt', true);
                  $icon = wp_get_attachment_url( $each_service['icon'] ); ?>
                  <div class="grop-float_left  grop-callout2_icon">
                    <img src="<?php echo esc_url( $icon ); ?>" alt="<?php echo esc_attr( $groppe_alt ); ?>" />
                  </div>
                <?php } ?>
                <div class="grop-fix grop-callout2_text">
                  <?php
                  if( !empty($link) ){
                    echo '<h3><a href="'.$each_service['link'].'" '.$open_link.'>'.$each_service['title'].'</a></h3>'; 
                  } else {
                   echo '<h3>'.$each_service['title'].'</h3>';
                  } 
                  if (!empty($each_service['desc'])) {
                    echo '<p>'.$each_service['desc'].'</p>';
                  } ?>
                </div><!--/end-->
              </div>
            </div>
          <?php } ?>

        </div>
      </div>
    </div>
<?php } elseif ( $service_style == 'icon-left' ) { ?>
    <div class="grop-missions_area">
     <div class="grop-missions_block container <?php echo esc_attr( $class.$styled_class ); ?>">
      <div class="con-class <?php echo esc_attr( $class.$styled_class ); ?>">
        <div class="row">
          <?php $count = 0;
          foreach ( $get_each_service as $each_service ) { 
            $link = $each_service['link'];
            $count++;
            $open_link = $each_service['open_link'] ? 'target="_blank"' : ''; 
            if ($service_column == 'col-3' && $count == 3) {
              $ofset_class = ' col-sm-offset-0  col-md-offset-0';
            } else {
              $ofset_class = '';
            } ?>
            <div class="<?php echo esc_attr( $col_class.$ofset_class ); ?>">
              <div class="grop-missions_single">
                <?php if( $each_service['icon'] ) {
                  $groppe_alt = get_post_meta( $each_service['icon'], '_wp_attachment_image_alt', true);
                  $icon = wp_get_attachment_url( $each_service['icon'] ); ?>
                  <div class="grop-float_left  grop-missions_icon">
                    <img src="<?php echo esc_url( $icon ); ?>" alt="<?php echo esc_attr( $groppe_alt ); ?>" />
                  </div>
                <?php } ?>
                <div class="grop-fix grop-missions_txt">
                  <?php
                  if( !empty($link) ){
                    echo '<h4><a href="'.$each_service['link'].'" '.$open_link.'>'.$each_service['title'].'</a></h4>'; 
                  } else {
                   echo '<h4>'.$each_service['title'].'</h4>';
                  } 
                  if (!empty($each_service['desc'])) {
                    echo '<p>'.$each_service['desc'].'</p>';
                  } ?>
                </div><!--/end-->
              </div>
            </div>
          <?php } ?>

        </div>
      </div>
    </div>
  </div>
<?php } else { ?>
<div class="grop-hm4srv_box_area">
  <div class="con-class container <?php echo esc_attr( $class.$styled_class ); ?>">
    <?php 
    $count = 0;
    foreach ( $get_each_service as $each_service ) { 
      $open_link = $each_service['open_link'] ? 'target="_blank"' : ''; 
      $link_text = $each_service['link_text'] ? $each_service['link_text'] : esc_html__( 'Donate' ); 
      $link = $each_service['link']; 
      $overlay_active = $each_service['overlay_active'] ? 'hm4srv_active' : '';
      $count++;
      if ( $service_column == 'col-3' && $count == 3 ) {
        $ofset_class = ' col-sm-offset-0  col-md-offset-0';
      } else {
        $ofset_class = '';
      }
      ?>
      <!--single service start \-->
      <div class="<?php echo esc_attr( $col_class.$ofset_class ); ?> grop-hm4srv_box_warp <?php echo esc_attr($overlay_active); ?>">
        <div class="grop-hm4srv_box_single">
          <div class="grop-vertical_middle  grop-hm4srv_box">
            <!--icon start \-->
            <?php if($each_service['icon']) {
                $icon = wp_get_attachment_url( $each_service['icon'] ); ?>
                <div class="grop-fix  grop-float_left  grop-hm4srv_icon">
                  <img src="<?php echo esc_url( $icon ); ?>" alt="#" />
                </div>
              <?php } ?>
            <div class="grop-fix  grop-hm4srv_txt">
            <?php if( !empty($link) ){
                echo '<h4><a href="'.$each_service['link'].'">'.$each_service['title'].'</a></h4>'; 
              } else {
               echo '<h4>'.$each_service['title'].'</h4>';
              } 
              if (!empty($each_service['desc'])) {
                echo '<p>'.$each_service['desc'].'</p>';
              }
              if (!empty($link)) {
                echo '<a class="grop-btn grop-btn_overly grop-hm4srv_btn" href="'.esc_url( $link ).'">
                <span>'.esc_html__( $link_text, 'groppe-core' ).'</span>
              </a>';
              } ?>
              
            </div><!--/icon end-->
          </div>
        </div>
      </div><!--/single service end-->
      <?php } ?>
  </div>
</div>
<?php
}
 
    return ob_get_clean();
  }
}
add_shortcode( 'grop_services', 'grop_services_function' );

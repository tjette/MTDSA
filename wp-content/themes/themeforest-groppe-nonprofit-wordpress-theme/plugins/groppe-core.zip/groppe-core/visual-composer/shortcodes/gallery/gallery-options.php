<?php
/**
 * Gallery - Shortcode Options
 */
add_action( 'init', 'grop_gallery_vc_map' );
if ( ! function_exists( 'grop_gallery_vc_map' ) ) {
  function grop_gallery_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Gallery", 'groppe-core'),
      "base" => "grop_gallery",
      "description" => esc_html__( "Gallery Styles", 'groppe-core'),
      "icon" => "fa fa-briefcase color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Gallery Style', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Gallery Style', 'groppe-core' ) => '',
            esc_html__( 'Without Caption', 'groppe-core' ) => 'without_caption',
            esc_html__( 'With Caption', 'groppe-core' ) => 'with_caption',
          ),
          'admin_label' => true,
          'param_name' => 'gallery_style',
          'description' => esc_html__( 'Select your gallery style.', 'groppe-core' ),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        =>'textfield',
          "heading"     =>esc_html__('Limit', 'groppe-core'),
          "param_name"  => "gallery_limit",
          "value"       => "",
          'admin_label' => true,
          "description" => esc_html__( "Enter the number of items to show.", 'groppe-core'),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Columns', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Gallery Columns', 'groppe-core' ) => '',
            esc_html__( 'Column Two', 'groppe-core' ) => 'grop-galry_col-2',
            esc_html__( 'Column Three', 'groppe-core' ) => 'grop-galry_col-3',
            esc_html__( 'Column Four', 'groppe-core' ) => 'grop-galry_col-4',
          ),
          'admin_label' => true,
          'param_name' => 'gallery_column',
          'description' => esc_html__( 'Select your gallery column.', 'groppe-core' ),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),

        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Enable & Disable", 'groppe-core' ),
    			"param_name"  => 'ends_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
    		),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Filter', 'groppe-core'),
          "param_name"  => "gallery_filter",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
          "type"        =>'switcher',
          "heading"     =>esc_html__('Pagination', 'groppe-core'),
          "param_name"  => "gallery_pagination",
          "value"       => "",
          "std"         => true,
          'edit_field_class'   => 'vc_col-md-4 vc_column vt_field_space',
        ),
        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Listing", 'groppe-core' ),
    			"param_name"  => 'lsng_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
    		),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Order', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Select Gallery Order', 'groppe-core' ) => '',
            esc_html__('Ascending', 'groppe-core') => 'ASC',
            esc_html__('Desending', 'groppe-core') => 'DESC',
          ),
          'param_name' => 'gallery_order',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Order By', 'groppe-core' ),
          'value' => array(
            esc_html__('None', 'groppe-core') => 'none',
            esc_html__('ID', 'groppe-core') => 'ID',
            esc_html__('Author', 'groppe-core') => 'author',
            esc_html__('Title', 'groppe-core') => 'title',
            esc_html__('Date', 'groppe-core') => 'date',
          ),
          'param_name' => 'gallery_orderby',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Show only certain categories?', 'groppe-core'),
          "param_name"  => "gallery_show_category",
          "value"       => "",
          "description" => esc_html__( "Enter category SLUGS (comma separated) you want to display.", 'groppe-core')
        ),
        GroppeLib::vt_class_option(),

        // Stylings
        array(
    			"type"        => "notice",
    			"heading"     => esc_html__( "Filter", 'groppe-core' ),
    			"param_name"  => 'flst_opt',
    			'class'       => 'cs-warning',
    			'value'       => '',
          "group"       => esc_html__('Style', 'groppe-core'),
    		),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Color', 'groppe-core'),
          "param_name"  => "filter_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'gallery_filter',
            'value' => 'true',
          ),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Active Color', 'groppe-core'),
          "param_name"  => "filter_active_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'gallery_filter',
            'value' => 'true',
          ),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Active bg', 'groppe-core'),
          "param_name"  => "active_bg",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          'dependency' => array(
            'element' => 'gallery_filter',
            'value' => 'true',
          ),
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Text Size', 'groppe-core'),
          "param_name"  => "filter_size",
          "value"       => "",
          "group"       => esc_html__('Style', 'groppe-core'),
          "description" => esc_html__( "Enter filter text size in px.", 'groppe-core'),
          'dependency' => array(
            'element' => 'gallery_filter',
            'value' => 'true',
          ),
        ),
      )
    ) );
  }
}

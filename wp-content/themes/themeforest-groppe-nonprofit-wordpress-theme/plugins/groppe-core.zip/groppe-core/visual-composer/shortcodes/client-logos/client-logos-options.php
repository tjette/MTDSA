<?php
/**
 * Client Logos - Shortcode Options
 */
add_action( 'init', 'client_logos_vc_map' );
if ( ! function_exists( 'client_logos_vc_map' ) ) {
  function client_logos_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Client", 'groppe-core'),
      "base" => "grop_client_logos",
      "description" => esc_html__( "Client Logos", 'groppe-core'),
      "icon" => "fa fa-shield color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(

        GroppeLib::vt_open_link_tab(),

        // Client Logos
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Client Logos', 'groppe-core' ),
          'param_name' => 'client_logos',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              'type' => 'attach_image',
              'value' => '',
              'heading' => esc_html__( 'Upload Image', 'groppe-core' ),
              'param_name' => 'client_logo',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Client Link', 'groppe-core' ),
              'param_name' => 'client_link',
            )
          )
        ),
        GroppeLib::vt_class_option(),
      )
    ) );
  }
}

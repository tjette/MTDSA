<?php
/* ==========================================================
    Contact
=========================================================== */
if ( !function_exists('grop_contact_function')) {
  function grop_contact_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'contact_style' => '',
      'id'  => '',
      'form_title' => '',
      'class'  => '',
      // Style
      'submit_size'  => '',
      'submit_color'  => '',
      'submit_bg_color'  => '',  
    ), $atts)); 

    // Shortcode Style CSS
    $e_uniqid        = uniqid();
    $inline_style  = '';

    // Own Styles
    if ( $submit_size || $submit_color || $submit_bg_color ) {
      $inline_style .= '.grop-contact-'. $e_uniqid .' .wpcf7 input[type="submit"] {';
      $inline_style .= ( $submit_size ) ? 'font-size:'. groppe_core_check_px($submit_size) .';' : '';
      $inline_style .= ( $submit_color ) ? 'color:'. $submit_color .' !important;' : '';
      $inline_style .= ( $submit_bg_color ) ? 'background-color:'. $submit_bg_color .'!important;' : '';
      $inline_style .= '}';
    }

    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-contact-'. $e_uniqid;

    if ($contact_style === 'with-bg') {
      $bg_class = ' grop-bv_form_box';
    } else {
      $bg_class = '';
    }

    // Atts If
    $id = ( $id ) ? $id : '';
    $form_title = ( $form_title ) ? '<h3 class="grop-form_title">'. $form_title .'</h3>' : '';
    $class = ( $class ) ? ' '. $class : '';

    // Starts
    $output  = '<div class="grop-contact_form'. $styled_class . $class . $bg_class .'">';
    $output .= $form_title;
    $output .= do_shortcode( '[contact-form-7 id="'. $id .'"]' );
    $output .= '</div>';

    return $output;

  }
}
add_shortcode( 'grop_contact', 'grop_contact_function' );

<?php
/* ==========================================================
  Blog
=========================================================== */
if ( !function_exists('grop_blog_function')) {
  function grop_blog_function( $atts, $content = NULL ) {
    extract(shortcode_atts(array(
      'blog_style'  => '',
      'blog_column'  => '',
      'blog_limit'  => '',
      // Enable & Disable
      'blog_category'  => '',
      'blog_date'  => '',
      'blog_author'  => '',
      'blog_comments'  => '',
      'blog_pagination'  => '',
      // Listing
      'blog_order'  => '',
      'blog_orderby'  => '',
      'blog_show_category'  => '',
      'short_content'  => '',
      'class'  => '',
      // Read More Text
      'read_more_txt'  => '',
      // Miss Align
      'miss_align_height'  => '',
    ), $atts));


    // Excerpt
    if (groppe_framework_active()) {
      $excerpt_length = cs_get_option('theme_blog_excerpt');
      $excerpt_length = $excerpt_length ? $excerpt_length : '55';
      if ($short_content) {
        $short_content = $short_content;
      } else {
        $short_content = $excerpt_length;
      }
    } else {
      $short_content = '55';
    }

    // Style
    if ($blog_style === 'blog-grid') {
      $blog_style_class = 'grop-filter_content_warp ';
      $grid_before = '<div class="grop-filter_content">';
      $grid_after = '</div>';
      $single_class = 'grop-filter_single_col';
    } else {
      $blog_style_class = 'grop-blog_post_warp ';
      $grid_before = '';
      $grid_after = '';
      $single_class = ' grop-blog_post ';
    }

    // Read More Text
    if (groppe_framework_active()) {
      $read_more_to = cs_get_option('read_more_text');
      if ($read_more_txt) {
        $read_more_txt = $read_more_txt;
      } elseif($read_more_to) {
        $read_more_txt = $read_more_to;
      } else {
        $read_more_txt = esc_html__( 'Read More', 'groppe-core' );
      }
    } else {
      $read_more_txt = $read_more_txt ? $read_more_txt : esc_html__( 'Read More', 'groppe-core' );
    }
    // Turn output buffer on
    ob_start();

    // Pagination
		global $paged;
    if( get_query_var( 'paged' ) )
      $my_page = get_query_var( 'paged' );
    else {
      if( get_query_var( 'page' ) )
        $my_page = get_query_var( 'page' );
      else
        $my_page = 1;
      set_query_var( 'paged', $my_page );
      $paged = $my_page;
    }

    $args = array(
      // other query params here,
      'paged' => $my_page,
      'post_type' => 'post',
      'posts_per_page' => (int)$blog_limit,
      'category_name' => esc_attr($blog_show_category),
      'orderby' => $blog_orderby,
      'order' => $blog_order
    );

    $grop_post = new WP_Query( $args ); ?>

    <!-- Blog Start -->
    <div class="grop-blog-wrap <?php echo esc_attr($blog_style_class.$blog_column.' '. $class); ?>">
      <?php
      echo $grid_before;
      if ($grop_post->have_posts()) : while ($grop_post->have_posts()) : $grop_post->the_post();

        $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
        $large_image = $large_image[0];
        $post_type = get_post_meta( get_the_ID(), 'post_type_metabox', true ); ?>
      <article id="post-<?php the_ID(); ?>" <?php post_class( $single_class ); ?>>
        <?php
				if ($blog_style === 'blog-grid') { ?>
				<div class="grop-hm3news_single_post_warp  grop-blog_grid">
					<div class="grop-news_pst_media">
						<?php if ( 'gallery' == get_post_format() && ! empty( $post_type['gallery_post_format'] ) ) { ?>
	          <div class="owl-carousel  grop-oimt_carousel" data-autoplay="false" data-center="true" data-dots="false" data-nav="false">
								<?php $groppe_ids = explode( ',', $post_type['gallery_post_format'] );
							  foreach ( $groppe_ids as $id ) {
							    $groppe_attachment = wp_get_attachment_image_src( $id, 'full' );
							    $groppe_alt = get_post_meta($id, '_wp_attachment_image_alt', true);
							    echo '<div class="grop-oimt_single"><img src="'. $groppe_attachment[0] .'" alt="'. esc_attr( $groppe_alt ) .'" /></div>';
							  } ?>
	          </div>
	        	<?php
	        	} elseif ($large_image) { ?>
	          	<img src="<?php echo esc_attr( $large_image ); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
	        	<?php } // Featured Image ?>
					</div><!--/ end-->
					<div class="grop-news_pst_cont_warp">
						<div class="grop-news_pst_cont">
						<?php if ( !$blog_date ) { ?>
							<div class="grop-news_ps_date">
								<i class="fa fa-clock-o"></i> <?php echo get_the_date('d M Y'); ?>
							</div>
							<?php }
							if (!empty(get_the_title())) {
							 	echo '<h4 class="grop-news_ps_title"><a href="'.esc_url( get_the_permalink() ).'">'.get_the_title().'</a></h4>';
							}?>
							<p><?php
			          if (groppe_framework_active()) {
			            groppe_excerpt($short_content);
			          } else {
			            the_excerpt();
			          }
			          if ( function_exists( 'groppe_wp_link_pages' ) ) {
			            echo groppe_wp_link_pages();
			          }
			          ?>
			        </p>
						</div><!--/ end-->
						<!--meta element start \-->
						<?php if ( !$blog_category || !$blog_comments ) { ?>
						<div class="grop-fix grop-news_pst_meta">
							<?php
	            if ( !$blog_category ) { // Category Hide
	              if ( get_post_type() === 'post') {
	                $category_list = get_the_category_list( ', ' );
	                if ( $category_list ) {
	            ?>
							<div class="grop-float_left grop-news_pst_in">
								 	<?php echo esc_html__( 'in ', 'groppe-core' ).$category_list; ?>
							</div>
							<?php 
									} 
								} 
							}
							if( !$blog_comments ) {
							 ?>
							<div class="grop-float_right grop-news_pst_commnt">
								<?php comments_popup_link( __( '<i class="fa fa-comment-o"></i>0', 'groppe' ), __( '<i class="fa fa-comment-o"></i>1', 'groppe' ), __( '<i class="fa fa-comment-o"></i>%', 'groppe' ), '', '' ); ?>
							</div>
							<?php } ?>
						</div><!--/ end-->
						<?php } ?>
					</div>
				</div>
				<?php
				} else { ?>
				<header class="grop-post_header">
					<div class="grop-post_image">
						<?php if ( 'gallery' == get_post_format() && ! empty( $post_type['gallery_post_format'] ) ) { ?>
						<div class="owl-carousel  grop-oimt_carousel" data-autoplay="false" data-center="true" data-dots="false" data-nav="false">
								<?php $groppe_ids = explode( ',', $post_type['gallery_post_format'] );
							  foreach ( $groppe_ids as $id ) {
							    $groppe_attachment = wp_get_attachment_image_src( $id, 'full' );
							    $groppe_alt = get_post_meta($id, '_wp_attachment_image_alt', true);
							    echo '<div class="grop-oimt_single"><img src="'. $groppe_attachment[0] .'" alt="'. esc_attr($groppe_alt) .'" /></div>';
							  } ?>
	          </div>
	        	<?php
	        	} elseif ($large_image) { ?>
	          	<img src="<?php echo esc_attr( $large_image ); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
	        	<?php } ?>
					</div>
            <p class="grop-post_meta">
              <?php
              if ( !$blog_date ) { // Date Hide
              ?>
              <span class="grop-post_date"><i class="fa fa-clock-o"></i><?php echo get_the_date('d M Y'); ?></span>
              <?php } // Date Hides
              if ( !$blog_category ) { // Category Hide
                if ( get_post_type() === 'post') {
                  $category_list = get_the_category_list( ', ' );
                  if ( $category_list ) {
                    echo '<span class="grop-post_in"><i class="fa fa-folder-o"></i>In '. $category_list .' </span>';
                  }
                }
              } // Category Hides
              if ( !$blog_author ) { // Author Hide
              ?>
              <span class="grop-post_by">
                <?php
                printf(
                  '<i class="fa fa-pencil"></i>'. esc_html__('By','groppe') .'<span> <a href="%1$s" rel="author">%2$s</a></span>',
                  esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
                  get_the_author()
                );
                ?>
              </span>
              <?php } ?>
            </p>
					<?php
          if (!empty(get_the_title())) {
					 	echo '<h2 class="grop-post_title"><a href="'.esc_url( get_the_permalink() ).'">'.get_the_title().'</a></h2>';
					} ?>
				</header>
				<div class="grop-post_content">
					<p><?php
          if (groppe_framework_active()) {
            groppe_excerpt($short_content);
          } else {
            the_excerpt();
          }
          if ( function_exists( 'groppe_wp_link_pages' ) ) {
            echo groppe_wp_link_pages();
          }
          ?></p>
				</div>
				<footer class="row grop-post_footer">
					<div class="text-left  col-xs-6">
						<a class="grop-btn grop-btn_overly grop-postrm_btn bp-read-more" href="<?php echo esc_url( get_permalink() ); ?>">
							<span><?php echo esc_attr($read_more_txt); ?></span>
						</a>
					</div>
					<?php if (!$blog_comments) { ?>
						<div class="text-right  col-xs-6">
						<?php comments_popup_link( __( '<span class="grop-post_comnt"><i class="fa fa-comment-o"></i><span>0</span></span>', 'groppe' ), __( '<span class="grop-post_comnt"><i class="fa fa-comment-o"></i><span>1</span></span>', 'groppe' ), __( '<span class="grop-post_comnt"><i class="fa fa-comment-o"></i><span>%</span></span>', 'groppe' ), '', '' ); ?>
						</div>
					<?php } ?>
				</footer>
			<?php	} ?>
        </article><!-- #post-## -->
      <?php
      endwhile;
      endif;
      wp_reset_postdata();
      echo $grid_after; ?>
    </div>
    <!-- Blog End -->
    <?php
    if ($blog_pagination) {
      groppe_custom_paging_nav($grop_post->max_num_pages,"",$paged);
    }

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'grop_blog', 'grop_blog_function' );
<?php
/**
 * Causes - Shortcode Options
 */
add_action( 'init', 'grop_featured_causes_vc_map' );
if ( ! function_exists( 'grop_featured_causes_vc_map' ) ) {
  function grop_featured_causes_vc_map() {
  $causes = get_posts( 'post_type="give_forms"&numberposts=-1' );
  $all_causes = array();
  if ( $causes ) {
    foreach ( $causes as $cause ) {
      $all_causes[ $cause->post_title ] = $cause->ID;
    }
  } else {
    $all_causes[ esc_html__( 'No contact forms found', 'groppe-core' ) ] = 0;
  }

    vc_map( array(
      "name" => esc_html__( "Featured Causes", 'groppe-core'),
      "base" => "grop_featured_causes",
      "description" => esc_html__( "Featured Causes Styles", 'groppe-core'),
      "icon" => "fa fa-briefcase color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          "type" => "checkbox",
          "heading" => __( "Show Cause", 'groppe-core' ),
          "param_name" => "show_cause",
          "value" => $all_causes,
          "admin_label" => true,
          "description" => __( "Select featured cause.", 'groppe-core'),
        ),

        GroppeLib::vt_class_option(),
      )
    ) );
  }
}

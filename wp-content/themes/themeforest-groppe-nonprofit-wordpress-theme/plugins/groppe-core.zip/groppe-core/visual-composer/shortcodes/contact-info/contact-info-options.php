<?php
/**
 * Contact - Shortcode Options
 */
add_action( 'init', 'contact_address_vc_map' );
if ( ! function_exists( 'contact_address_vc_map' ) ) {
  function contact_address_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Contact Address", 'groppe-core'),
      "base" => "contact_address",
      "description" => esc_html__( "Contact Address", 'groppe-core'),
      "icon" => "fa fa-shield color-green",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Title', 'groppe-core' ),
          'param_name' => 'title',
        ),
        array(
          'type' => 'textarea',
          'value' => '',
          'heading' => esc_html__( 'Description', 'groppe-core' ),
          'param_name' => 'description',
        ),
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Contact Images', 'groppe-core' ),
          'param_name' => 'items',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Adreess Prefix', 'groppe-core' ),
              'param_name' => 'prefix',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Adreess Text', 'groppe-core' ),
              'param_name' => 'address_title',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Adreess URL', 'groppe-core' ),
              'param_name' => 'url',
            )
          )
        ),
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Section Class', 'groppe-core' ),
          'param_name' => 'section_class',
        ),
        GroppeLib::vt_class_option(),
      )
    ) );
  }
}

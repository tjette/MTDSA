<?php
/* ==========================================================
  Sectors
=========================================================== */
if ( !function_exists('grop_sectors_function')) {
  function grop_sectors_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'sector_column'  => '',
      'sector_items'  => '',
      'class'  => '',

      // Style
      'section_bg'  => '',
      'title_color'  => '',
      'title_size'  => '',
      'title_hover_color'  => '',
      'reademore_color'  => '',
      'reademore_size'  => '',
      'reademore_bg'  => '',
      'reademore_hover_color'  => '',
      'reademore_hover_bg'  => '',
    ), $atts));

    $sector_items = (array) vc_param_group_parse_atts( $sector_items );
    
    $get_each_sector = array();
    foreach ( $sector_items as $sector_item ) {
      $each_sector = $sector_item;
      $each_sector['icon'] = isset( $sector_item['icon'] ) ? $sector_item['icon'] : '';
      $each_sector['link'] = isset( $sector_item['link'] ) ? $sector_item['link'] : '';
      $each_sector['title'] = isset( $sector_item['title'] ) ? $sector_item['title'] : '';
      $each_sector['link_text'] = isset( $sector_item['link_text'] ) ? $sector_item['link_text'] : '';
      $each_sector['open_link'] = isset( $sector_item['open_link'] ) ? $sector_item['open_link'] : '';
      $get_each_sector[] = $each_sector;
    }
    // Style
    
    $e_uniqid        = uniqid();
    $inline_style  = '';
    // Name Color
    if ( $title_color || $title_size ) {
      $inline_style .= '.grop-sector-'. $e_uniqid .' .grop-dont_sectors_txt .grop-dont_sectors_mta{';
      $inline_style .= ( $title_color ) ? 'color:'. $title_color .';' : '';
      $inline_style .= ( $title_size ) ? 'font-size:'. groppe_core_check_px($title_size) .';' : '';
      $inline_style .= '}';
    }
    if ( $title_hover_color) {
      $inline_style .= '.grop-sector-'. $e_uniqid .' .grop-dont_sectors_txt .grop-dont_sectors_mta:hover{';
      $inline_style .= ( $title_hover_color ) ? 'color:'. $title_hover_color .';' : '';
      $inline_style .= '}';
    }
    if ( $reademore_color || $reademore_size || $reademore_bg ) {
      $inline_style .= '.grop-sector-'. $e_uniqid .' .grop-dont_sectors_txt .grop-dont_sectors_btn{';
      $inline_style .= ( $reademore_color ) ? 'color:'. $reademore_color .' !important;' : '';
      $inline_style .= ( $reademore_bg ) ? 'background-color:'. $reademore_bg .' !important;' : '';
      $inline_style .= ( $reademore_size ) ? 'font-size:'. groppe_core_check_px( $reademore_size ) .';' : '';
      $inline_style .= '}';
    }

    if ( $reademore_hover_color || $reademore_hover_bg ) {
      $inline_style .= '.grop-sector-'. $e_uniqid .' .grop-dont_sectors_txt .grop-dont_sectors_btn:hover{';
      $inline_style .= ( $reademore_hover_color ) ? 'color:'. $reademore_hover_color .';' : '';
      $inline_style .= ( $reademore_hover_bg ) ? 'background-color:'. $reademore_hover_bg .';' : '';
      $inline_style .= '}';
    }
    // add inline style
    add_inline_style( $inline_style );
    $styled_class  = ' grop-sector-'. $e_uniqid;

    $sector_column = $sector_column ? $sector_column: 'col-3';

    if ( $sector_column == 'col-2' ) {
      $col_class = 'col-md-6 col-sm-6 col-xs-6';
    } elseif($sector_column == 'col-4') {
      $col_class = 'col-md-3 col-sm-6 col-xs-6';
    } else {
      $col_class = 'col-md-4 col-sm-6 col-xs-6';
    }

  ob_start();
?>
<div class="grop-dont_sectors_area">
    <?php 
    $count = 0;
    foreach ( $get_each_sector as $each_sector ) { 
      $open_link = $each_sector['open_link'] ? 'target="_blank"' : ''; 
      $link_text = $each_sector['link_text'] ? $each_sector['link_text'] : esc_html__( 'Donate Now', 'groppe-core' );
      $link = $each_sector['link']; 
      $count++;
      if ( $sector_column == 'col-3' && $count == 3 ) {
        $ofset_class = ' col-sm-offset-3  col-md-offset-0';
      } else {
        $ofset_class = '';
      }
      ?>
      <!--single sector start \-->
      <div class="grop-donor-itm <?php echo esc_attr( $col_class.$ofset_class ); ?>">
        <div class="grop-fix  grop-dont_sectors_single">
            <!--icon start \-->
            <?php if($each_sector['icon']) {
                $icon = wp_get_attachment_url( $each_sector['icon'] ); ?>
                <div class="grop-fix  grop-dont_sectors_image">
                  <img src="<?php echo esc_url( $icon ); ?>" alt="#" />
                </div>
              <?php } ?>
            <div class="grop-dont_sectors_txt">
            <?php if( !empty($link) ){
                echo '<a class="grop-dont_sectors_mta" href="'.$each_sector['link'].'">'.$each_sector['title'].'</a>'; 
              } else {
               echo '<a class="grop-dont_sectors_mta">'.$each_sector['title'].'</a>';
              }
              if (!empty($link)) {
                echo '<a class="grop-btn grop-btn_overly grop-dont_sectors_btn" href="'.esc_url( $link ).'" '.$open_link.'>
                <span>'.esc_html__( $link_text, 'groppe-core' ).'</span>
              </a>';
              } ?>
              
            </div><!--/icon end-->
        </div>
      </div><!--/single sector end-->
      <?php } ?>
</div>
<?php 
    return ob_get_clean();
  }
}
add_shortcode( 'grop_sectors', 'grop_sectors_function' );

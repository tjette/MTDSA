<?php
/* ==========================================================
  Links
=========================================================== */
if ( !function_exists('grop_project_info_function')) {
  function grop_project_info_function( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'project_info_items'  => '',
      'class'  => '',
    ), $atts));

    // Group Field
    $project_info_items = (array) vc_param_group_parse_atts( $project_info_items );
    $get_each_project_info = array();
    foreach ( $project_info_items as $project_info_item ) {
      $each_project_info['title'] = isset( $project_info_item['title'] ) ? $project_info_item['title'] : '';
      $each_project_info['icon'] = isset( $project_info_item['icon'] ) ? $project_info_item['icon'] : '';
      $each_project_info['info'] = isset( $project_info_item['info'] ) ? $project_info_item['info'] : '';
      $get_each_project_info[] = $each_project_info;
    }

    $output = '<div class="grop-prjctinfo_box_warp '.esc_attr($class).'"><ul class="grop-fix grop-list_unstyled">';

      foreach ( $get_each_project_info as $each_project_info ) {
        $info = $each_project_info['info'] ? $each_project_info['info'] : '';
        $title = $each_project_info['title'] ? $each_project_info['title'] : '';
        $icon = $each_project_info['icon'] ? $each_project_info['icon'] : '';
        $icon_image = wp_get_attachment_url( $icon );
          $output .= '<li><div class="text-center  grop-prjctinfo_box">';
          if ($icon) {
            $output .= '<div class="grop-prjcts_icon"><img src="'.esc_url($icon).'" alt="'.$title.'" /></div>';
          }
          if ($title) {
            $output .= '<h6>'.$title.'</h6>';
          }
          if ($info) {
            $output .= '<h5>'.$info.'</h5>';
          }
          $output .= '</div></li>';
      }

    $output .= '</ul></div>';

    return $output;
  }
}
add_shortcode( 'grop_project_info', 'grop_project_info_function' );

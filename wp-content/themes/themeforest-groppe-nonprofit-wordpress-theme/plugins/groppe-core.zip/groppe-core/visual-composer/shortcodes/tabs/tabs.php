<?php
/* ==========================================================
  Tabs
=========================================================== */
if( ! function_exists( 'grop_vt_tabs_function' ) ) {
  function grop_vt_tabs_function( $atts, $content = '', $key = '' ) {

    global $vt_tabs;
    $vt_tabs = array();

    extract( shortcode_atts( array(
      'id'        => '',
      'tab_style' => '',
      'class'     => '',
      'active'    => 1,
    ), $atts ) );

    do_shortcode( $content );

    // is not empty
    if( empty( $vt_tabs ) ) { return; }

    $output       = '';
    $id           = ( $id ) ? ' id="'. $id .'"' : '';
    $active       = ( isset( $_REQUEST['tab'] ) ) ? $_REQUEST['tab'] : $active;
    $uniqtab      = uniqid();
    // begin output
    $output  .= '<div'. $id .' class="grop-project_tabs '. $class .'">';

      // tab-navs
      $output  .= '<ul class="grop-fix grop-list_unstyled  grop-prjct_nav_tabs" role="tablist">';
      foreach( $vt_tabs as $key => $tab ){
        $title      = $tab['atts']['title'];
        $icon       = ( !empty( $tab['atts']['icon'] ) ) ? '<i class="'. $tab['atts']['icon'] .'"></i>': '';
        $active_nav = ( ( $key + 1 ) == $active ) ? ' class="active"' : '';
        $output    .= '<li'. $active_nav .' role="presentation"><a href="#'. $uniqtab .'-'. $key .'" role="tab" data-toggle="tab">'. $title . '</a></li>';
      }
      $output  .= '</ul>';

      // tab-contents
      $output  .= '<div class="tab-content grop-project_tabs_content">';
      foreach( $vt_tabs as $key => $tab ){
        $title           = $tab['atts']['title'];
        $active_content  = ( ( $key + 1 ) == $active ) ? ' in active' : '';
        $output         .= '<div id="'. $uniqtab .'-'. $key .'" class="tab-pane fade in '. $active_content .'">'. do_shortcode( $tab['content'] ) .'</div>';
      }
      $output  .= '</div>';

    $output  .= '</div>';
    // end output

    return $output;
  }
  add_shortcode( 'vt_tabs', 'grop_vt_tabs_function' );
}

/* ==========================================================
  Tab
=========================================================== */
if( ! function_exists( 'grop_vt_tab_function' ) ) {
  function grop_vt_tab_function( $atts, $content = '', $key = '' ) {
    global $vt_tabs;
    $vt_tabs[]  = array( 'atts' => $atts, 'content' => $content );
    return;
  }
  add_shortcode('vt_tab', 'grop_vt_tab_function');
}
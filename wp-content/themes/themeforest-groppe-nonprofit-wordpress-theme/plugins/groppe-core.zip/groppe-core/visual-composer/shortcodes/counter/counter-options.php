<?php
/**
 * Counter - Shortcode Options
 */
add_action( 'init', 'grop_counter_vc_map' );
if ( ! function_exists( 'grop_counter_vc_map' ) ) {
  function grop_counter_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Counter", 'groppe-core'),
      "base" => "grop_counter",
      "description" => esc_html__( "Counter Styles", 'groppe-core'),
      "icon" => "fa fa-sort-numeric-asc color-blue",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(

        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Counter Style', 'groppe-core' ),
          'value' => array(
            esc_html__( 'Basic', 'groppe-core' ) => 'basic',
            esc_html__( 'Standard', 'groppe-core' ) => 'standard',
            esc_html__( 'Enhanced ', 'groppe-core' ) => 'enhanced',
          ),
          'admin_label' => true,
          'param_name' => 'counter_style',
          'description' => esc_html__( 'Select your counter style.', 'groppe-core' ),
        ),
        array(
          'type' => 'dropdown',
          'heading' => esc_html__( 'Counter Column', 'groppe-core' ),
          'value' => array(
            esc_html__( '1 column', 'groppe-core' ) => 'col-1',
            esc_html__( '2 column', 'groppe-core' ) => 'col-2',
            esc_html__( '3 column', 'groppe-core' ) => 'col-3',
            esc_html__( '4 column', 'groppe-core' ) => 'col-4',
            esc_html__( '5 column', 'groppe-core' ) => 'col-5',
          ),
          'admin_label' => true,
          'param_name' => 'counter_column',
          'description' => esc_html__( 'Select your counter column.', 'groppe-core' ),
        ),
        array(
          "type"        =>'textarea',
          "heading"     =>esc_html__('Title', 'groppe-core'),
          "param_name"  => "counter_title",
          "value"       => "",
          "description" => esc_html__( "Enter your counter title.", 'groppe-core'),
          'dependency' => array(
            'element' => 'counter_style',
            'value'     => 'enhanced',
          ),
        ),
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Add Counter', 'groppe-core' ),
          'param_name' => 'counters',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              'type' => 'attach_image',
              'value' => '',
              'heading' => esc_html__( 'Upload Icon', 'groppe-core' ),
              'param_name' => 'image',
            ),
            array(
              "type"        =>'textfield',
              "heading"     =>esc_html__('Counter Value', 'groppe-core'),
              "param_name"  => "counter_value",
              "value"       => "",
              "admin_label"=> true,
              "description" => esc_html__( "Enter numeric value to count. Ex : 20", 'groppe-core')
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Counter Title', 'groppe-core' ),
              'param_name' => 'title',
              "admin_label"=> true,
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Pre Sign', 'groppe-core' ),
              'param_name' => 'pre',
              "admin_label"=> true,
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Post Sign', 'groppe-core' ),
              'param_name' => 'post',
              "admin_label"=> true,
            )
          ),
          'dependency' => array(
            'element' => 'counter_style',
            'value'     => 'enhanced',
          )
        ),
        array(
          'type' => 'attach_image',
          'value' => '',
          'heading' => esc_html__( 'Background Image', 'groppe-core' ),
          'param_name' => 'background_image',
          'dependency' => array(
            'element' => 'counter_style',
            'value'     => 'enhanced',
          )
        ),
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Add Counter', 'groppe-core' ),
          'param_name' => 'counters2',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              "type"        =>'textfield',
              "heading"     =>esc_html__('Counter Value', 'groppe-core'),
              "param_name"  => "counter_value",
              "value"       => "",
              "admin_label"=> true,
              "description" => esc_html__( "Enter numeric value to count. Ex : 20", 'groppe-core')
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Counter Title', 'groppe-core' ),
              'param_name' => 'title',
              "admin_label"=> true,
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Pre Sign', 'groppe-core' ),
              'param_name' => 'pre',
              "admin_label"=> true,
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Post Sign', 'groppe-core' ),
              'param_name' => 'post',
              "admin_label"=> true,
            )
          ),
          'dependency' => array(
            'element' => 'counter_style',
            'value'     => array( 'basic', 'standard' ),
          )
        ),
        GroppeLib::vt_class_option(),

        // Stylings
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Title Color', 'groppe-core'),
          "param_name"  => "counter_title_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
        ),
        array(
          "type"        => 'colorpicker',
          "heading"     => esc_html__('Counter Color', 'groppe-core'),
          "param_name"  => "counter_value_color",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
        ),
        // Size
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Title Size', 'groppe-core'),
          "param_name"  => "counter_title_size",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          "description" => esc_html__( "Enter font size in px.", 'groppe-core')
        ),
        array(
          "type"        => 'textfield',
          "heading"     => esc_html__('Counter Size', 'groppe-core'),
          "param_name"  => "counter_value_size",
          "value"       => "",
          'edit_field_class'   => 'vc_col-md-4 vt_field_space',
          "group"       => esc_html__('Style', 'groppe-core'),
          "description" => esc_html__( "Enter font size in px.", 'groppe-core')
        ),
      )
    ) );
  }
}

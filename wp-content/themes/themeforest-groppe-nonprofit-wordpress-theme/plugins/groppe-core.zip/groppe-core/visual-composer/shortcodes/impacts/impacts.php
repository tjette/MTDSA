<?php
/* Call to Action */
if ( !function_exists('impact_group_function')) {
  function impact_group_function( $atts, $content = true ) {
    extract(shortcode_atts(array(
      'title'  => '',
      'description'  => '',
      'button_text'  => '',
      'button_link'  => '',
      'class'  => '',
    ), $atts));

ob_start(); ?>
    <!--Great Mission area start \-->
        <section class="grop-ab_msion_area">
          <div class="container">
            <div class="row">
              <!--Great Mission heading text start \-->
              <div class="col-md-3  col-sm-6  no-right-padding">
                <div class="grop-ab_msion_heading">
                  <?php
                  if (!empty( $title )) {
                    echo '<h3>'.$title.'</h3>';
                  }
                  if (!empty( $description )) {
                    echo '<p>'.$description.'</p>';
                  }
                  if (!empty( $button_link )) {
                    if (!empty( $button_text )) {
                      $button_text = $button_text;
                    } else {
                      $button_text = 'See Our Impacts';
                    }
                    echo '<a class="grop-btn grop-btn_overly grop-ab_msionrd_btn" href="'.esc_url($button_link).'">
                        <span>'.esc_html__($button_text).'</span>
                      </a>';
                  }
                  ?>
                </div>
              </div><!--/Great Mission heading text end-->
              <?php echo do_shortcode( $content ); ?>
            </div>
          </div>
        </section><!--/ =XXX Great Mission area end XXX=-->
  <?php  return ob_get_clean();

  }
}
add_shortcode( 'impact_group', 'impact_group_function' );

/* Call to Action */
if ( !function_exists('single_impact_function')) {
  function single_impact_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'title'  => '',
      'description'  => '',
      'link'  => '',
      'image'  => '',
      'list_items'  => '',
    ), $atts));


    ob_start(); 
    $list_items = (array) vc_param_group_parse_atts( $list_items );
    $get_each_item = array();
    foreach ( $list_items as $list_item ) {
      $each_item = $list_item;
      $each_item['link'] = isset( $list_item['link'] ) ? $list_item['link'] : '';
      $each_item['title'] = isset( $list_item['title'] ) ? $list_item['title'] : '';
      $get_each_item[] = $each_item;
    } ?>
                  <!--Great Mission single start \-->
    <div class="col-md-3  col-sm-6">
      <div class="grop-ab_msions_cont">
        
        <?php 
          if (!empty( $image )) {
            $image_url = wp_get_attachment_url( $image );
          } else {
            $image_url = GROPPE_PLUGIN_ASTS . '/images/1000x800.jpg';
          }
          ?>
        <div class="grop-ab_msions_image">
          <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $title ); ?>" />
        </div>
        <div class="grop-ab_msions_txt">
        <?php 
          if (!empty($link)) {
            echo '<h4><a href="'.$link.'">'.$title.'</a></h4>';
          } else {
            echo '<h4>'.$title.'</h4>';
          }
          if (!empty($description)) {
            echo '<p>'.$description.'</p>';
          }
          ?>
          <ul class="grop-ab_msions_list">
            <?php
            foreach ( $get_each_item as $each_item ) { 
              if ($each_item['link']) {
                echo '<li><i class="fa fa-check"></i><a href="'.esc_url($each_item['link']).'">'.$each_item['title'].'</a></li>';
              } else {
                echo '<li><i class="fa fa-check"></i>'.$each_item['title'].'</li>';
              }
            } ?>
          </ul>
        </div><!--/end-->
      </div>
    </div><!--/Great Mission single end-->
    <?php
    return ob_get_clean();

  }
}
add_shortcode( 'single_impact', 'single_impact_function' );
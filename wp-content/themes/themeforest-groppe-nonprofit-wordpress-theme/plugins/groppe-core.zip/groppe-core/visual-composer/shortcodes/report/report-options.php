<?php
/**
 * Report - Shortcode Options
 */
add_action( 'init', 'grop_report_vc_map' );
if ( ! function_exists( 'grop_report_vc_map' ) ) {
  function grop_report_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Report", 'groppe-core'),
      "base" => "grop_report",
      "description" => esc_html__( "Report Styles", 'groppe-core'),
      "icon" => "fa fa-report color-red",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Curency Sign', 'groppe-core' ),
          'param_name' => 'curency',
        ),
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Reports', 'groppe-core' ),
          'param_name' => 'report_items',
          'params' => array(
            array(
              'type' => 'textfield',
              'value' => '',
              'admin_label' => true,
              'heading' => esc_html__( 'Title', 'groppe-core' ),
              'param_name' => 'report_title',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Amount', 'groppe-core' ),
              'param_name' => 'amount',
            ),
            array(
              'type' => 'colorpicker',
              'value' => '',
              'heading' => esc_html__( 'Chart Color', 'groppe-core' ),
              'param_name' => 'chart_color',
            ),

          )
        ),
        GroppeLib::vt_class_option(),

        // Style
        array(
          'type' => 'colorpicker',
          'value' => '',
          'heading' => esc_html__( 'Text Color', 'groppe-core' ),
          'param_name' => 'text_color',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'group' => esc_html__( 'Style', 'groppe-core' ),
        ),
        array(
          'type' => 'colorpicker',
          'value' => '',
          'heading' => esc_html__( 'Chart Title Color', 'groppe-core' ),
          'param_name' => 'title_color',
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'group' => esc_html__( 'Style', 'groppe-core' ),
        ),
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Chart Title Size', 'groppe-core' ),
          'param_name' => 'title_size',
          'group' => esc_html__( 'Style', 'groppe-core' ),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'description' => esc_html__( 'Enter the px value if you used title area in report style type one.', 'groppe-core' ),
        ),
        array(
          'type' => 'textfield',
          'value' => '',
          'heading' => esc_html__( 'Text Size', 'groppe-core' ),
          'param_name' => 'text_size',
          'group' => esc_html__( 'Style', 'groppe-core' ),
          'edit_field_class'   => 'vc_col-md-6 vc_column vt_field_space',
          'description' => esc_html__( 'Enter the px value if you used title area in report style type one.', 'groppe-core' ),
        ),

      )
    ) );
  }
}

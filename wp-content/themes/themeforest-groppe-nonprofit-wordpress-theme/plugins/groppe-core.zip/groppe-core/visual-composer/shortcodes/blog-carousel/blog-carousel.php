<?php
/* Blog Carousel */
if ( !function_exists('grop_blog_carousel_function')) {
  function grop_blog_carousel_function( $atts, $content = true ) {

    extract(shortcode_atts(array(
      'class'  => '',
      'blog_title'  => '',
      'blog_title_link'  => '',
      'blog_desc'  => '',
      // Listing
      'perticular_blog'  => '',
      'blog_limit'  => '',
      'blog_order'  => '',
      'blog_orderby'  => '',
      'blog_category' => '',
      'blog_date' => '',
      'blog_comments' => '',

      // Carousel
      'carousel_loop'  => '',
      'carousel_items'  => '',
      'carousel_margin'  => '',
      'carousel_dots'  => '',
      'carousel_nav'  => '',
      'carousel_autoplay_timeout'  => '',
      'carousel_autoplay'  => '',
      'carousel_animate_out'  => '',
      'carousel_mousedrag'  => '',
      'carousel_autowidth'  => '',
      'carousel_autoheight'  => '',
      'carousel_tablet'  => '',
      'carousel_mobile'  => '',
      'carousel_small_mobile'  => '',
    ), $atts));


    // Carousel Data's
    $carousel_loop = $carousel_loop !== 'true' ? 'data-loop="true"' : 'data-loop="false"';
    $carousel_items = $carousel_items ? 'data-items="'. $carousel_items .'"' : 'data-items="3"';
    $carousel_margin = $carousel_margin ? 'data-margin="'. $carousel_margin .'"' : 'data-margin="30"';
    $carousel_dots = $carousel_dots ? 'data-dots="'. $carousel_dots .'"' : 'data-dots="false"';
    $carousel_autoplay_timeout = $carousel_autoplay_timeout ? 'data-autoplay-timeout="'. $carousel_autoplay_timeout .'"' : '';
    $carousel_autoplay = $carousel_autoplay ? 'data-autoplay="'. $carousel_autoplay .'"' : '';
    $carousel_animate_out = $carousel_animate_out ? 'data-animateout="'. $carousel_animate_out .'"' : '';
    $carousel_mousedrag = $carousel_mousedrag !== 'true' ? 'data-mouse-drag="true"' : 'data-mouse-drag="false"';
    $carousel_autowidth = $carousel_autowidth ? 'data-auto-width="'. $carousel_autowidth .'"' : '';
    $carousel_autoheight = $carousel_autoheight ? 'data-auto-height="'. $carousel_autoheight .'"' : '';
    $carousel_tablet = $carousel_tablet ? 'data-items-tablet="'. $carousel_tablet .'"' : 'data-items-tablet="2"';
    $carousel_mobile = $carousel_mobile ? 'data-items-mobile-landscape="'. $carousel_mobile .'"' : '';
    $carousel_small_mobile = $carousel_small_mobile ? 'data-items-mobile-portrait="'. $carousel_small_mobile .'"' : 'data-items-mobile-portrait="1"';
    // Turn output buffer on
    ob_start();

    $args = array(
      'post_type' => 'post',
      'posts_per_page' => (int)$blog_limit,
      'orderby' => $blog_orderby,
      'order' => $blog_order,
      'post__in' => $perticular_blog,
    );

    $grop_blog = new WP_Query( $args );
    if ($grop_blog->have_posts()) : ?>
    <section class="grop-news_area <?php echo esc_attr( $class ); ?>">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="grop-news_single">
            <?php if($blog_title_link){
                echo '<h2><a href="'.$blog_title_link.'">'.$blog_title.'</a></h2>';
              } else {
                echo '<h2>'.$blog_title.'</h2>';
              } 
              echo '<p>'.$blog_desc.'</p>';
              ?>
            </div>
            <?php if ( $carousel_nav ) { ?>
              <div class="latest_news_caro_nav"></div>
          <?php  } ?>
          </div>
          <div class="col-md-9">
            <div class="owl-carousel  grop-latest_news_carousel"  <?php echo $carousel_loop .' '. $carousel_items .' '. $carousel_margin .' '. $carousel_dots .' '. $carousel_autoplay_timeout .' '. $carousel_autoplay .' '. $carousel_animate_out .' '. $carousel_mousedrag .' '. $carousel_autowidth .' '. $carousel_autoheight .' '. $carousel_tablet .' '. $carousel_mobile .' '. $carousel_small_mobile; ?>>

            <?php
            while ($grop_blog->have_posts()) : $grop_blog->the_post();
            // $blog_options = get_post_meta( get_the_ID(), 'blog_options', true );
            // $client_name = $blog_options['blog_name'];
            // $name_link = $blog_options['blog_name_link'];
            // $client_pro = $blog_options['blog_pro'];
            // $pro_link = $blog_options['blog_pro_link'];

            // $name_tag = $name_link ? 'a' : 'span';
            // $client_name = $client_name ? '<h5 class="grop-suessrstr_name">'. $client_name .'</h5>' : '';

            // $pro_tag = $pro_link ? 'a' : 'span';
            // $pro_link = $pro_link ? 'href="'. $pro_link .'" target="_blank"' : '';
            // $client_pro = $client_pro ? '<'. $pro_tag .' '. $pro_link .' class="blog-pro">'. $client_pro .'</'. $pro_tag .'>' : '';
            $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
            $large_image = $large_image[0];

             ?>
              <div class="grop-news_single_post_warp">
                <div class="grop-news_pst_media">
                  <img src="<?php echo esc_url($large_image); ?>" alt="#" />
                </div>
                <div class="grop-news_pst_cont_warp">
                  <div class="grop-news_pst_cont">
                    <?php if( !$blog_date ) { ?>
                      <div class="grop-news_ps_date">
                        <i class="fa fa-clock-o"></i> <?php echo get_the_date('d M Y'); ?>
                      </div>
                    <?php } ?>
                    <h4 class="grop-news_ps_title">
                      <?php
                      if (!empty(get_the_title())) {
                        echo '<a href="'.esc_url( get_the_permalink() ).'">'.get_the_title().'</a>';
                      }
                      ?>
                    </h4>
                  </div>
                  <?php if ( !$blog_comments && !$blog_category) { ?>
                  <div class="grop-fix grop-news_pst_meta">
                  <?php 
                  $category_list = get_the_category_list( ', ' );
                  if ( $category_list && !$blog_category) {
                  ?>
                    <div class="grop-float_left grop-news_pst_in">
                        <?php echo esc_html__( 'in ', 'groppe-core' ).$category_list; ?>
                    </div>
                    <?php } if( !$blog_comments ) { ?>
                    <div class="grop-float_right grop-news_pst_commnt">
                      <?php comments_popup_link( __( '<i class="fa fa-comment-o"></i>0', 'groppe' ), __( '<i class="fa fa-comment-o"></i>1', 'groppe' ), __( '<i class="fa fa-comment-o"></i>%', 'groppe' ), '', '' ); ?>
                    </div>
                    <?php } ?>
                  </div><!--/ end-->
                  <?php } ?>
                </div>
              </div>
            <?php
            endwhile;
            wp_reset_postdata();
            ?>
          </div> <!--carousel loop -->
        </div> <!-- col 9 -->
      </div> <!-- row -->
    </div> <!-- container -->
  </section> <!-- Blog End -->

<?php
  endif;

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'grop_blog_carousel', 'grop_blog_carousel_function' );
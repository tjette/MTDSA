<?php
/**
 * Project Info - Shortcode Options
 */
add_action( 'init', 'grop_project_info_vc_map' );
if ( ! function_exists( 'grop_project_info_vc_map' ) ) {
  function grop_project_info_vc_map() {
    vc_map( array(
      "name" => esc_html__( "Project Info", 'groppe-core'),
      "base" => "grop_project_info",
      "description" => esc_html__( "Project Info Styles", 'groppe-core'),
      "icon" => "fa fa-project_info color-red",
      "category" => GroppeLib::grop_cat_name(),
      "params" => array(
        // Project Info
        array(
          'type' => 'param_group',
          'value' => '',
          'heading' => esc_html__( 'Project Infos', 'groppe-core' ),
          'param_name' => 'project_info_items',
          // Note params is mapped inside param-group:
          'params' => array(
            array(
              'type' => 'attach_image',
              'value' => '',
              'heading' => esc_html__( 'Icon', 'groppe-core' ),
              'param_name' => 'icon',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'admin_label' => true,
              'heading' => esc_html__( 'Info Title', 'groppe-core' ),
              'param_name' => 'title',
            ),
            array(
              'type' => 'textfield',
              'value' => '',
              'heading' => esc_html__( 'Info', 'groppe-core' ),
              'param_name' => 'info',
            ),
          )
        ),
        GroppeLib::vt_class_option(),
      )
    ) );
  }
}

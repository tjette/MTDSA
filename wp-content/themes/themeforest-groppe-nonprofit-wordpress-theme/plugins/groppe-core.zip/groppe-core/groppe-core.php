<?php
/*
Plugin Name: Groppe Core
Plugin URI: http://themeforest.net/user/VictorThemes
Description: Plugin to contain shortcodes and custom post types of the groppe theme.
Author: VictorThemes
Author URI: http://themeforest.net/user/VictorThemes/portfolio
Version: 1.1
Text Domain: groppe-core
*/

if( ! function_exists( 'groppe_block_direct_access' ) ) {
	function groppe_block_direct_access() {
		if( ! defined( 'ABSPATH' ) ) {
			exit( 'Forbidden' );
		}
	}
}

// Plugin URL
define( 'GROPPE_PLUGIN_URL', plugins_url( '/', __FILE__ ) );

// Plugin PATH
define( 'GROPPE_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'GROPPE_PLUGIN_ASTS', GROPPE_PLUGIN_URL . 'assets' );
define( 'GROPPE_PLUGIN_IMGS', GROPPE_PLUGIN_ASTS . '/images' );
define( 'GROPPE_PLUGIN_INC', GROPPE_PLUGIN_PATH . 'inc' );

// DIRECTORY SEPARATOR
define ( 'DS' , DIRECTORY_SEPARATOR );

// Groppe Shortcode Path
define( 'GROPPE_SHORTCODE_BASE_PATH', GROPPE_PLUGIN_PATH . 'visual-composer/' );
define( 'GROPPE_SHORTCODE_PATH', GROPPE_SHORTCODE_BASE_PATH . 'shortcodes/' );

/**
 * Check if Codestar Framework is Active or Not!
 */
function groppe_framework_active() {
  return ( defined( 'CS_VERSION' ) ) ? true : false;
}

/* VTHEME_NAME_P */
define('VTHEME_NAME_P', 'Groppe', true);

// Initial File
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if (is_plugin_active('groppe-core/groppe-core.php')) {

	// Custom Post Type
	require_once( GROPPE_PLUGIN_INC . '/custom-post-type.php' );

  // Shortcodes
  require_once( GROPPE_SHORTCODE_BASE_PATH . '/vc-setup.php' );
  require_once( GROPPE_PLUGIN_INC . '/custom-shortcodes/theme-shortcodes.php' );
  require_once( GROPPE_PLUGIN_INC . '/custom-shortcodes/custom-shortcodes.php' );

  // Widgets
  require_once( GROPPE_PLUGIN_INC . '/widgets/about-widget.php' );
  require_once( GROPPE_PLUGIN_INC . '/widgets/get-quote-widget.php' );
  require_once( GROPPE_PLUGIN_INC . '/widgets/nav-widget.php' );
  require_once( GROPPE_PLUGIN_INC . '/widgets/recent-posts.php' );
  require_once( GROPPE_PLUGIN_INC . '/widgets/latest-news.php' );
  require_once( GROPPE_PLUGIN_INC . '/widgets/testimonial-widget.php' );
  require_once( GROPPE_PLUGIN_INC . '/widgets/text-widget.php' );
  require_once( GROPPE_PLUGIN_INC . '/widgets/widget-extra-fields.php' );
  require_once( GROPPE_PLUGIN_INC . '/widgets/cause-categories.php' );
  require_once( GROPPE_PLUGIN_INC . '/widgets/urgent-causes.php' );
  require_once( GROPPE_PLUGIN_INC . '/widgets/call-to-action.php' );

}

/**
 * Plugin language
 */
function groppe_plugin_language_setup() {
  load_plugin_textdomain( 'groppe-core', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'groppe_plugin_language_setup' );

/* WPAUTOP for shortcode output */
if( ! function_exists( 'groppe_set_wpautop' ) ) {
  function groppe_set_wpautop( $content, $force = true ) {
    if ( $force ) {
      $content = wpautop( preg_replace( '/<\/?p\>/', "\n", $content ) . "\n" );
    }
    return do_shortcode( shortcode_unautop( $content ) );
  }
}

/* Use shortcodes in text widgets */
add_filter('widget_text', 'do_shortcode');

/* Shortcodes enable in the_excerpt */
add_filter('the_excerpt', 'do_shortcode');

/* Remove p tag and add by our self in the_excerpt */
remove_filter('the_excerpt', 'wpautop');

/* Add Extra Social Fields in Admin User Profile */
function groppe_add_twitter_facebook( $contactmethods ) {
  $contactmethods['facebook']   = 'Facebook';
  $contactmethods['twitter']    = 'Twitter';
  $contactmethods['google_plus']  = 'Google Plus';
  $contactmethods['linkedin']   = 'Linkedin';
  return $contactmethods;
}
add_filter('user_contactmethods','groppe_add_twitter_facebook',10,1);

/**
 *
 * Encode string for backup options
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'cs_encode_string' ) ) {
  function cs_encode_string( $string ) {
    return rtrim( strtr( call_user_func( 'base'. '64' .'_encode', addslashes( gzcompress( serialize( $string ), 9 ) ) ), '+/', '-_' ), '=' );
  }
}

/**
 *
 * Decode string for backup options
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'cs_decode_string' ) ) {
  function cs_decode_string( $string ) {
    return unserialize( gzuncompress( stripslashes( call_user_func( 'base'. '64' .'_decode', rtrim( strtr( $string, '-_', '+/' ), '=' ) ) ) ) );
  }
}
function wp_list_categories_remove_title_attributes($output) {
    $output = preg_replace('` title=""`', '', $output);
    return $output;
}
add_filter('wp_list_categories', 'wp_list_categories_remove_title_attributes');

/**
 * Share Option
 */
if ( ! function_exists( 'groppe_wp_share_option' ) ) {
  function groppe_wp_share_option() {

    global $post;
    $page_url = get_permalink($post->ID );
    $media_url =  get_the_post_thumbnail_url();
    $title = $post->post_title;
    $share_text = cs_get_option('share_text');
    $share_text = $share_text ? $share_text : esc_html__( 'Share', 'groppe' );
    ?>
    <div class="grop-sigl_social">
      <div class="row grop-flax_vr-middle">
        <div class="text-left col-sm-5 grop-siglso_txt">
          <h4><?php echo esc_attr($share_text); ?>:</h4>
        </div>
        <div class="text-right col-sm-7 grop-siglso_share">
          <div class="grop-siglso_share_warp">
            <ul class="list-inline">
              <li>
                <a href="//www.facebook.com/sharer/sharer.php?u=<?php print(urlencode($page_url)); ?>&amp;t=<?php print(urlencode($title)); ?>"><i class="fa fa-facebook"></i></a>
              </li>
              <li>
                <a href="//twitter.com/home?status=<?php print(urlencode($title)); ?>+<?php print(urlencode($page_url)); ?>"><i class="fa fa-twitter"></i></a>
              </li>
              <li>
                <a href="//plus.google.com/share?url=<?php print(urlencode($page_url)); ?>"><i class="fa fa-google-plus"></i></a>
              </li>
              <li>
                <a href="http://pinterest.com/pin/create/button/?url=<?php print(urlencode($page_url)); ?>&amp;media=<?php print(urlencode($media_url)); ?>"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
              </li>
              <li>
                <a href="//www.linkedin.com/shareArticle?mini=true&amp;url=<?php print(urlencode($page_url)); ?>&amp;title=<?php print(urlencode($title)); ?>"><i class="fa fa-linkedin"></i></a>
              </li>
              <li>
                <a href="mailto:?subject=<?php print(urlencode($title)); ?>&amp;body=<?php print(urlencode($page_url)); ?>"><i class="fa fa-envelope" aria-hidden="true"></i></a>
              </li>
            </ul>
          </div>
            <!--plus btn start\-->
            <a class="grop-siglso_plus"  href="">
              <i class="fa fa-plus"></i>
            </a><!--/plus btn end-->
        </div>
      </div>
    </div><!--/ end-->
<?php
  }
}

/* Event Share Options */
if ( ! function_exists( 'groppe_event_share_option' ) ) {
  function groppe_event_share_option() {

    global $post;
    $page_url = get_permalink($post->ID );
    $title = $post->post_title;
    ?>
    <div class="grop-evshare_warp">
      <a class="grop-evshare_share" href=""><i class="fa fa-share-alt"></i></a>
      <div class="grop-evshare_icon">
        <a class="grop-ev-facebook" href="//www.facebook.com/sharer/sharer.php?u=<?php print(urlencode($page_url)); ?>&amp;t=<?php print(urlencode($title)); ?>"><i class="fa fa-facebook"></i></a>
        <a class="grop-ev-twitter" href="//twitter.com/home?status=<?php print(urlencode($title)); ?>+<?php print(urlencode($page_url)); ?>"><i class="fa fa-twitter"></i></a>
        <a class="grop-ev-google-plus"  href="//plus.google.com/share?url=<?php print(urlencode($page_url)); ?>"><i class="fa fa-google-plus"></i></a>
      </div>
    </div>
<?php
  }
}

/* Cause Pop-up Form */
if ( ! function_exists( 'groppe_cause_popup_form' ) ) {
  function groppe_cause_popup_form() {
$args = array(
  'number' => -1,
);
$form        = new Give_Donate_Form( get_the_ID() );
$goal_option = get_post_meta( get_the_ID(), '_give_goal_option', true );
$goal        = $form->goal;
$goal_format = get_post_meta( get_the_ID(), '_give_goal_format', true );
$income      = $form->get_earnings();
$color       = get_post_meta( get_the_ID(), '_give_goal_color', true );
//Sanity check - ensure form has goal set to output
if ( empty( $form->ID ) || ( is_singular( 'give_forms' ) && ! give_is_setting_enabled( $goal_option ) ) || ! give_is_setting_enabled( $goal_option ) || $goal == 0 ) {
  return false;
}
$progress = round( ( $income / $goal ) * 100, 2 );
if ( $income >= $goal ) {
  $progress = 100;
}
$income = give_human_format_large_amount( give_format_amount( $income ) );
$goal = give_human_format_large_amount( give_format_amount( $goal ) );
$payment_mode = give_get_chosen_gateway( get_the_ID() );
$form_action = add_query_arg( apply_filters( 'give_form_action_args', array( 'payment-mode' => $payment_mode, ) ),  give_get_current_page_url() ); ?>
<div class="popup-dontate">
  <div class="donate-popup-form submit-form">
    <a href="" class="single-donate-close"><i class="fa fa-close"></i></a>
    <form id="give-form-<?php echo esc_attr(get_the_ID()); ?>" action="<?php echo esc_url_raw( $form_action ); ?>" method="post">
      <input type="hidden" name="give-form-id" value="<?php echo esc_attr( $form->ID ); ?>"/>
      <input type="hidden" name="give-form-title" value="<?php echo htmlentities( $form->post_title ); ?>"/>
      <input type="hidden" name="give-current-url"
           value="<?php echo htmlspecialchars( give_get_current_page_url() ); ?>"/>
      <input type="hidden" name="give-form-url"
           value="<?php echo htmlspecialchars( give_get_current_page_url() ); ?>"/>
      <input type="hidden" name="give-form-minimum"
           value="<?php echo give_format_amount( give_get_form_minimum_price( $form->ID ) ); ?>"/>
      <span class="give-hidden" style="display: none !important;">
        <label for="give-form-honeypot-<?php echo esc_attr(get_the_ID()); ?>"></label>
        <input id="give-form-honeypot-<?php echo esc_attr(get_the_ID()); ?>" type="text" name="give-honeypot" class="give-honeypot give-hidden"/>
      </span>
      <?php
      // Price ID hidden field for variable (mult-level) donation forms.
      if ( give_has_variable_prices( get_the_ID() ) ) {
        // Get default selected price ID.
        $prices   = apply_filters( 'give_form_variable_prices', give_get_variable_prices( get_the_ID() ), get_the_ID() );
        $price_id = 0;
        //loop through prices.
        foreach ( $prices as $price ) {
          if ( isset( $price['_give_default'] ) && $price['_give_default'] === 'default' ) {
            $price_id = $price['_give_id']['level_id'];
          };
        }
        ?>
        <input type="hidden" name="give-price-id" value="<?php echo esc_attr( $price_id ); ?>"/>
      <?php }
        give_get_donation_form($form->ID, $args);
      ?>
    </form>
  </div>
</div>
<?php
  }
}

/* Pop-up Form */
if ( ! function_exists( 'groppe_popup_form' ) ) {
  function groppe_popup_form() {

    global $post;
    $groppe_id    = ( isset( $post ) ) ? $post->ID : false;
    $groppe_id    = ( is_home() ) ? get_option( 'page_for_posts' ) : $groppe_id;
    $groppe_id    = ( is_woocommerce_shop() ) ? wc_get_page_id( 'shop' ) : $groppe_id;
    $groppe_id    = ( ! is_tag() && ! is_archive() && ! is_search() && ! is_404() && ! is_singular('testimonial') ) ? $groppe_id : false;
    $groppe_meta  = get_post_meta( $groppe_id, 'page_type_metabox', true );

    // Header Style
    if ($groppe_meta) {
      $groppe_header_design  = $groppe_meta['select_header_design'];
    } else {
      $groppe_header_design  = '';
    }
    if ($groppe_meta && $groppe_header_design !== 'default') {
      $donate_btn_type    = $groppe_meta['donate_btn_type'];
      $pop_form_id    = $groppe_meta['pop_form_id'];
    } else {
      $donate_btn_type    = cs_get_option('donate_btn_type');
      $pop_form_id    = cs_get_option('pop_form_id');
    }
    ob_start();
    if ($donate_btn_type === 'popup') {
      $pop_id = $pop_form_id ? 'id='.$pop_form_id : '';
    ?>
    <div class="grop-model_popup_warp">
      <div <?php echo esc_attr($pop_id); ?> class="modal fade" role="dialog">
        <div class="modal-dialog  grop-model_dialog">
          <div class="modal-content  grop-model_content">
            <div class="modal-header grop-model_header">
              <button type="button" class="close" data-dismiss="modal">&times;</button><!--/ close btn end-->
              <div class="grop-resform_headr">
                <?php
                $args = array('post_type' => 'wpcf7_contact_form', 'p'=>$pop_form_id);
                 $cf7Forms = get_posts( $args );
                 $form_titles = get_the_title( $pop_form_id );
                echo esc_attr($form_titles); ?>
              </div>
            </div>
            <!-- Modal Popup content body start\-->
            <div class="modal-body grop-model_body">
              <div class="grop-resform_form  grop-contact_poup_form">
                <?php echo do_shortcode( '[contact-form-7 id="'. esc_attr($pop_form_id) .'"]' ); ?>
              </div>
            </div><!--/ Modal Popup content body end-->
            <div class="modal-footer grop-model_footer">
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php }
    $output = ob_get_clean();
      return $output;
  }
}

/* Event Pop-up Form */
if ( ! function_exists( 'groppe_event_popup_form' ) ) {
  function groppe_event_popup_form() {
$event_popup_options = get_post_meta( get_the_ID(), '_event_popup_form_metabox', true );
  if ($event_popup_options) {
    if ($event_popup_options['popup_btn']) {
    $event_contact_btn = $event_popup_options['popup_btn'];
    $event_popup_form_id = $event_popup_options['form_id'];
    $event_contact_btn_type = $event_popup_options['contact_btn_type'];
    $event_contact_btn_link = $event_popup_options['contact_btn_link'] ? $event_popup_options['contact_btn_link'] : cs_get_option('contact_btn_link');
    } else {
      $event_contact_btn = cs_get_option('popup_btn');
      $event_popup_form_id = cs_get_option('form_id');
      $event_contact_btn_type = cs_get_option('contact_btn_type');
      $event_contact_btn_link = cs_get_option('contact_btn_link');
    }
  } else {
    $event_contact_btn = cs_get_option('popup_btn');
    $event_popup_form_id = cs_get_option('form_id');
    $event_contact_btn_type = cs_get_option('contact_btn_type');
    $event_contact_btn_link = cs_get_option('contact_btn_link');
  } ?>
<div class="grop-model_popup_warp">
  <?php $pop_id = $event_popup_form_id ? 'id='.$event_popup_form_id : ''; ?>
  <div <?php echo esc_attr($pop_id); ?> class="modal fade" role="dialog">
    <div class="modal-dialog  grop-model_dialog">
      <div class="modal-content  grop-model_content">
        <div class="modal-header grop-model_header">
          <button type="button" class="close" data-dismiss="modal">&times;</button><!--/ close btn end-->
          <div class="grop-resform_headr">
            <?php
            $args = array('post_type' => 'wpcf7_contact_form', 'p'=>$event_popup_form_id);
             $cf7Forms = get_posts( $args );
             $form_titles = get_the_title( $event_popup_form_id );
            echo esc_attr($form_titles); ?>
          </div>
        </div>
        <!-- Modal Popup content body start\-->
        <div class="modal-body grop-model_body">
          <div class="grop-resform_form  grop-contact_poup_form">
            <?php echo do_shortcode( '[contact-form-7 id="'. $event_popup_form_id .'"]' ); ?>
          </div>
        </div><!--/ Modal Popup content body end-->
        <div class="modal-footer grop-model_footer">
        </div>
      </div>
    </div>
  </div>
</div>
<?php
  }
}

/* Custom WordPress admin login logo */
if( ! function_exists( 'groppe_theme_login_logo' ) ) {
  function groppe_theme_login_logo() {
    $login_logo = cs_get_option('brand_logo_wp');
    if($login_logo) {
      $login_logo_url = wp_get_attachment_url($login_logo);
    } else {
      $login_logo_url = GROPPE_IMAGES . '/logo.png';
    }
    if($login_logo) {
    echo "
      <style>
        body.login #login h1 a {
        background: url('$login_logo_url') no-repeat scroll center bottom transparent;
        height: 100px;
        width: 100%;
        margin-bottom:0px;
        }
      </style>";
    }
  }
  add_action('login_head', 'groppe_theme_login_logo');
}

/* WordPress admin login logo link */
if( ! function_exists( 'groppe_login_url' ) ) {
  function groppe_login_url() {
    return site_url();
  }
  add_filter( 'login_headerurl', 'groppe_login_url', 10, 4 );
}

/* WordPress admin login logo link */
if( ! function_exists( 'groppe_login_title' ) ) {
  function groppe_login_title() {
    return get_bloginfo('name');
  }
  add_filter('login_headertitle', 'groppe_login_title');
}

/**
 * One Click Install
 * @return Import Demos - Needed Import Demo's
 */
function groppe_import_files() {
  return array(
    array(
      'import_file_name'           => 'Groppe',
      'import_file_url'            => trailingslashit( GROPPE_PLUGIN_URL ) . 'inc/import/content.xml',
      'import_widget_file_url'     => trailingslashit( GROPPE_PLUGIN_URL ) . 'inc/import/widget.wie',
      'local_import_csf'           => array(
        array(
          'file_path'   => trailingslashit( GROPPE_PLUGIN_URL ) . 'inc/import/theme-options.json',
          'option_name' => '_cs_options',
        ),
      ),
      'import_notice'              => __( 'Import process may take 3-5 minutes, please be patient. It\'s really based on your network speed.', 'groppe-core' ),
      'preview_url'                => 'http://victorthemes.com/themes/groppe',
    ),
  );
}
add_filter( 'pt-ocdi/import_files', 'groppe_import_files' );

/**
 * One Click Import Function for CodeStar Framework
 */
if ( ! function_exists( 'csf_after_content_import_execution' ) ) {
  function csf_after_content_import_execution( $selected_import_files, $import_files, $selected_index ) {

    $downloader = new OCDI\Downloader();

    if( ! empty( $import_files[$selected_index]['import_csf'] ) ) {

      foreach( $import_files[$selected_index]['import_csf'] as $index => $import ) {
        $file_path = $downloader->download_file( $import['file_url'], 'demo-csf-import-file-'. $index . '-'. date( 'Y-m-d__H-i-s' ) .'.json' );
        $file_raw  = OCDI\Helpers::data_from_file( $file_path );
        update_option( $import['option_name'], json_decode( $file_raw, true ) );
      }

    } else if( ! empty( $import_files[$selected_index]['local_import_csf'] ) ) {

      foreach( $import_files[$selected_index]['local_import_csf'] as $index => $import ) {
        $file_path = $import['file_path'];
        $file_raw  = OCDI\Helpers::data_from_file( $file_path );
        update_option( $import['option_name'], json_decode( $file_raw, true ) );
      }

    }

    // Put info to log file.
    $ocdi       = OCDI\OneClickDemoImport::get_instance();
    $log_path   = $ocdi->get_log_file_path();

    OCDI\Helpers::append_to_file( 'Codestar Framework files loaded.'. $logs, $log_path );

  }
  add_action('pt-ocdi/after_content_import_execution', 'csf_after_content_import_execution', 3, 99 );
}

/**
 * [groppe_after_import_setup]
 * @return Front Page, Post Page & Menu Set
 */
function groppe_after_import_setup() {
    // Assign menus to their locations.
    $main_menu = get_term_by( 'name', 'Main Menu 2', 'nav_menu' );

    set_theme_mod( 'nav_menu_locations', array(
        'primary' => $main_menu->term_id,
      )
    );

    // Assign front page and posts page (blog page).
    $front_page_id = get_page_by_title( 'Front Page' );
    $blog_page_id  = get_page_by_title( 'Blog' );

    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    update_option( 'page_for_posts', $blog_page_id->ID );

}
add_action( 'pt-ocdi/after_import', 'groppe_after_import_setup' );

// Install Demos Menu - Menu Edited
function groppe_core_one_click_page( $default_settings ) {
  $default_settings['parent_slug'] = 'themes.php';
  $default_settings['page_title']  = esc_html__( 'Install Demos', 'groppe-core' );
  $default_settings['menu_title']  = esc_html__( 'Install Demos', 'groppe-core' );
  $default_settings['capability']  = 'import';
  $default_settings['menu_slug']   = 'install_demos';

  return $default_settings;
}
add_filter( 'pt-ocdi/plugin_page_setup', 'groppe_core_one_click_page' );

// Model Popup - Width Increased
function groppe_ocdi_confirmation_dialog_options ( $options ) {
  return array_merge( $options, array(
    'width'       => 600,
    'dialogClass' => 'wp-dialog',
    'resizable'   => false,
    'height'      => 'auto',
    'modal'       => true,
  ) );
}
add_filter( 'pt-ocdi/confirmation_dialog_options', 'groppe_ocdi_confirmation_dialog_options', 10, 1 );

// Disable the branding notice - ProteusThemes
add_filter( 'pt-ocdi/disable_pt_branding', '__return_true' );

function ocdi_plugin_intro_text( $default_text ) {
    $default_text .= '<h1>Install Demos</h1>
    <div class="groppe-core_intro-text vtdemo-one-click">
    <div id="poststuff">

      <div class="postbox important-notes">
        <h3><span>Important notes:</span></h3>
        <div class="inside">
          <ol>
            <li>Please note, this import process will take time. So, please be patient.</li>
            <li>Please make sure you\'ve installed recommended plugins before you import this content.</li>
            <li>All images are demo purposes only. So, images may repeat in your site content.</li>
          </ol>
        </div>
      </div>

      <div class="postbox vt-support-box vt-error-box">
        <h3><span>Don\'t Edit Parent Theme Files:</span></h3>
        <div class="inside">
          <p>Don\'t edit any files from parent theme! Use only a <strong>Child Theme</strong> files for your customizations!</p>
          <p>If you get future updates from our theme, you\'ll lose edited customization from your parent theme.</p>
        </div>
      </div>

      <div class="postbox vt-support-box">
        <h3><span>Need Support?</span> <a href="https://www.youtube.com/watch?v=xJJUgi02lWE" target="_blank" class="cs-section-video"><i class="fa fa-youtube-play"></i> <span>How to?</span></a></h3>
        <div class="inside">
          <p>Have any doubts regarding this installation or any other issues? Please feel free to open a ticket in our support center.</p>
          <a href="http://victorthemes.com/docs/groppe" class="button-primary" target="_blank">Docs</a>
          <a href="https://victorthemes.com/my-account/support/" class="button-primary" target="_blank">Support</a>
          <a href="https://themeforest.net/item/groppe-nonprofit-wordpress-theme/20351940?ref=VictorThemes" class="button-primary" target="_blank">Item Page</a>
        </div>
      </div>

    </div>
  </div>';

    return $default_text;
}
add_filter( 'pt-ocdi/plugin_intro_text', 'ocdi_plugin_intro_text' );

<form method="get" id="searchform" action="<?php echo esc_url(home_url('/')); ?>" class="grop-wigt_search_form" >
	<input class="grop-wigt_search_field" type="search" name="s" id="s" placeholder="<?php esc_html_e( 'Looking For Something?', 'groppe' ); ?>" />
	<button type="submit" class="grop-wigt_search_submit"><span class="fa fa-search"></span></button>
</form>
<div class="grop-hadr_search">
<a href="#"><i class="fa fa-search"></i></a>
<div class="grop-hadrsrch_form_warp">
	<div class="grop-hadrsrch_form">
		<form method="get" id="searchform" action="<?php echo esc_url(home_url('/')); ?>" >
			<input type="search" name="s" id="s" placeholder="<?php esc_html_e( 'Type and hit enter', 'groppe' ); ?>">
			<button type="submit">
				<span class="grop-srchicon"></span>
			</button>
		</form>
	</div>
</div>
</div><!--/end-->